"""
Unified Antidetect Session.
High-level reusable context manager providing fluent access to DOM, Vision,
Mouse, Cookies, Navigation, and Screenshot operations on an active profile.
"""

from __future__ import annotations
import time
from pathlib import Path
from typing import Optional, Union, Any, Dict, List

from sammonny.core.cdp import SyncCdpClient
from sammonny.core.client import SamMonnyDaemonClient
from sammonny.core.models import Point, Rect, CookieItem
from sammonny.dom.controller import DOMController
from sammonny.dom.stealth_controller import StealthDOMController, HoneypotDetectedError
from sammonny.dom.mouse import HumanMouse
from sammonny.vision.locator import ImageLocator
from sammonny.cookies.cdp_extractor import CdpCookieClient
from sammonny.cookies.sqlite_manager import CookieSqliteManager
from sammonny.network.monitor import NetworkMonitor
from sammonny.network.kernel_http import KernelHttpClient, KernelResponse
from sammonny.system.memory_scanner import ProcessMemoryScanner
from sammonny.signatures.harvester import KernelSignatureHarvester

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False


class AntidetectSession:
    """Fluent, reusable execution session for a single browser profile."""

    def __init__(
        self,
        profile_id: str,
        daemon_client: SamMonnyDaemonClient,
        ws_url: Optional[str] = None,
        profile_dir: Optional[Path] = None,
        auto_stop_on_exit: bool = True,
    ):
        self.profile_id = profile_id
        self.daemon = daemon_client
        self.ws_url = ws_url
        self.profile_dir = profile_dir or (Path("profiles") / profile_id)
        self.auto_stop = auto_stop_on_exit

        self._cdp: Optional[SyncCdpClient] = None
        self._dom: Optional[DOMController] = None
        self._stealth_dom: Optional[StealthDOMController] = None
        self._mouse: Optional[HumanMouse] = None
        self._vision: Optional[ImageLocator] = None
        self._cookies: Optional[CdpCookieClient] = None
        self._offline_cookies: Optional[CookieSqliteManager] = None
        self._network: Optional[NetworkMonitor] = None
        self._memory: Optional[ProcessMemoryScanner] = None
        self._signatures: Optional[KernelSignatureHarvester] = None
        self._http: Optional[KernelHttpClient] = None
        self._browser_pid: Optional[int] = None

    def _resolve_browser_pid(self) -> Optional[int]:
        if not self.ws_url or not HAS_PSUTIL:
            return None
        try:
            clean = self.ws_url.replace("ws://", "").replace("wss://", "")
            host_port = clean.split("/")[0]
            if ":" in host_port:
                port = int(host_port.split(":")[1])
                for conn in psutil.net_connections():
                    if conn.laddr and conn.laddr.port == port:
                        return conn.pid
        except Exception:
            pass
        return None

    def start(self, headless: bool = False) -> AntidetectSession:
        if not self.ws_url:
            self.ws_url = self.daemon.start_profile(self.profile_id, headless=headless)

        self._cdp = SyncCdpClient(self.ws_url).connect()
        self._mouse = HumanMouse(self._cdp)
        self._dom = DOMController(self._cdp, self._mouse)
        self._stealth_dom = StealthDOMController(self._cdp, self._mouse)
        self._vision = ImageLocator(self._cdp, self._mouse)
        self._cookies = CdpCookieClient(self._cdp)
        self._offline_cookies = CookieSqliteManager(self.profile_dir)

        # Network Monitor
        self._network = NetworkMonitor(self._cdp)
        self._network.enable()

        # In-Memory RAM Scanner
        self._browser_pid = self._resolve_browser_pid()
        if self._browser_pid:
            self._memory = ProcessMemoryScanner(self._browser_pid)

        # In-Kernel & Profile-Bound Signature Harvester
        self._signatures = KernelSignatureHarvester(profile_id=self.profile_id, cdp_client=self._cdp)

        # In-Kernel Browser Network Client
        self._http = KernelHttpClient(self._cdp, session=self)

        return self

    def close(self) -> None:
        if self._network:
            try:
                self._network.disable()
            except Exception:
                pass
            self._network = None

        if self._cdp:
            try:
                self._cdp.close()
            except Exception:
                pass
            self._cdp = None

        if self.auto_stop:
            try:
                self.daemon.stop_profile(self.profile_id)
            except Exception:
                pass

    def __enter__(self) -> AntidetectSession:
        return self.start()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    # =========================================================================
    # Subsystem Properties
    # =========================================================================

    @property
    def cdp(self) -> SyncCdpClient:
        if not self._cdp:
            raise RuntimeError("Session is not active. Call .start() or use 'with' context manager.")
        return self._cdp

    @property
    def dom(self) -> DOMController:
        if not self._dom:
            raise RuntimeError("Session is not active.")
        return self._dom

    @property
    def mouse(self) -> HumanMouse:
        if not self._mouse:
            raise RuntimeError("Session is not active.")
        return self._mouse

    @property
    def vision(self) -> ImageLocator:
        if not self._vision:
            raise RuntimeError("Session is not active.")
        return self._vision

    @property
    def live_cookies(self) -> CdpCookieClient:
        if not self._cookies:
            raise RuntimeError("Session is not active.")
        return self._cookies

    @property
    def sqlite_cookies(self) -> CookieSqliteManager:
        if not self._offline_cookies:
            self._offline_cookies = CookieSqliteManager(self.profile_dir)
        return self._offline_cookies

    @property
    def network(self) -> NetworkMonitor:
        """Real-time network traffic monitor & WebSocket frame sniffer."""
        if not self._network:
            raise RuntimeError("Session is not active.")
        return self._network

    @property
    def stealth_dom(self) -> StealthDOMController:
        """Stealth DOM controller with Anti-Bot honeypot neutralization."""
        if not self._stealth_dom:
            raise RuntimeError("Session is not active.")
        return self._stealth_dom

    @property
    def memory(self) -> Optional[ProcessMemoryScanner]:
        """Win32 in-memory RAM scanner for the running browser process."""
        if not self._memory:
            self._browser_pid = self._resolve_browser_pid()
            if self._browser_pid:
                self._memory = ProcessMemoryScanner(self._browser_pid)
        return self._memory

    @property
    def signatures(self) -> KernelSignatureHarvester:
        """In-Kernel & Profile-Bound Hardware Signature Harvester."""
        if not self._signatures:
            self._signatures = KernelSignatureHarvester(profile_id=self.profile_id, cdp_client=self._cdp)
        return self._signatures

    @property
    def http(self) -> KernelHttpClient:
        """In-Kernel HTTP Client. Sends outgoing requests through Chromium network stack."""
        if not self._http:
            self._http = KernelHttpClient(self.cdp, session=self)
        return self._http

    @property
    def auditor(self):
        from sammonny.vpn.audit import NetworkLeakAuditor
        return NetworkLeakAuditor(self.cdp)

    def audit_leaks(self):
        """Runs preflight security leak audit (WebRTC, DNS, IPv6)."""
        return self.auditor.audit_full()


    # =========================================================================
    # Fluent Shortcuts
    # =========================================================================

    def goto(self, url: str) -> AntidetectSession:
        self.cdp.navigate(url)
        time.sleep(1.0)
        return self

    def click(self, target: Union[str, Path], style: str = "minimum_jerk") -> Point:
        """
        Smart click:
        - If target is a file path or ends with .png/.jpg, uses Computer Vision template matching.
        - Otherwise, treats target as a CSS selector in DOM with Honeypot protection.
        """
        return self.smart_click(target, style=style)

    def smart_click(self, target: Union[str, Path], style: str = "minimum_jerk", timeout: float = 10.0) -> Point:
        """
        Anti-Bot Immune Dual-Engine Smart Click:
        1. If target is an image file path, executes 100% DOM-less Optical Computer Vision.
        2. Otherwise, validates target element against honeypot filters (0x0, hidden, offscreen traps),
           and executes Minimum Jerk Quintic Spline with 2D Gaussian sampling.
        """
        target_str = str(target)
        if target_str.endswith((".png", ".jpg", ".jpeg", ".webp")) or Path(target_str).exists():
            return self.vision.click_image(target_str, style=style, timeout=timeout)
        try:
            return self.stealth_dom.click(target_str, style=style, timeout=timeout)
        except Exception:
            return self.dom.click(target_str, style=style, timeout=timeout)

    def type(self, selector: str, text: str, wpm: float = 85.0) -> AntidetectSession:
        self.dom.type_text(selector, text, wpm=wpm)
        return self

    def screenshot(self, save_path: Optional[Union[str, Path]] = None) -> bytes:
        return self.vision.screenshot(save_path)

    def enable_ghost_cursor(self) -> AntidetectSession:
        """Injects in-DOM visual tracking cursor for real-time visual inspection."""
        from sammonny.dom.ghost_cursor import GhostCursor
        GhostCursor(self.cdp).enable()
        return self

    def export_cookies(self, format: str = "json") -> Any:

        """Exports cookies either from live CDP or directly from SQLite."""
        try:
            return [c.to_dict() for c in self.live_cookies.get_all_cookies()]
        except Exception:
            if format == "netscape":
                return self.sqlite_cookies.export_netscape()
            return [c.to_dict() for c in self.sqlite_cookies.export_cookies()]

"""
sammonny.signatures.harvester
=============================
Unified Kernel Signature Harvester & Dispatcher.
Seamlessly unifies:
1. In-Browser Live Context Evaluation (via CDP to running Orbita Chromium V8).
2. Profile-Bound Synthetic Signing (via deterministic S-box & telemetry seeds).

Supports dual-mode execution:
- Mode 'auto': attempts in-kernel live signing first; falls back gracefully
  to profile-bound synthetic calculation if browser context is unavailable.
- Mode 'live': strictly enforces in-browser V8 execution.
- Mode 'synthetic': fast, standalone mathematical calculation bound to profile telemetry.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
import time
from typing import Any, Dict, List, Optional, Union

from sammonny.core.cdp import SyncCdpClient
from sammonny.signatures.bytedance_direct import (
    compute_xgorgon,
    compute_xbogus,
    compute_abogus,
    compute_mobile_envelope,
    ttencrypt_payload,
)
from sammonny.signatures.device_context import (
    ProfileDeviceContext,
    get_profile_device_context,
    resolve_idc_endpoint,
)
from sammonny.signatures.kernel_live import CDPLiveSigner

logger = logging.getLogger("sammonny.signatures.harvester")


class KernelSignatureHarvester:
    """
    Unified signature harvester for ByteDance, TikTok, and browser-kernel-bound APIs.
    """

    def __init__(
        self,
        profile_id: str = "default",
        cdp_client: Optional[SyncCdpClient] = None,
        region: str = "US",
        telemetry: Optional[Dict[str, Any]] = None,
        user_agent: Optional[str] = None,
    ) -> None:
        self.profile_id = profile_id
        self.cdp = cdp_client
        self.region = region.upper()
        self.user_agent = user_agent or (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
        )
        self.device_context: ProfileDeviceContext = get_profile_device_context(
            profile_id=self.profile_id,
            region=self.region,
            telemetry=telemetry,
        )
        self.live_signer: Optional[CDPLiveSigner] = (
            CDPLiveSigner(self.cdp) if self.cdp is not None else None
        )

    @classmethod
    def from_profile_id(
        cls,
        profile_id: str,
        daemon_client: Optional[Any] = None,
        region: Optional[str] = None,
        cdp_client: Optional[SyncCdpClient] = None,
        profiles_dir: Optional[Union[str, Path]] = None,
    ) -> KernelSignatureHarvester:
        """
        Factory method to instantiate KernelSignatureHarvester pre-loaded with
        the exact hardware telemetry seeds of a given profile.
        Can run completely offline without an active browser.
        """
        user_agent = None
        telemetry: Dict[str, Any] = {}
        detected_region = region

        # 1. Try querying daemon if available
        if daemon_client is None:
            try:
                from sammonny.core.client import SamMonnyDaemonClient
                daemon_client = SamMonnyDaemonClient()
            except Exception:
                daemon_client = None

        if daemon_client:
            try:
                prof = daemon_client.get_profile(profile_id)
                if prof and isinstance(prof.raw_data, dict):
                    raw = prof.raw_data
                    fp = raw.get("fingerprint", {})
                    nav = fp.get("navigator", {})
                    screen = fp.get("screen", {})
                    webgl = fp.get("webgl", {})

                    user_agent = nav.get("user_agent")
                    telemetry = {
                        "screen_width": screen.get("width", 1920),
                        "screen_height": screen.get("height", 1080),
                        "cpu_cores": nav.get("hardware_concurrency", 8),
                        "memory_gb": nav.get("device_memory", 8),
                        "canvas_noise": fp.get("canvas_noise", 42),
                        "webgl_vendor": webgl.get("vendor", "Google Inc. (Intel)"),
                        "webgl_renderer": webgl.get("renderer", "ANGLE (Intel, Intel(R) Iris(R) Xe Graphics...)"),
                        "platform": nav.get("platform", "Win32"),
                    }
                    tz = fp.get("timezone", {}).get("timezone_id", "")
                    if not detected_region:
                        if "Bangkok" in tz or "Asia" in tz:
                            detected_region = "VN"
                        elif "Europe" in tz or "London" in tz:
                            detected_region = "GB"
            except Exception as e:
                logger.debug("from_profile_id daemon query failed: %s", e)

        # 2. Fallback to local profile directory Preferences JSON
        if not telemetry and profiles_dir:
            pref_file = Path(profiles_dir) / profile_id / "Default" / "Preferences"
            if pref_file.exists():
                try:
                    with open(pref_file, "r", encoding="utf-8") as f:
                        prefs = json.load(f)
                    gl = prefs.get("gologin", {})
                    telemetry = {
                        "screen_width": 1920,
                        "screen_height": 1080,
                        "cpu_cores": 8,
                        "memory_gb": 8,
                        "canvas_noise": gl.get("canvasNoise", 42),
                        "webgl_vendor": "Google Inc. (NVIDIA)",
                        "webgl_renderer": "ANGLE (NVIDIA GeForce RTX)",
                        "platform": "Win32",
                    }
                except Exception:
                    pass

        return cls(
            profile_id=profile_id,
            cdp_client=cdp_client,
            region=detected_region or "US",
            telemetry=telemetry,
            user_agent=user_agent,
        )

    def attach_cdp(self, cdp_client: SyncCdpClient) -> None:
        """Attaches or updates the active CDP client for live signing."""
        self.cdp = cdp_client
        self.live_signer = CDPLiveSigner(cdp_client)

    def warmup_biometrics(self) -> None:
        """Triggers subtle natural biometrics in the running browser tab."""
        if self.live_signer:
            self.live_signer.warmup_biometrics()

    def sign_url(
        self,
        url: str,
        post_data: Optional[Union[bytes, str, Dict[str, Any]]] = None,
        mode: str = "auto",
    ) -> Dict[str, Any]:
        """
        Signs a target URL with X-Bogus, a_bogus, and msToken.
        In 'auto' mode, queries the active browser kernel if available,
        otherwise uses deterministic profile-bound calculation.
        """
        # Try Live Kernel first if available and requested
        if mode in ("auto", "live") and self.live_signer is not None:
            try:
                live_res = self.live_signer.sign_url_live(url)
                if live_res.get("signature") or live_res.get("aBogus"):
                    return live_res
            except Exception as e:
                logger.debug("Live kernel signing failed, falling back to synthetic: %s", e)
                if mode == "live":
                    raise

        # Synthetic signing bound to profile device context
        now_ts = int(time.time())
        body_bytes = None
        if post_data is not None:
            if isinstance(post_data, dict):
                body_bytes = json.dumps(post_data, separators=(",", ":")).encode("utf-8")
            elif isinstance(post_data, str):
                body_bytes = post_data.encode("utf-8")
            else:
                body_bytes = post_data

        parsed = url.split("?", 1)
        base_url = parsed[0]
        query = parsed[1] if len(parsed) > 1 else ""

        x_bogus = compute_xbogus(query, self.user_agent, body_bytes, now_ts)
        a_bogus = compute_abogus(
            query,
            self.user_agent,
            body_bytes,
            now_ts,
            telemetry=self.device_context.telemetry,
        )

        sep = "&" if "?" in url else "?"
        signed_url = (
            f"{url}{sep}msToken={self.device_context.ms_token}"
            f"&X-Bogus={x_bogus}&a_bogus={a_bogus}"
        )

        return {
            "status": "ok",
            "url": signed_url,
            "x_bogus": x_bogus,
            "a_bogus": a_bogus,
            "msToken": self.device_context.ms_token,
            "engine": "profile_bound_synthetic",
        }

    def sign_request(
        self,
        endpoint: str,
        method: str = "GET",
        body: Optional[Union[bytes, str, Dict[str, Any]]] = None,
        cookies: Optional[Dict[str, str]] = None,
        custom_headers: Optional[Dict[str, str]] = None,
        aid: int = 1988,
    ) -> Dict[str, Any]:
        """
        Generates a comprehensive ByteDance HTTP request envelope containing:
        - Signed URL (with appended msToken, X-Bogus, a_bogus)
        - IDC-aware cookies (`store-idc`, `sessionid`)
        - Cryptographic security headers (`X-Gorgon`, `X-Bogus`, `X-ABogus`, `X-Khronos`, `X-SS-REQ-TICKET`)
        - Hardware tokens (`device_id`, `install_id`)
        """
        now_ts = int(time.time())
        body_bytes = None
        if body is not None:
            if isinstance(body, dict):
                body_bytes = json.dumps(body, separators=(",", ":")).encode("utf-8")
            elif isinstance(body, str):
                body_bytes = body.encode("utf-8")
            else:
                body_bytes = body

        # Ensure base query parameters include standard device IDs
        sep = "&" if "?" in endpoint else "?"
        query_supplement = self.device_context.get_query_params(aid=aid)
        full_endpoint = f"{endpoint}{sep}{query_supplement}"

        parsed = full_endpoint.split("?", 1)
        query = parsed[1] if len(parsed) > 1 else ""

        # Format cookie string with guaranteed IDC geo-affinity
        c_dict = dict(cookies or {})
        c_dict.setdefault("store-idc", self.device_context.idc)
        cookie_parts = [f"{k}={v}" for k, v in c_dict.items() if k and not k.startswith("_")]
        cookie_str = "; ".join(cookie_parts)

        # Compute signatures
        x_gorgon = compute_xgorgon(query, body_bytes, cookie_str, now_ts)
        x_bogus = compute_xbogus(query, self.user_agent, body_bytes, now_ts)
        a_bogus = compute_abogus(
            query,
            self.user_agent,
            body_bytes,
            now_ts,
            telemetry=self.device_context.telemetry,
        )

        signed_url = (
            f"{full_endpoint}&msToken={self.device_context.ms_token}"
            f"&X-Bogus={x_bogus}&a_bogus={a_bogus}&_signature={x_gorgon}"
        )

        csrf_token = c_dict.get("passport_csrf_token") or c_dict.get("tt_csrf_token") or f"csrf_{now_ts}"
        # Dynamically extract Chrome major version for sec-ch-ua alignment
        chrome_major = "139"
        if "Chrome/" in self.user_agent:
            try:
                chrome_major = self.user_agent.split("Chrome/")[1].split(".")[0]
            except Exception:
                chrome_major = "139"

        headers = {
            "User-Agent": self.user_agent,
            "Referer": "https://www.tiktok.com/",
            "Content-Type": "application/json",
            "Accept": "application/json, text/plain, */*",
            "Cookie": cookie_str,
            "sec-ch-ua": f'"Not;A=Brand";v="99", "Google Chrome";v="{chrome_major}", "Chromium";v="{chrome_major}"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "X-SecSDK-CSRF-Token": csrf_token,
            "X-TT-Token": csrf_token,
            "X-Khronos": str(now_ts),
            "X-Gorgon": x_gorgon,
            "X-Bogus": x_bogus,
            "X-ABogus": a_bogus,
            "X-SS-REQ-TICKET": f"{now_ts}000",
        }
        if custom_headers:
            headers.update(custom_headers)

        return {
            "status": "ok",
            "url": signed_url,
            "method": method.upper(),
            "headers": headers,
            "body": body_bytes.decode("utf-8") if body_bytes else None,
            "device_id": self.device_context.device_id,
            "install_id": self.device_context.install_id,
            "region": self.device_context.region,
            "idc": self.device_context.idc,
            "engine": "profile_bound_synthetic",
        }

    def execute_live_call(
        self,
        endpoint: str,
        method: str = "POST",
        json_data: Optional[Dict[str, Any]] = None,
        custom_headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Executes an API request directly through the running browser tab's V8 engine
        via `window.fetch()`, inheriting all in-page SecSDK and acrawler state.
        """
        if not self.live_signer:
            raise RuntimeError("Live browser execution requires an active CDP connection.")
        return self.live_signer.execute_in_browser_fetch(
            endpoint=endpoint,
            method=method,
            json_data=json_data,
            custom_headers=custom_headers,
        )

    def sign_mobile(
        self,
        url: str,
        post_data: Optional[Union[bytes, str, Dict[str, Any]]] = None,
        cookies: Optional[Dict[str, str]] = None,
        app_id: int = 1233,
    ) -> Dict[str, Any]:
        """
        Generates full ByteDance / TikTok Mobile Metasec signature header envelope
        (X-Gorgon, X-Khronos, X-Argus, X-Ladon, X-SS-REQ-TICKET) bound to profile device.
        """
        body_bytes: Optional[bytes] = None
        if post_data is not None:
            if isinstance(post_data, dict):
                body_bytes = json.dumps(post_data, separators=(",", ":")).encode("utf-8")
            elif isinstance(post_data, str):
                body_bytes = post_data.encode("utf-8")
            else:
                body_bytes = post_data

        cookie_str: Optional[str] = None
        if cookies:
            cookie_str = "; ".join(f"{k}={v}" for k, v in cookies.items())

        return compute_mobile_envelope(
            url=url,
            post_data=body_bytes,
            cookies=cookie_str,
            device_id=self.device_context.device_id,
            app_id=app_id,
        )

    def encrypt_payload(self, payload: Union[bytes, str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Encrypts request payload using ByteDance proprietary TTEncrypt protocol.
        """
        if isinstance(payload, dict):
            raw = json.dumps(payload, separators=(",", ":"))
        else:
            raw = payload
        return ttencrypt_payload(raw)



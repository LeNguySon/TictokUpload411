"""
sammonny.platforms
==================
High-level vertical platform automation workflows (TikTok, Social, Gaming, E-commerce).
"""

from sammonny.platforms.tiktok import (
    TikTokPipeline,
    TikTokDirectPostClient,
    TikTokHeadlessStudioUploader,
    TikTokPublisherAdapter,
    UploadMode,
    RemoteStatus,
    CapabilityResult,
    DraftResult,
    UploadResult,
)

__all__ = [
    "TikTokPipeline",
    "TikTokDirectPostClient",
    "TikTokHeadlessStudioUploader",
    "TikTokPublisherAdapter",
    "UploadMode",
    "RemoteStatus",
    "CapabilityResult",
    "DraftResult",
    "UploadResult",
]

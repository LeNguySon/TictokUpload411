"""
Unified Antidetect Session.
High-level reusable context manager providing fluent access to DOM, Vision,
Mouse, Cookies, Navigation, and Screenshot operations on an active profile.
"""

from __future__ import annotations
import time
from pathlib import Path
from typing import Optional, Union, Any, Dict, List

from sammonny.core.cdp import SyncCdpClient
from sammonny.core.client import SamMonnyDaemonClient
from sammonny.core.models import Point, Rect, CookieItem
from sammonny.dom.controller import DOMController
from sammonny.dom.stealth_controller import StealthDOMController, HoneypotDetectedError
from sammonny.dom.mouse import HumanMouse
from sammonny.vision.locator import ImageLocator
from sammonny.cookies.cdp_extractor import CdpCookieClient
from sammonny.cookies.sqlite_manager import CookieSqliteManager
from sammonny.network.monitor import NetworkMonitor
from sammonny.network.kernel_http import KernelHttpClient, KernelResponse
from sammonny.system.memory_scanner import ProcessMemoryScanner
from sammonny.signatures.harvester import KernelSignatureHarvester

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False


class AntidetectSession:
    """Fluent, reusable execution session for a single browser profile."""

    def __init__(
        self,
        profile_id: str,
        daemon_client: SamMonnyDaemonClient,
        ws_url: Optional[str] = None,
        profile_dir: Optional[Path] = None,
        auto_stop_on_exit: bool = True,
        headless: bool = False,
    ):
        self.profile_id = profile_id
        self.daemon = daemon_client
        self.ws_url = ws_url
        self.profile_dir = profile_dir or (Path("profiles") / profile_id)
        self.auto_stop = auto_stop_on_exit
        self.headless = headless

        self._cdp: Optional[SyncCdpClient] = None
        self._dom: Optional[DOMController] = None
        self._stealth_dom: Optional[StealthDOMController] = None
        self._mouse: Optional[HumanMouse] = None
        self._vision: Optional[ImageLocator] = None
        self._cookies: Optional[CdpCookieClient] = None
        self._offline_cookies: Optional[CookieSqliteManager] = None
        self._network: Optional[NetworkMonitor] = None
        self._memory: Optional[ProcessMemoryScanner] = None
        self._signatures: Optional[KernelSignatureHarvester] = None
        self._http: Optional[KernelHttpClient] = None
        self._interceptor: Optional[KernelRequestInterceptor] = None
        self._tab_manager: Optional[Any] = None
        self._job_supervisor: Optional[Any] = None
        self._circuit_breaker: Optional[Any] = None
        self._headless_agent: Optional[Any] = None
        self._tab_pool: Optional[Any] = None
        self._action_engine: Optional[Any] = None
        self._network_idle_observer: Optional[Any] = None
        self._spa_observer: Optional[Any] = None
        self._canvas_inspector: Optional[Any] = None
        self._browser_pid: Optional[int] = None

    def _resolve_browser_pid(self) -> Optional[int]:
        # 1. Check daemon startup response first
        try:
            info = self.daemon.get_last_started_profile_info(self.profile_id)
            pid = info.get("pid")
            if pid and isinstance(pid, int) and pid > 0:
                return pid
        except Exception:
            pass

        # 2. Check psutil network connections
        if not self.ws_url or not HAS_PSUTIL:
            return None
        try:
            clean = self.ws_url.replace("ws://", "").replace("wss://", "")
            host_port = clean.split("/")[0]
            if ":" in host_port:
                port = int(host_port.split(":")[1])
                for conn in psutil.net_connections():
                    if conn.laddr and conn.laddr.port == port:
                        return conn.pid
        except Exception:
            pass
        return None

    @property
    def browser_pid(self) -> Optional[int]:
        """Root PID of the running browser process."""
        if not self._browser_pid:
            self._browser_pid = self._resolve_browser_pid()
        return self._browser_pid

    @property
    def pid(self) -> Optional[int]:
        """Alias for browser_pid."""
        return self.browser_pid

    def start(self, headless: Optional[bool] = None) -> AntidetectSession:
        is_headless = self.headless if headless is None else headless
        if not self.ws_url:
            self.ws_url = self.daemon.start_profile(self.profile_id, headless=is_headless)

        self._cdp = SyncCdpClient(self.ws_url).connect()
        self._mouse = HumanMouse(self._cdp)
        self._dom = DOMController(self._cdp, self._mouse)
        self._stealth_dom = StealthDOMController(self._cdp, self._mouse)
        self._vision = ImageLocator(self._cdp, self._mouse)
        self._cookies = CdpCookieClient(self._cdp)
        self._offline_cookies = CookieSqliteManager(self.profile_dir)

        # Network Monitor
        self._network = NetworkMonitor(self._cdp)
        self._network.enable()

        # In-Memory RAM Scanner & Win32 Job Object Supervision
        self._browser_pid = self._resolve_browser_pid()
        if self._browser_pid:
            self._memory = ProcessMemoryScanner(self._browser_pid)
            try:
                from sammonny.system.job import WindowsJobSupervisor
                self._job_supervisor = WindowsJobSupervisor()
                self._job_supervisor.assign_process(self._browser_pid)
            except Exception:
                pass

        # In-Kernel & Profile-Bound Signature Harvester
        self._signatures = KernelSignatureHarvester(profile_id=self.profile_id, cdp_client=self._cdp)

        # In-Kernel Browser Network Client
        self._http = KernelHttpClient(self._cdp, session=self)

        return self

    def close(self) -> None:
        if self._tab_pool:
            try:
                self._tab_pool.close_all()
            except Exception:
                pass
            self._tab_pool = None

        if self._interceptor:
            try:
                self._interceptor.disable()
            except Exception:
                pass
            self._interceptor = None

        if self._network:
            try:
                self._network.disable()
            except Exception:
                pass
            self._network = None

        if self._cdp:
            try:
                self._cdp.close()
            except Exception:
                pass
            self._cdp = None

        if self.auto_stop:
            try:
                self.daemon.stop_profile(self.profile_id)
            except Exception:
                pass

    def stop(self) -> None:
        """Alias for close()."""
        self.close()

    def __enter__(self) -> AntidetectSession:
        return self.start()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    # =========================================================================
    # Subsystem Properties
    # =========================================================================

    @property
    def cdp(self) -> SyncCdpClient:
        if not self._cdp:
            raise RuntimeError("Session is not active. Call .start() or use 'with' context manager.")
        return self._cdp

    @property
    def dom(self) -> DOMController:
        if not self._dom:
            raise RuntimeError("Session is not active.")
        return self._dom

    @property
    def mouse(self) -> HumanMouse:
        if not self._mouse:
            raise RuntimeError("Session is not active.")
        return self._mouse

    @property
    def vision(self) -> ImageLocator:
        if not self._vision:
            raise RuntimeError("Session is not active.")
        return self._vision

    @property
    def live_cookies(self) -> CdpCookieClient:
        if not self._cookies:
            raise RuntimeError("Session is not active.")
        return self._cookies

    @property
    def sqlite_cookies(self) -> CookieSqliteManager:
        if not self._offline_cookies:
            self._offline_cookies = CookieSqliteManager(self.profile_dir)
        return self._offline_cookies

    @property
    def network(self) -> NetworkMonitor:
        """Real-time network traffic monitor & WebSocket frame sniffer."""
        if not self._network:
            raise RuntimeError("Session is not active.")
        return self._network

    @property
    def stealth_dom(self) -> StealthDOMController:
        """Stealth DOM controller with Anti-Bot honeypot neutralization."""
        if not self._stealth_dom:
            raise RuntimeError("Session is not active.")
        return self._stealth_dom

    @property
    def memory(self) -> Optional[ProcessMemoryScanner]:
        """Win32 in-memory RAM scanner for the running browser process."""
        if not self._memory:
            self._browser_pid = self._resolve_browser_pid()
            if self._browser_pid:
                self._memory = ProcessMemoryScanner(self._browser_pid)
        return self._memory

    def trim_memory(self):
        """Trims working set memory for all browser processes in the session tree."""
        from sammonny.system.memory import MemoryManager
        pid = self._resolve_browser_pid()
        if not pid:
            return None
        return MemoryManager.trim_process_tree_memory(pid)

    def get_working_set_ram(self) -> Optional[float]:
        """Returns total working set memory in MB for the browser process tree."""
        from sammonny.system.memory import MemoryManager
        pid = self._resolve_browser_pid()
        if not pid:
            return None
        try:
            tree_info = MemoryManager.get_process_tree_memory(pid)
            return tree_info.total_rss_mb
        except Exception:
            return None

    @property
    def signatures(self) -> KernelSignatureHarvester:
        """In-Kernel & Profile-Bound Hardware Signature Harvester."""
        if not self._signatures:
            self._signatures = KernelSignatureHarvester(profile_id=self.profile_id, cdp_client=self._cdp)
        return self._signatures

    @property
    def http(self) -> KernelHttpClient:
        """In-Kernel HTTP Client. Sends outgoing requests through Chromium network stack."""
        if not self._http:
            self._http = KernelHttpClient(self.cdp, session=self)
        return self._http

    @property
    def wasm(self):
        """WebAssembly Linear Memory & V8 ArrayBuffer Inspector."""
        from sammonny.memory.wasm_inspector import WasmMemoryInspector
        return WasmMemoryInspector(self.cdp)

    @property
    def fonts(self):
        """Sub-pixel Font Glyph Metrics & Anti-Fingerprinting Guard."""
        from sammonny.fingerprint.font_guard import FontMetricsGuard
        return FontMetricsGuard(self.cdp)

    @property
    def canvas(self):
        """2D Canvas Alpha Purity & Noise Tampering Auditor."""
        from sammonny.fingerprint.canvas_guard import CanvasGuard
        return CanvasGuard(self.cdp)

    @property
    def webgl(self):
        """WebGL Hardware Renderer & Shader Precision Parity Auditor."""
        from sammonny.fingerprint.webgl_guard import WebGLGuard
        return WebGLGuard(self.cdp)

    @property
    def connections(self):
        """Chromium Socket Pool, Preconnect & TLS Session Ticket Supervisor."""
        from sammonny.network.connection_pool import KernelConnectionPool
        return KernelConnectionPool(self.cdp)

    @property
    def interceptor(self):
        """In-Kernel Request Interceptor & Payload Injector (Zero DOM/V8 visibility)."""
        from sammonny.network.interceptor import KernelRequestInterceptor
        if not self._interceptor:
            self._interceptor = KernelRequestInterceptor(self.cdp)
        return self._interceptor

    @property
    def tabs(self):
        """Multi-tab, popup window & OAuth dialog supervisor."""
        from sammonny.core.tab_manager import TabManager
        if not self._tab_manager:
            self._tab_manager = TabManager(self)
        return self._tab_manager

    def _switch_cdp(self, ws_url: str) -> None:
        """Dynamically rebinds CDP connection and controllers to a new tab WebSocket."""
        if self.ws_url == ws_url and self._cdp and self._cdp._running:
            return

        if self._interceptor:
            try:
                self._interceptor.disable()
            except Exception:
                pass
            self._interceptor = None

        if self._network:
            try:
                self._network.disable()
            except Exception:
                pass
            self._network = None

        if self._cdp:
            try:
                self._cdp.close()
            except Exception:
                pass

        self.ws_url = ws_url
        self._cdp = SyncCdpClient(ws_url).connect()
        self._mouse = HumanMouse(self._cdp)
        self._dom = DOMController(self._cdp, self._mouse)
        self._stealth_dom = StealthDOMController(self._cdp, self._mouse)
        self._vision = ImageLocator(self._cdp, self._mouse)
        self._cookies = CdpCookieClient(self._cdp)
        self._network = NetworkMonitor(self._cdp)
        self._signatures = KernelSignatureHarvester(profile_id=self.profile_id, cdp_client=self._cdp)
        self._http = KernelHttpClient(self._cdp, session=self)

    @property
    def auditor(self):
        from sammonny.vpn.audit import NetworkLeakAuditor
        return NetworkLeakAuditor(self.cdp)

    @property
    def circuit_breaker(self):
        """Automated network health supervisor & proxy failover circuit breaker."""
        from sammonny.network.circuit_breaker import NetworkCircuitBreaker
        if not self._circuit_breaker:
            self._circuit_breaker = NetworkCircuitBreaker()
        return self._circuit_breaker

    @property
    def audio(self):
        """Web Audio API & AudioContext Parity Auditor."""
        from sammonny.fingerprint.audio_guard import AudioGuard
        return AudioGuard(self.cdp)

    @property
    def hygiene(self):
        """V8 Runtime & CDP Anti-Detection Hygiene Auditor (Zero CDP Leakage)."""
        from sammonny.fingerprint.hygiene_guard import RuntimeHygieneGuard
        return RuntimeHygieneGuard(self.cdp)

    @property
    def scroller(self):
        """Human Inertial Mouse-Wheel & Touchpad Scrolling Kinematics."""
        from sammonny.dom.scroller import HumanScroller
        return HumanScroller(self.cdp)

    @property
    def indexer(self):
        """AI Agent Interactive Element Indexer & Visual DOM Tree Parser."""
        from sammonny.dom.indexer import DOMIndexer
        return DOMIndexer(self.cdp, session=self)

    @property
    def telemetry(self):
        """Real-time Anti-Bot Telemetry Decoder & Surveillance Supervisor."""
        from sammonny.network.telemetry_supervisor import TelemetrySupervisor
        return TelemetrySupervisor(self)

    @property
    def headless_agent(self):
        """Headless Agent Accelerator & High-Throughput Resource Interceptor."""
        from sammonny.headless.accelerator import HeadlessAgentAccelerator
        if not self._headless_agent:
            self._headless_agent = HeadlessAgentAccelerator(self.cdp, session=self)
        return self._headless_agent

    @property
    def headless_mode(self):
        """Alias for headless_agent."""
        return self.headless_agent

    @property
    def tab_pool(self):
        """Headless Tab Pool for multi-tab concurrency within this browser session."""
        from sammonny.headless.tab_pool import HeadlessTabPool
        if not self._tab_pool:
            self._tab_pool = HeadlessTabPool(self)
        return self._tab_pool

    @property
    def tabs(self):
        """Lists active secondary tabs managed by the tab pool."""
        return self.tab_pool.list_tabs()

    @property
    def actions(self):
        """Autonomous AI Agent Action Engine (click, type, scroll, hover, press_key)."""
        from sammonny.headless.actions import AutonomousActionEngine
        if not self._action_engine:
            self._action_engine = AutonomousActionEngine(
                self.cdp,
                mouse=self.mouse,
                accelerator=self.headless_agent,
                session=self,
            )
        return self._action_engine

    @property
    def canvas(self):
        """Offscreen HTML5 Canvas & WebGL Inspector for headless environments."""
        from sammonny.headless.canvas import HeadlessCanvasInspector
        if not self._canvas_inspector:
            self._canvas_inspector = HeadlessCanvasInspector(self.cdp, mouse=self.mouse, session=self)
        return self._canvas_inspector

    @property
    def network_idle_observer(self):
        """Network Idle Observer."""
        from sammonny.headless.observer import NetworkIdleObserver
        if not self._network_idle_observer:
            self._network_idle_observer = NetworkIdleObserver(self.cdp)
        return self._network_idle_observer

    @property
    def spa_observer(self):
        """SPA DOM and Condition Observer."""
        from sammonny.headless.observer import SPAConditionObserver
        if not self._spa_observer:
            self._spa_observer = SPAConditionObserver(self.cdp)
        return self._spa_observer

    def open_tab(self, url: str = "about:blank"):
        """Opens a new headless tab with its own dedicated CDP client and accelerator."""
        return self.tab_pool.open_tab(url)

    def close_tab(self, tab_or_id):
        """Closes a secondary tab by instance or target ID."""
        return self.tab_pool.close_tab(tab_or_id)

    def parallel_map(self, items: list, worker_fn, max_concurrency: int = 4) -> list:
        """Executes tasks in parallel across pooled headless tabs within this browser instance."""
        return self.tab_pool.parallel_map(items, worker_fn, max_concurrency=max_concurrency)

    def act(
        self,
        action: str,
        target: Optional[Union[str, int]] = None,
        value: Optional[str] = None,
        timeout_sec: float = 10.0,
    ):
        """
        Executes an autonomous action (click, type, scroll, hover, press_key, navigate, wait).
        Target seamlessly resolves AX IDs ('AX-15', 15), CSS selectors, XPath, or text matches.
        """
        return self.actions.act(action=action, target=target, value=value, timeout_sec=timeout_sec)

    def get_agent_state(self, with_screenshot: bool = False):
        """Synthesizes a complete multi-modal snapshot for AI agents in a single round-trip."""
        return self.actions.get_agent_state(with_screenshot=with_screenshot)

    def wait_for_network_idle(self, idle_threshold_sec: float = 0.5, timeout_sec: float = 10.0) -> bool:
        """Waits until all in-flight network requests finish and network is idle."""
        return self.network_idle_observer.wait_for_idle(
            idle_threshold_sec=idle_threshold_sec,
            timeout_sec=timeout_sec,
        )

    def wait_for_selector(self, selector: str, timeout_sec: float = 10.0, visible_only: bool = True) -> bool:
        """Waits until CSS selector exists and is visible in DOM."""
        return self.spa_observer.wait_for_selector(
            selector=selector,
            timeout_sec=timeout_sec,
            visible_only=visible_only,
        )

    def wait_for_condition(self, predicate_js: str, timeout_sec: float = 10.0) -> Any:
        """Evaluates JavaScript condition in isolated world until truthy."""
        return self.spa_observer.wait_for_predicate(predicate_js=predicate_js, timeout_sec=timeout_sec)

    def inspect_canvas(self, selector: str = "canvas") -> Dict[str, Any]:
        """Inspects offscreen canvas element and its WebGL rendering context."""
        return self.canvas.get_canvas_info(selector=selector)

    def extract_markdown(self) -> str:
        """Extracts clean, structured Markdown from the current page DOM for LLM context."""
        return self.headless_agent.extract_markdown()

    def get_accessibility_tree(self, interactive_only: bool = True):
        """Extracts semantic Accessibility (a11y) tree from Chromium for AI Agent action decisions."""
        return self.headless_agent.get_accessibility_tree(interactive_only=interactive_only)

    def format_a11y_tree(self, max_nodes: int = 50) -> str:
        """Formats Accessibility tree into a compact prompt string for LLM navigation."""
        return self.headless_agent.format_a11y_tree(max_nodes=max_nodes)

    def block_resources(self, preset_or_patterns: Union[str, List[str]] = "text_only") -> AntidetectSession:
        """Blocks heavy assets (images, media, fonts, css) via CDP to slash RAM & bandwidth by 70-80%."""
        self.headless_agent.block_resources(preset_or_patterns)
        return self

    def unblock_resources(self) -> AntidetectSession:
        """Restores unrestricted network resource loading."""
        self.headless_agent.unblock_resources()
        return self

    def audit_headless_stealth(self) -> Dict[str, Any]:
        """Runs comprehensive 8-vector headless anti-detection and offscreen rendering audit."""
        return self.headless_agent.audit_stealth()

    def monitor_telemetry(self, timeout_sec: float = 3.0, min_reports: int = 1):
        """Blocks and captures anti-bot surveillance beacons (Akamai, DataDome, Cloudflare, ByteDance, etc.)."""
        return self.telemetry.capture(timeout_sec=timeout_sec, min_reports=min_reports)

    def audit_telemetry_exposure(self):
        """Synthesizes an anti-surveillance exposure and C++ kernel defense mitigation audit."""
        return self.telemetry.audit_exposure()

    def scroll(self, delta_y: int, delta_x: int = 0, duration: float = 0.8) -> AntidetectSession:
        """Executes human-like inertial scrolling with cubic ease-out kinematics."""
        self.scroller.scroll(delta_y=delta_y, delta_x=delta_x, duration=duration)
        return self

    def scroll_into_view(self, selector: str) -> bool:
        """Smoothly scrolls the page until target element is safely inside the viewport."""
        return self.scroller.scroll_into_view(selector)

    def get_interactive_elements(self):
        """Discovers and indexes all visible interactive elements for AI Agent navigation."""
        return self.indexer.scan()

    def click_index(self, index: int, style: str = "minimum_jerk") -> Point:
        """Clicks an element by its numeric index using human kinematics."""
        return self.indexer.click_index(index, style=style)

    def type_index(self, index: int, text: str, wpm: float = 85.0) -> AntidetectSession:
        """Focuses and types text into an element by its numeric index."""
        self.indexer.type_index(index, text, wpm=wpm)
        return self

    def audit_leaks(self):
        """Runs preflight security leak audit (WebRTC, DNS, IPv6)."""
        return self.auditor.audit_full()


    # =========================================================================
    # Fluent Shortcuts
    # =========================================================================

    def goto(self, url: str) -> AntidetectSession:
        self.cdp.navigate(url)
        time.sleep(1.0)
        return self

    def navigate(self, url: str) -> AntidetectSession:
        """Alias for goto(). Navigates session to destination URL."""
        return self.goto(url)

    def evaluate(self, expression: str) -> Any:
        """Evaluates JavaScript expression in main page."""
        return self.cdp.evaluate(expression)

    def click(self, target: Union[str, Path], style: str = "minimum_jerk") -> Point:
        """
        Smart click:
        - If target is a file path or ends with .png/.jpg, uses Computer Vision template matching.
        - Otherwise, treats target as a CSS selector in DOM with Honeypot protection.
        """
        return self.smart_click(target, style=style)

    def smart_click(self, target: Union[str, Path], style: str = "minimum_jerk", timeout: float = 10.0) -> Point:
        """
        Anti-Bot Immune Dual-Engine Smart Click:
        1. If target is an image file path, executes 100% DOM-less Optical Computer Vision.
        2. Otherwise, validates target element against honeypot filters (0x0, hidden, offscreen traps),
           and executes Minimum Jerk Quintic Spline with 2D Gaussian sampling.
        """
        target_str = str(target)
        if target_str.endswith((".png", ".jpg", ".jpeg", ".webp")) or Path(target_str).exists():
            return self.vision.click_image(target_str, style=style, timeout=timeout)
        try:
            return self.stealth_dom.click(target_str, style=style, timeout=timeout)
        except Exception:
            return self.dom.click(target_str, style=style, timeout=timeout)

    def type(self, selector: str, text: str, wpm: float = 85.0) -> AntidetectSession:
        self.dom.type_text(selector, text, wpm=wpm)
        return self

    def screenshot(self, save_path: Optional[Union[str, Path]] = None) -> bytes:
        return self.vision.screenshot(save_path)

    def enable_ghost_cursor(self) -> AntidetectSession:
        """Injects in-DOM visual tracking cursor for real-time visual inspection."""
        from sammonny.dom.ghost_cursor import GhostCursor
        GhostCursor(self.cdp).enable()
        return self

    def export_cookies(self, format: str = "json") -> Any:

        """Exports cookies either from live CDP or directly from SQLite."""
        try:
            return [c.to_dict() for c in self.live_cookies.get_all_cookies()]
        except Exception:
            if format == "netscape":
                return self.sqlite_cookies.export_netscape()
            return [c.to_dict() for c in self.sqlite_cookies.export_cookies()]

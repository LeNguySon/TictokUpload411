"""
Core Data Models for SamMonny Antidetect Python SDK.
"""

from __future__ import annotations
import math
import random
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List


@dataclass
class Point:
    x: float
    y: float

    def distance_to(self, other: Point) -> float:
        return math.hypot(self.x - other.x, self.y - other.y)

    def as_dict(self) -> Dict[str, float]:
        return {"x": round(self.x, 2), "y": round(self.y, 2)}


@dataclass
class Rect:
    x: float
    y: float
    width: float
    height: float

    @property
    def center(self) -> Point:
        return Point(self.x + self.width / 2.0, self.y + self.height / 2.0)

    def contains(self, pt: Point) -> bool:
        return (
            self.x <= pt.x <= self.x + self.width
            and self.y <= pt.y <= self.y + self.height
        )

    def sample_human_point(self, safe_ratio: float = 0.6) -> Point:
        """
        Samples a realistic human click coordinate using a truncated 2D Gaussian distribution.
        Disperses points around center without hitting the exact centroid (defeats honeypots).
        Clamps to the safe inner box (default 20% to 80% of width/height).
        """
        sigma_x = max(1.0, self.width / 6.0)
        sigma_y = max(1.0, self.height / 6.0)
        c = self.center

        # Box-Muller transform
        u1 = max(1e-7, random.random())
        u2 = max(1e-7, random.random())
        z0 = math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)
        z1 = math.sqrt(-2.0 * math.log(u1)) * math.sin(2.0 * math.pi * u2)

        raw_x = c.x + z0 * sigma_x
        raw_y = c.y + z1 * sigma_y

        margin = (1.0 - safe_ratio) / 2.0
        min_x = self.x + self.width * margin
        max_x = self.x + self.width * (1.0 - margin)
        min_y = self.y + self.height * margin
        max_y = self.y + self.height * (1.0 - margin)

        return Point(
            x=min(max(raw_x, min_x), max_x),
            y=min(max(raw_y, min_y), max_y),
        )

    def as_dict(self) -> Dict[str, float]:
        return {
            "x": round(self.x, 2),
            "y": round(self.y, 2),
            "width": round(self.width, 2),
            "height": round(self.height, 2),
        }


@dataclass(init=False)
class CookieItem:
    name: str
    value: str
    domain: str
    path: str = "/"
    expirationDate: Optional[float] = None
    secure: bool = False
    httpOnly: bool = False
    sameSite: str = "Lax"

    def __init__(
        self,
        name: str,
        value: str,
        domain: str,
        path: str = "/",
        expirationDate: Optional[float] = None,
        secure: bool = False,
        httpOnly: bool = False,
        sameSite: str = "Lax",
        # Pythonic snake_case aliases:
        http_only: Optional[bool] = None,
        same_site: Optional[str] = None,
        expiration_date: Optional[float] = None,
        expires: Optional[float] = None,
    ):
        self.name = name
        self.value = value
        self.domain = domain
        self.path = path
        self.secure = bool(secure)
        self.httpOnly = bool(http_only if http_only is not None else httpOnly)
        self.sameSite = same_site if same_site is not None else sameSite
        self.expirationDate = (
            expiration_date
            if expiration_date is not None
            else (expires if expires is not None else expirationDate)
        )

    @property
    def http_only(self) -> bool:
        return self.httpOnly

    @http_only.setter
    def http_only(self, val: bool) -> None:
        self.httpOnly = val

    @property
    def same_site(self) -> str:
        return self.sameSite

    @same_site.setter
    def same_site(self, val: str) -> None:
        self.sameSite = val

    @property
    def expiration_date(self) -> Optional[float]:
        return self.expirationDate

    @expiration_date.setter
    def expiration_date(self, val: Optional[float]) -> None:
        self.expirationDate = val

    def to_dict(self) -> Dict[str, Any]:
        data: Dict[str, Any] = {
            "name": self.name,
            "value": self.value,
            "domain": self.domain,
            "path": self.path,
            "secure": self.secure,
            "httpOnly": self.httpOnly,
            "sameSite": self.sameSite,
        }
        if self.expirationDate is not None:
            data["expirationDate"] = self.expirationDate
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> CookieItem:
        return cls(
            name=data.get("name", ""),
            value=data.get("value", ""),
            domain=data.get("domain", ""),
            path=data.get("path", "/"),
            expirationDate=data.get("expirationDate") or data.get("expiration_date") or data.get("expires"),
            secure=bool(data.get("secure", False)),
            httpOnly=bool(data.get("httpOnly") if data.get("httpOnly") is not None else data.get("http_only", False)),
            sameSite=data.get("sameSite") or data.get("same_site", "Lax"),
        )


@dataclass
class ProfileInfo:
    id: str
    name: str
    os: str = "win"
    proxy: Optional[str] = None
    status: str = "stopped"
    port: Optional[int] = None
    ws_url: Optional[str] = None
    raw_data: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TemplateMatchResult:
    bounds: Rect
    confidence: float
    scale: float
    click_point: Point

    @property
    def rect(self) -> Rect:
        """Alias for bounds."""
        return self.bounds


@dataclass
class ProxyHealthResult:
    is_alive: bool
    latency_ms: float
    egress_ip: Optional[str] = None
    country: Optional[str] = None
    city: Optional[str] = None
    timezone: Optional[str] = None
    error: Optional[str] = None


@dataclass
class ProxyItem:
    id: str
    mode: str  # "http", "https", "socks4", "socks5"
    host: str
    port: int
    username: Optional[str] = None
    password: Optional[str] = None
    change_ip_url: Optional[str] = None
    name: Optional[str] = None
    country: Optional[str] = None
    latency_ms: Optional[float] = None
    is_alive: bool = True
    last_checked: Optional[float] = None

    def to_url(self) -> str:
        if self.username and self.password:
            return f"{self.mode}://{self.username}:{self.password}@{self.host}:{self.port}"
        return f"{self.mode}://{self.host}:{self.port}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "mode": self.mode,
            "host": self.host,
            "port": self.port,
            "username": self.username,
            "password": self.password,
            "change_ip_url": self.change_ip_url,
            "name": self.name,
            "country": self.country,
            "latency_ms": self.latency_ms,
            "is_alive": self.is_alive,
            "last_checked": self.last_checked,
            "url": self.to_url(),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ProxyItem:
        return cls(
            id=data.get("id", ""),
            mode=data.get("mode", "http").lower(),
            host=data.get("host", ""),
            port=int(data.get("port", 80)),
            username=data.get("username"),
            password=data.get("password"),
            change_ip_url=data.get("change_ip_url"),
            name=data.get("name"),
            country=data.get("country"),
            latency_ms=data.get("latency_ms"),
            is_alive=bool(data.get("is_alive", True)),
            last_checked=data.get("last_checked"),
        )


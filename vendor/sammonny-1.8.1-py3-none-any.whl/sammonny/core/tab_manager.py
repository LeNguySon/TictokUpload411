"""
CDP Multi-Tab & Popup Window Manager.
Supervises tab creation, popup interception, OAuth login flows, and active tab switching.
"""

from __future__ import annotations
import json
import time
import logging
import urllib.request
from typing import List, Optional, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger("sammonny.tabs")


@dataclass
class TabInfo:
    id: str
    type: str
    title: str
    url: str
    ws_url: str
    is_active: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "type": self.type,
            "title": self.title,
            "url": self.url,
            "ws_url": self.ws_url,
            "is_active": self.is_active,
        }


class TabManager:
    """
    Supervises multi-tab, popup windows, and OAuth authentication flows for AntidetectSession.
    """

    def __init__(self, session: Any) -> None:
        self.session = session
        self._current_tab_id: Optional[str] = None

    def _get_devtools_host_port(self) -> str:
        raw_url = getattr(self.session, "ws_url", "") or ""
        clean = raw_url.replace("ws://", "").replace("wss://", "")
        host_port = clean.split("/")[0]
        return host_port or "127.0.0.1:9222"

    def list(self) -> List[TabInfo]:
        """Queries Chrome DevTools HTTP endpoint to enumerate all open page targets."""
        host_port = self._get_devtools_host_port()
        json_url = f"http://{host_port}/json"

        try:
            req = urllib.request.Request(json_url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=3.0) as resp:
                data = json.loads(resp.read().decode("utf-8"))

            tabs: List[TabInfo] = []
            for item in data:
                if item.get("type") == "page":
                    tab_id = item.get("id", "")
                    ws_url = item.get("webSocketDebuggerUrl", "")
                    is_active = (
                        self._current_tab_id == tab_id
                        or (not self._current_tab_id and ws_url == self.session.ws_url)
                    )
                    tabs.append(
                        TabInfo(
                            id=tab_id,
                            type=item.get("type", "page"),
                            title=item.get("title", ""),
                            url=item.get("url", ""),
                            ws_url=ws_url,
                            is_active=is_active,
                        )
                    )
            return tabs
        except Exception as e:
            logger.debug(f"Error enumerating tabs: {e}")
            return []

    def current(self) -> Optional[TabInfo]:
        """Returns the currently active TabInfo."""
        tabs = self.list()
        for t in tabs:
            if t.is_active or (self._current_tab_id and t.id == self._current_tab_id):
                return t
        return tabs[0] if tabs else None

    def new(self, url: str = "about:blank") -> TabInfo:
        """
        Creates a new browser tab via CDP Target.createTarget and activates it.
        """
        res = self.session.cdp.send("Target.createTarget", {"url": url})
        target_id = res.get("targetId")

        # Allow tab to initialize
        time.sleep(0.3)
        tabs = self.list()
        new_tab = next((t for t in tabs if t.id == target_id), None)
        if not new_tab and tabs:
            new_tab = tabs[-1]

        if new_tab:
            self.switch_to(new_tab.id)
            return new_tab
        raise RuntimeError(f"Failed to create and discover new tab with url: {url}")

    def switch_to(self, target_id_or_title: str) -> TabInfo:
        """
        Switches AntidetectSession CDP context to target tab by target ID or title substring.
        """
        tabs = self.list()
        target = next(
            (t for t in tabs if t.id == target_id_or_title or target_id_or_title.lower() in t.title.lower()),
            None,
        )
        if not target:
            raise ValueError(f"No tab found matching '{target_id_or_title}'")

        try:
            self.session.cdp.send("Target.activateTarget", {"targetId": target.id})
        except Exception:
            pass

        self._current_tab_id = target.id
        self.session._switch_cdp(target.ws_url)
        return target

    def switch_to_popup(self, timeout: float = 5.0) -> TabInfo:
        """
        Waits for a newly spawned popup window (e.g. OAuth dialog) and switches context to it.
        """
        main_tab_id = self._current_tab_id or (self.current().id if self.current() else None)
        deadline = time.time() + timeout

        while time.time() < deadline:
            tabs = self.list()
            for t in tabs:
                if t.id != main_tab_id:
                    return self.switch_to(t.id)
            time.sleep(0.2)

        raise TimeoutError(f"No popup window detected within {timeout}s")

    def close(self, target_id: Optional[str] = None) -> bool:
        """Closes target tab and returns to the primary tab if active."""
        tid = target_id or self._current_tab_id
        if not tid:
            return False

        try:
            self.session.cdp.send("Target.closeTarget", {"targetId": tid})
        except Exception as e:
            logger.warning(f"Failed to close tab {tid}: {e}")
            return False

        time.sleep(0.2)
        remaining = self.list()
        if remaining:
            self.switch_to(remaining[0].id)
        return True


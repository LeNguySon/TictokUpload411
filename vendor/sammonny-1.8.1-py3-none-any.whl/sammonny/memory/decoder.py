"""
In-Memory Payload Decoders & Deserializers.
Decodes MessagePack, XOR obfuscation, Base64 chunked buffers, and structured network packets.
"""

from __future__ import annotations
import base64
import json
import re
from typing import Any, Dict, List, Optional, Union

try:
    import msgpack
    HAS_MSGPACK = True
except ImportError:
    HAS_MSGPACK = False


class MemoryDecoder:
    """Decodes in-memory obfuscated and serialized payloads."""

    @staticmethod
    def xor_decrypt(data: Union[bytes, bytearray], key: Union[bytes, str, int]) -> bytes:
        """Decrypts XOR-obfuscated byte buffers."""
        if isinstance(key, str):
            key_bytes = key.encode("utf-8")
        elif isinstance(key, int):
            key_bytes = bytes([key & 0xFF])
        else:
            key_bytes = key

        if not key_bytes:
            return bytes(data)

        key_len = len(key_bytes)
        return bytes([b ^ key_bytes[i % key_len] for i, b in enumerate(data)])

    @staticmethod
    def decode_base64(data: Union[str, bytes]) -> bytes:
        """Decodes standard or URL-safe base64 strings with automatic padding."""
        s = data.decode("utf-8") if isinstance(data, bytes) else str(data)
        s = s.strip()
        # Add required padding
        missing_padding = len(s) % 4
        if missing_padding:
            s += "=" * (4 - missing_padding)
        return base64.b64decode(s.replace("-", "+").replace("_", "/"))

    @staticmethod
    def decode_msgpack(data: bytes) -> Optional[Any]:
        """Decodes Cocos Creator / SystemJS MessagePack binary frames."""
        if not HAS_MSGPACK:
            return None
        try:
            return msgpack.unpackb(data, raw=False)
        except Exception:
            return None

    @staticmethod
    def extract_strings(data: bytes, min_len: int = 4) -> List[str]:
        """Extracts ASCII/UTF-8 readable string sequences from raw memory bytes."""
        result: List[str] = []
        current: List[int] = []

        for b in data:
            if 32 <= b <= 126 or b in (9, 10, 13):
                current.append(b)
            else:
                if len(current) >= min_len:
                    result.append(bytes(current).decode("utf-8", errors="ignore"))
                current = []

        if len(current) >= min_len:
            result.append(bytes(current).decode("utf-8", errors="ignore"))

        return result

    @staticmethod
    def decode_hex(data: Union[str, bytes]) -> bytes:
        """Decodes hex strings (ignoring whitespace and optional 0x prefix)."""
        s = data.decode("utf-8") if isinstance(data, bytes) else str(data)
        s = s.strip().replace(" ", "").replace(":", "")
        if s.startswith("0x") or s.startswith("0X"):
            s = s[2:]
        return bytes.fromhex(s)

    @staticmethod
    def decode_rot47(data: str) -> str:
        """Decodes ROT47 obfuscated ASCII strings."""
        result = []
        for char in data:
            code = ord(char)
            if 33 <= code <= 126:
                result.append(chr(33 + ((code + 14) % 94)))
            else:
                result.append(char)
        return "".join(result)

    @staticmethod
    def decompress_stream(data: bytes) -> bytes:
        """Auto-detects and decompresses Gzip (1f 8b) or Zlib (78 9c/da/01) streams."""
        import gzip
        import zlib
        if len(data) >= 2 and data[0] == 0x1F and data[1] == 0x8B:
            try:
                return gzip.decompress(data)
            except Exception:
                pass
        if len(data) >= 2 and data[0] == 0x78 and data[1] in (0x9C, 0xDA, 0x01, 0x5E):
            try:
                return zlib.decompress(data)
            except Exception:
                pass
        return data

    @staticmethod
    def decode_ttencrypt(data: Union[bytes, bytearray, str, Dict[str, Any]]) -> Dict[str, Any]:
        """Decrypts ByteDance TTEncrypt protocol payload."""
        from sammonny.signatures.bytedance_direct import ttdecrypt_payload
        return ttdecrypt_payload(data)

    @classmethod
    def unpack_telemetry_stream(cls, raw_stream: Union[bytes, str]) -> Dict[str, Any]:
        """
        Universal telemetry stream un-packer.
        Automatically recognizes TTEncrypt, Gzip, Zlib, MessagePack, Base64, and JSON envelopes.
        """
        import urllib.parse

        if isinstance(raw_stream, str):
            s = raw_stream.strip()
            # Check TTEncrypt hex magic
            if s.startswith("746305100000"):
                try:
                    dec = cls.decode_ttencrypt(s)
                    return {"format": "ttencrypt", "data": dec.get("json") or dec.get("text"), "meta": dec}
                except Exception:
                    pass
            # Check Base64
            if len(s) > 16 and (s.endswith("=") or re.match(r"^[A-Za-z0-9+/_-]+$", s)):
                try:
                    b = cls.decode_base64(s)
                    decomp = cls.decompress_stream(b)
                    try:
                        parsed = json.loads(decomp.decode("utf-8"))
                        return {"format": "base64_json", "data": parsed}
                    except Exception:
                        return {"format": "base64_raw", "data": decomp}
                except Exception:
                    pass
            # Check URL-encoded
            if "%" in s or "&" in s:
                try:
                    qs = urllib.parse.parse_qs(s)
                    return {"format": "urlencoded", "data": {k: v[0] if len(v) == 1 else v for k, v in qs.items()}}
                except Exception:
                    pass
            # Check JSON
            try:
                parsed = json.loads(s)
                return {"format": "json", "data": parsed}
            except Exception:
                return {"format": "plaintext", "data": s}

        # Raw bytes
        b_data = bytes(raw_stream)
        # Check TTEncrypt magic
        if len(b_data) >= 6 and b_data[:6] == b"\x74\x63\x05\x10\x00\x00":
            dec = cls.decode_ttencrypt(b_data)
            return {"format": "ttencrypt", "data": dec.get("json") or dec.get("text"), "meta": dec}

        # Check compression
        decomp = cls.decompress_stream(b_data)
        if HAS_MSGPACK:
            mp = cls.decode_msgpack(decomp)
            if mp is not None:
                return {"format": "msgpack", "data": mp}

        try:
            parsed = json.loads(decomp.decode("utf-8"))
            return {"format": "json", "data": parsed}
        except Exception:
            strings = cls.extract_strings(decomp)
            return {"format": "binary", "strings": strings[:20], "raw_size": len(decomp)}



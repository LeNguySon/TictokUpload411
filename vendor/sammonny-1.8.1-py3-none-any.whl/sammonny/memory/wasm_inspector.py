"""
sammonny.memory.wasm_inspector
==============================
WebAssembly Linear Memory & V8 ArrayBuffer Inspector.
Enables safe, structured inspection and byte-level manipulation of WebAssembly
linear memory buffers inside running Chromium tabs without crashing the browser:
- Hook and discover all instantiated WebAssembly.Memory buffers in real time.
- Search for byte signatures, encryption keys, and S-boxes in WASM memory.
- Read, write, and dump linear memory regions with hex formatting.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
import logging
from typing import Any, Dict, List, Optional, Union

from sammonny.core.cdp import SyncCdpClient

logger = logging.getLogger("sammonny.memory.wasm_inspector")


@dataclass
class WasmMemoryInfo:
    """Metadata describing an active WebAssembly.Memory linear buffer."""
    index: int
    byte_length: int
    pages: int
    created_at_ms: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "index": self.index,
            "byte_length": self.byte_length,
            "pages": self.pages,
            "created_at_ms": self.created_at_ms,
        }


class WasmMemoryInspector:
    """
    Structured inspector for WebAssembly linear memory and V8 ArrayBuffers.
    Interacts via Chrome DevTools Protocol (CDP) Runtime domain.
    """

    def __init__(self, cdp_client: SyncCdpClient) -> None:
        self.cdp = cdp_client

    def install_hooks(self) -> bool:
        """
        Injects stealth hooks into WebAssembly.Memory, WebAssembly.instantiate,
        and WebAssembly.instantiateStreaming to intercept and register all
        active WASM linear memory buffers in window.__sammonny_wasm_registry.
        """
        js_hook = """
        (() => {
            if (window.__sammonny_wasm_installed) {
                return true;
            }
            if (!Object.prototype.hasOwnProperty.call(window, '__sammonny_wasm_registry')) {
                Object.defineProperty(window, '__sammonny_wasm_registry', {
                    value: [],
                    writable: true,
                    enumerable: false,
                    configurable: false,
                });
            }

            const originalMemory = window.WebAssembly.Memory;
            window.WebAssembly.Memory = function(descriptor) {
                const memInstance = new originalMemory(descriptor);
                window.__sammonny_wasm_registry.push({
                    instance: memInstance,
                    created_at: performance.now(),
                    initial_pages: descriptor ? descriptor.initial : 1
                });
                return memInstance;
            };
            window.WebAssembly.Memory.prototype = originalMemory.prototype;

            // Hook memory.grow() for dynamic re-binding when WASM expands
            if (originalMemory.prototype && originalMemory.prototype.grow) {
                const originalGrow = originalMemory.prototype.grow;
                originalMemory.prototype.grow = function(delta) {
                    const result = originalGrow.call(this, delta);
                    try {
                        const reg = window.__sammonny_wasm_registry;
                        if (reg) {
                            for (let i = 0; i < reg.length; i++) {
                                if (reg[i].instance === this) {
                                    reg[i].initial_pages = Math.floor(this.buffer.byteLength / 65536);
                                    reg[i].last_grown_at = performance.now();
                                }
                            }
                        }
                    } catch (e) {}
                    return result;
                };
            }

            if (window.WebAssembly.instantiate) {
                const originalInstantiate = window.WebAssembly.instantiate;
                window.WebAssembly.instantiate = async function(...args) {
                    const result = await originalInstantiate.apply(this, args);
                    try {
                        const inst = result.instance || result;
                        if (inst && inst.exports) {
                            for (const exp of Object.values(inst.exports)) {
                                if (exp instanceof originalMemory) {
                                    if (!window.__sammonny_wasm_registry.some(r => r.instance === exp)) {
                                        window.__sammonny_wasm_registry.push({
                                            instance: exp,
                                            created_at: performance.now(),
                                            initial_pages: Math.floor(exp.buffer.byteLength / 65536)
                                        });
                                    }
                                }
                            }
                        }
                    } catch (e) {}
                    return result;
                };
            }

            try {
                window.WebAssembly.Memory.toString = () => 'function Memory() { [native code] }';
            } catch (e) {}

            Object.defineProperty(window, '__sammonny_wasm_installed', {
                value: true,
                writable: false,
                enumerable: false,
                configurable: false,
            });
            return true;
        })()
        """
        try:
            res = self.cdp.evaluate(js_hook)
            return bool(res)
        except Exception as e:
            logger.debug("Failed to install WASM hooks: %s", e)
            return False

    def list_memories(self) -> List[WasmMemoryInfo]:
        """Lists all registered active WebAssembly memory buffers."""
        js_code = """
        (() => {
            const list = [];
            const reg = window.__sammonny_wasm_registry || [];
            for (let i = 0; i < reg.length; i++) {
                const item = reg[i];
                if (item && item.instance && item.instance.buffer) {
                    const bytes = item.instance.buffer.byteLength;
                    list.push({
                        index: i,
                        byte_length: bytes,
                        pages: Math.floor(bytes / 65536),
                        created_at_ms: item.created_at
                    });
                }
            }
            return list;
        })()
        """
        try:
            res = self.cdp.evaluate(js_code)
            if isinstance(res, list):
                return [
                    WasmMemoryInfo(
                        index=m["index"],
                        byte_length=m["byte_length"],
                        pages=m["pages"],
                        created_at_ms=m["created_at_ms"],
                    )
                    for m in res
                ]
        except Exception as e:
            logger.debug("list_memories error: %s", e)
        return []

    def read_bytes(
        self,
        memory_index: int = 0,
        offset: int = 0,
        length: int = 256,
    ) -> bytes:
        """
        Reads raw bytes from the specified WebAssembly linear memory buffer.
        Returns bytes object.
        """
        import json as py_json
        js_code = f"""
        (() => {{
            const reg = window.__sammonny_wasm_registry || [];
            if (!reg[{memory_index}] || !reg[{memory_index}].instance) {{
                return null;
            }}
            const buf = reg[{memory_index}].instance.buffer;
            if ({offset} >= buf.byteLength) {{
                return null;
            }}
            const readLen = Math.min({length}, buf.byteLength - {offset});
            const view = new Uint8Array(buf, {offset}, readLen);
            let binary = '';
            for (let i = 0; i < view.byteLength; i++) {{
                binary += String.fromCharCode(view[i]);
            }}
            return btoa(binary);
        }})()
        """
        try:
            b64_res = self.cdp.evaluate(js_code)
            if b64_res:
                return base64.b64decode(b64_res)
        except Exception as e:
            logger.debug("read_bytes error: %s", e)
        return b""

    def write_bytes(
        self,
        memory_index: int,
        offset: int,
        data: bytes,
    ) -> bool:
        """
        Safely writes bytes into the specified WebAssembly linear memory buffer.
        """
        b64_data = base64.b64encode(data).decode("ascii")
        import json as py_json
        js_code = f"""
        (() => {{
            const reg = window.__sammonny_wasm_registry || [];
            if (!reg[{memory_index}] || !reg[{memory_index}].instance) {{
                return false;
            }}
            const buf = reg[{memory_index}].instance.buffer;
            const b64 = {py_json.dumps(b64_data)};
            const binStr = atob(b64);
            const len = binStr.length;
            if ({offset} + len > buf.byteLength) {{
                return false;
            }}
            const view = new Uint8Array(buf);
            for (let i = 0; i < len; i++) {{
                view[{offset} + i] = binStr.charCodeAt(i);
            }}
            return true;
        }})()
        """
        try:
            res = self.cdp.evaluate(js_code)
            return bool(res)
        except Exception as e:
            logger.debug("write_bytes error: %s", e)
            return False

    def search_pattern(
        self,
        pattern: Optional[Union[bytes, str, int]] = None,
        memory_index: Optional[Union[bytes, str, int]] = 0,
        max_matches: int = 10,
    ) -> List[int]:
        """
        Scans WebAssembly linear memory for specific byte sequence or text string.
        Returns a list of matching byte offsets.
        Accepts either search_pattern(pattern, memory_index) or search_pattern(memory_index, pattern).
        """
        if isinstance(pattern, int) and isinstance(memory_index, (bytes, str, bytearray)):
            actual_mem_idx = pattern
            actual_pat = memory_index
        else:
            actual_pat = pattern if pattern is not None else b""
            actual_mem_idx = int(memory_index) if isinstance(memory_index, int) else 0

        target_bytes = actual_pat.encode("utf-8") if isinstance(actual_pat, str) else actual_pat
        b64_pat = base64.b64encode(target_bytes).decode("ascii")
        import json as py_json

        js_code = f"""
        (() => {{
            const reg = window.__sammonny_wasm_registry || [];
            if (!reg[{actual_mem_idx}] || !reg[{actual_mem_idx}].instance) {{
                return [];
            }}
            const buf = reg[{actual_mem_idx}].instance.buffer;
            const u8 = new Uint8Array(buf);
            const patStr = atob({py_json.dumps(b64_pat)});
            const patLen = patStr.length;
            const pat = [];
            for (let i = 0; i < patLen; i++) {{
                pat.push(patStr.charCodeAt(i));
            }}

            const matches = [];
            const maxM = {max_matches};
            const limit = u8.length - patLen;

            for (let i = 0; i <= limit; i++) {{
                if (u8[i] === pat[0]) {{
                    let match = true;
                    for (let j = 1; j < patLen; j++) {{
                        if (u8[i + j] !== pat[j]) {{
                            match = false;
                            break;
                        }}
                    }}
                    if (match) {{
                        matches.push(i);
                        if (matches.length >= maxM) break;
                    }}
                }}
            }}
            return matches;
        }})()
        """
        try:
            res = self.cdp.evaluate(js_code)
            if isinstance(res, list):
                return [int(x) for x in res]
        except Exception as e:
            logger.debug("search_pattern error: %s", e)
        return []

    def dump_hex(
        self,
        memory_index: int = 0,
        offset: int = 0,
        length: int = 256,
    ) -> str:
        """Formats memory region into canonical hexdump format (Offset | Hex | ASCII)."""
        raw = self.read_bytes(memory_index=memory_index, offset=offset, length=length)
        if not raw:
            return "<Empty Memory Region or Index Out of Bounds>"

        lines = []
        for i in range(0, len(raw), 16):
            chunk = raw[i:i + 16]
            hex_part = " ".join(f"{b:02x}" for b in chunk)
            ascii_part = "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)
            lines.append(f"{offset + i:08x}  {hex_part:<48}  |{ascii_part}|")
        return "\n".join(lines)


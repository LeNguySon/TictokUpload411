"""
Automated Network Circuit Breaker & Proxy Failover Supervisor.
Guards long-running automation against dead proxies, Cloudflare 403s, rate-limits (429),
and socket disconnects by dynamically tripping and triggering auto-recovery.
"""

from __future__ import annotations
import time
import logging
import threading
from typing import Optional, Callable, List, Dict, Any

logger = logging.getLogger("sammonny.circuit_breaker")


class CircuitState:
    CLOSED = "CLOSED"        # Normal healthy operation
    OPEN = "OPEN"            # Tripped; traffic halted or proxy rotated
    HALF_OPEN = "HALF_OPEN"  # Recovery testing


class NetworkCircuitBreaker:
    """
    Supervises network request health for AntidetectSession.
    Detects repeated 403 / 407 / 429 / 502 errors and automatically trips failover.
    """

    def __init__(
        self,
        failure_threshold: int = 3,
        recovery_timeout_sec: float = 15.0,
        trigger_status_codes: Optional[List[int]] = None,
        on_trip_callback: Optional[Callable[[NetworkCircuitBreaker], None]] = None,
    ) -> None:
        self.failure_threshold = failure_threshold
        self.recovery_timeout_sec = recovery_timeout_sec
        self.trigger_status_codes = trigger_status_codes or [403, 407, 429, 502, 503, 504]
        self.on_trip_callback = on_trip_callback

        self._lock = threading.RLock()
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time = 0.0
        self.last_trip_time = 0.0
        self.last_error_message = ""
        self.last_status_code = 0

    @property
    def is_healthy(self) -> bool:
        with self._lock:
            if self.state == CircuitState.OPEN:
                # Check if recovery timeout elapsed
                if (time.time() - self.last_trip_time) >= self.recovery_timeout_sec:
                    self.state = CircuitState.HALF_OPEN
                    logger.info("CircuitBreaker transitioned from OPEN to HALF_OPEN (probing recovery).")
                    return True
                return False
            return True

    def record_success(self) -> None:
        """Records a successful HTTP/Network transaction, restoring healthy CLOSED state."""
        with self._lock:
            self.failure_count = 0
            self.success_count += 1
            if self.state != CircuitState.CLOSED:
                self.state = CircuitState.CLOSED
                logger.info("CircuitBreaker restored to CLOSED (Healthy).")

    def record_failure(self, status_code: int = 0, error: str = "") -> bool:
        """
        Records a failed network response or connection error.
        Returns True if the failure triggered the circuit to trip (OPEN).
        """
        with self._lock:
            self.failure_count += 1
            self.last_failure_time = time.time()
            self.last_status_code = status_code
            self.last_error_message = error

            is_critical = status_code in self.trigger_status_codes or "proxy" in error.lower() or "tunnel" in error.lower()
            if self.failure_count >= self.failure_threshold or (is_critical and self.failure_count >= 2):
                self._trip()
                return True
            return False

    def _trip(self) -> None:
        """Trips circuit to OPEN and fires callback."""
        self.state = CircuitState.OPEN
        self.last_trip_time = time.time()
        logger.warning(
            f"CircuitBreaker TRIPPED to OPEN: failure_count={self.failure_count}, "
            f"status={self.last_status_code}, error='{self.last_error_message}'"
        )
        if self.on_trip_callback:
            try:
                self.on_trip_callback(self)
            except Exception as e:
                logger.error(f"Error in CircuitBreaker on_trip callback: {e}")

    def reset(self) -> None:
        """Manually resets circuit breaker to CLOSED."""
        with self._lock:
            self.state = CircuitState.CLOSED
            self.failure_count = 0
            self.last_error_message = ""

    def get_status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "state": self.state,
                "is_healthy": self.is_healthy,
                "failure_count": self.failure_count,
                "success_count": self.success_count,
                "last_status_code": self.last_status_code,
                "last_error": self.last_error_message,
                "last_trip_sec_ago": round(time.time() - self.last_trip_time, 1) if self.last_trip_time > 0 else None,
            }


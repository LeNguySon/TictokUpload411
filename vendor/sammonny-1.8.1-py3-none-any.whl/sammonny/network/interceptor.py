"""
sammonny.network.interceptor
============================
In-Kernel HTTP Request Interceptor & Payload Injector.
Operates at Chromium's native Network Service layer (outside V8 JavaScript context).
Web pages and Anti-Bot scripts (TikTok SecSDK, Cloudflare, DataDome) have 0% visibility
into injected headers, modified query parameters, or altered payloads because the injection
happens downstream of the unprivileged Renderer Process via CDP Fetch.enable.
"""

from __future__ import annotations

import base64
import fnmatch
import json
import logging
import threading
from typing import Any, Callable, Dict, List, Optional, Union

from sammonny.core.cdp import SyncCdpClient

logger = logging.getLogger("sammonny.network.interceptor")


class KernelRequestInterceptor:
    """
    Chromium In-Kernel Network Interceptor & Data Injector.
    Bypasses DOM-level JavaScript anti-bot detection with zero V8 footprint.
    """

    def __init__(self, cdp_client: SyncCdpClient) -> None:
        self.cdp = cdp_client
        self.is_enabled = False
        self._lock = threading.RLock()

        # Rules
        self._header_rules: List[Tuple[str, Dict[str, str]]] = []
        self._body_modifiers: List[Tuple[str, Callable[[Any], Any]]] = []
        self._mock_rules: List[Tuple[str, int, Dict[str, str], bytes]] = []
        self._custom_hooks: List[Tuple[str, Callable[[Dict[str, Any]], Optional[Dict[str, Any]]]]] = []

    def enable(self, url_patterns: Optional[List[str]] = None) -> None:
        """
        Enables in-kernel interception via Chromium CDP Fetch domain.
        Default pattern intercepts all HTTP/HTTPS requests.
        """
        with self._lock:
            if self.is_enabled:
                return

            patterns = []
            if url_patterns:
                for pat in url_patterns:
                    patterns.append({"urlPattern": pat, "requestStage": "Request"})
            else:
                patterns.append({"urlPattern": "*", "requestStage": "Request"})

            self.cdp.on("Fetch.requestPaused", self._on_request_paused)
            try:
                self.cdp.send("Fetch.enable", {"patterns": patterns})
                self.is_enabled = True
                logger.info("KernelRequestInterceptor successfully enabled.")
            except Exception as e:
                logger.error(f"Failed to enable Fetch domain: {e}")

    def disable(self) -> None:
        """Disables in-kernel request interception."""
        with self._lock:
            if not self.is_enabled:
                return
            try:
                self.cdp.send("Fetch.disable", {})
            except Exception:
                pass
            self.is_enabled = False

    def add_headers(self, url_pattern: str, headers: Dict[str, str]) -> None:
        """
        Injects or overwrites outgoing HTTP headers for matching requests.
        Website JavaScript cannot detect this injection.
        """
        with self._lock:
            self._header_rules.append((url_pattern, headers))

    def add_body_modifier(self, url_pattern: str, modifier_fn: Callable[[Any], Any]) -> None:
        """
        Injects or mutates POST/PUT body data for matching requests.
        """
        with self._lock:
            self._body_modifiers.append((url_pattern, modifier_fn))

    def add_mock_response(
        self,
        url_pattern: str,
        status_code: int = 200,
        headers: Optional[Dict[str, str]] = None,
        body: Union[str, bytes] = "",
    ) -> None:
        """
        Fulfills matching requests directly from Chromium kernel memory
        without transmitting bytes over the network.
        """
        body_bytes = body.encode("utf-8") if isinstance(body, str) else body
        h = headers or {"Content-Type": "application/json"}
        with self._lock:
            self._mock_rules.append((url_pattern, status_code, h, body_bytes))

    def add_hook(
        self,
        url_pattern: str,
        hook_fn: Callable[[Dict[str, Any]], Optional[Dict[str, Any]]],
    ) -> None:
        """
        Registers custom hook callback allowing dynamic modification of url, method, headers, or body.
        """
        with self._lock:
            self._custom_hooks.append((url_pattern, hook_fn))

    def _on_request_paused(self, params: Dict[str, Any]) -> None:
        """
        Handles paused request event inside Chromium C++ Network Service.
        """
        req_id = params.get("requestId")
        if not req_id:
            return

        req = params.get("request", {})
        url = req.get("url", "")
        method = req.get("method", "GET")
        raw_headers = req.get("headers", {})

        with self._lock:
            # 1. Check Mock Rules (fulfillRequest)
            for pat, status, m_headers, m_body in self._mock_rules:
                if fnmatch.fnmatch(url, pat):
                    cdp_resp_headers = [{"name": k, "value": v} for k, v in m_headers.items()]
                    b64_body = base64.b64encode(m_body).decode("ascii")
                    try:
                        self.cdp.send("Fetch.fulfillRequest", {
                            "requestId": req_id,
                            "responseCode": status,
                            "responseHeaders": cdp_resp_headers,
                            "body": b64_body,
                        })
                        return
                    except Exception as e:
                        logger.warning(f"Failed to fulfill mock request: {e}")

            # 2. Check Header Injection Rules
            headers_to_modify = dict(raw_headers)
            headers_changed = False
            for pat, extra_headers in self._header_rules:
                if fnmatch.fnmatch(url, pat):
                    headers_to_modify.update(extra_headers)
                    headers_changed = True

            # 3. Check Body Modifiers
            post_data = req.get("postData")
            post_data_b64 = None
            if post_data is not None:
                for pat, modifier in self._body_modifiers:
                    if fnmatch.fnmatch(url, pat):
                        try:
                            modified = modifier(post_data)
                            if isinstance(modified, (dict, list)):
                                modified_str = json.dumps(modified)
                                post_data_b64 = base64.b64encode(modified_str.encode("utf-8")).decode("ascii")
                            elif isinstance(modified, str):
                                post_data_b64 = base64.b64encode(modified.encode("utf-8")).decode("ascii")
                            elif isinstance(modified, bytes):
                                post_data_b64 = base64.b64encode(modified).decode("ascii")
                        except Exception as e:
                            logger.warning(f"Error in body modifier: {e}")

            # 4. Check Custom Hooks
            target_url = None
            target_method = None
            for pat, hook in self._custom_hooks:
                if fnmatch.fnmatch(url, pat):
                    try:
                        res = hook(req)
                        if isinstance(res, dict):
                            if "url" in res:
                                target_url = res["url"]
                            if "method" in res:
                                target_method = res["method"]
                            if "headers" in res:
                                headers_to_modify.update(res["headers"])
                                headers_changed = True
                            if "postData" in res:
                                p_val = res["postData"]
                                p_bytes = p_val.encode("utf-8") if isinstance(p_val, str) else p_val
                                post_data_b64 = base64.b64encode(p_bytes).decode("ascii")
                    except Exception as e:
                        logger.warning(f"Error in custom hook: {e}")

            # 5. Build continueRequest payload
            continue_params: Dict[str, Any] = {"requestId": req_id}
            if target_url:
                continue_params["url"] = target_url
            if target_method:
                continue_params["method"] = target_method
            if headers_changed:
                continue_params["headers"] = [{"name": k, "value": v} for k, v in headers_to_modify.items()]
            if post_data_b64:
                continue_params["postData"] = post_data_b64

            try:
                self.cdp.send("Fetch.continueRequest", continue_params)
            except Exception as e:
                logger.warning(f"Failed to continue request {req_id}: {e}")


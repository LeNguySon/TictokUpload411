"""
Human Inertial Mouse Wheel & Touchpad Scrolling Kinematics.
Simulates natural biometric scrolling with acceleration, cubic ease-out deceleration,
random micro-jitter, and native CDP Input.dispatchMouseEvent.
Defeats Kasada, DataDome, and Cloudflare jump-scroll anti-bot heuristics.
"""

from __future__ import annotations
import math
import random
import time
from typing import Optional, Union, Tuple, Dict, Any

from sammonny.core.cdp import SyncCdpClient
from sammonny.core.models import Point


class HumanScroller:
    """
    Simulates organic, human-like inertial mouse-wheel and trackpad scrolling via CDP.
    """

    def __init__(self, cdp_client: SyncCdpClient) -> None:
        self.cdp = cdp_client

    def _get_viewport_center(self) -> Point:
        try:
            res = self.cdp.evaluate("({ width: window.innerWidth, height: window.innerHeight })")
            if res and "width" in res and "height" in res:
                return Point(res["width"] / 2.0, res["height"] / 2.0)
        except Exception:
            pass
        return Point(500.0, 400.0)

    def scroll(
        self,
        delta_y: int,
        delta_x: int = 0,
        duration: float = 0.8,
        steps: Optional[int] = None,
        anchor_point: Optional[Point] = None,
    ) -> None:
        """
        Executes a human-like inertial scroll using native CDP mouseWheel events.

        Args:
            delta_y: Vertical scroll amount (positive = scroll down, negative = scroll up).
            delta_x: Horizontal scroll amount (optional).
            duration: Total duration in seconds.
            steps: Number of micro-wheel events to emit (default dynamically calculated).
            anchor_point: Screen coordinates where mouse wheel occurs (default viewport center).
        """
        if delta_y == 0 and delta_x == 0:
            return

        pt = anchor_point or getattr(self.cdp, "last_mouse_pos", None) or self._get_viewport_center()
        num_steps = steps or max(12, int(abs(delta_y) / 25))
        num_steps = min(num_steps, 60)  # Bound to prevent excessive lag

        sleep_per_step = max(0.008, duration / num_steps)

        # Generate non-linear cubic ease-out acceleration and deceleration profile
        accumulated_y = 0.0
        accumulated_x = 0.0

        for i in range(1, num_steps + 1):
            t = i / num_steps
            # Cubic Ease-Out: 1 - (1 - t)^3
            ease_factor = 1.0 - math.pow(1.0 - t, 3.0)

            target_y_so_far = delta_y * ease_factor
            target_x_so_far = delta_x * ease_factor

            step_dy = target_y_so_far - accumulated_y
            step_dx = target_x_so_far - accumulated_x

            # Apply small biological micro-jitter (+/- 3%)
            jitter_factor = random.uniform(0.96, 1.04)
            current_dy = step_dy * jitter_factor
            current_dx = step_dx * jitter_factor

            # Dispatch native Chromium Input mouseWheel event
            self.cdp.send(
                "Input.dispatchMouseEvent",
                {
                    "type": "mouseWheel",
                    "x": pt.x + random.uniform(-1.0, 1.0),
                    "y": pt.y + random.uniform(-1.0, 1.0),
                    "deltaX": round(current_dx, 2),
                    "deltaY": round(current_dy, 2),
                },
            )

            accumulated_y += step_dy
            accumulated_x += step_dx
            time.sleep(sleep_per_step + random.uniform(-0.002, 0.003))

    def scroll_into_view(self, selector: str, padding: int = 150) -> bool:
        """
        Smoothly scrolls the page until target element is safely inside the viewport.
        """
        try:
            rect = self.cdp.get_element_rect(selector)
            if not rect:
                return False

            viewport = self.cdp.evaluate("({ innerHeight: window.innerHeight, scrollY: window.scrollY })")
            inner_height = viewport.get("innerHeight", 800)

            # Check if element is already comfortably in view
            if 50 <= rect.y <= (inner_height - 100):
                return True

            # Calculate desired delta
            target_screen_y = inner_height / 2.0
            diff = rect.y - target_screen_y

            # Inertial scroll
            self.scroll(delta_y=int(diff), duration=max(0.4, min(1.2, abs(diff) / 600.0)))
            time.sleep(0.15)
            return True
        except Exception:
            return False

    def scroll_to_bottom(self, max_scrolls: int = 5, pause: float = 0.5) -> None:
        """Scrolls down progressively for infinite-feed pages (TikTok, Facebook, Twitter)."""
        for _ in range(max_scrolls):
            self.scroll(delta_y=random.randint(450, 750), duration=random.uniform(0.6, 0.9))
            time.sleep(pause + random.uniform(0.1, 0.3))


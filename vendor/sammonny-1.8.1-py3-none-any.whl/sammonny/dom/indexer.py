"""
AI Agent Interactive Element Indexer & Visual DOM Tree Parser.
Extracts all visible clickable and focusable elements with geometric bounding boxes,
unique index IDs, honeypot filtering, and formatted summaries for LLMs and AI Agents.
Inspired by browser-use and modern AI agent web automation architectures.
"""

from __future__ import annotations
import json
from dataclasses import dataclass
from typing import List, Optional, Dict, Any, Union

from sammonny.core.cdp import SyncCdpClient
from sammonny.core.models import Rect, Point


@dataclass
class InteractiveElement:
    index: int
    tag: str
    type: str
    id: str
    name: str
    text: str
    placeholder: str
    aria_label: str
    selector: str
    bounds: Rect

    def to_dict(self) -> Dict[str, Any]:
        return {
            "index": self.index,
            "tag": self.tag,
            "type": self.type,
            "id": self.id,
            "name": self.name,
            "text": self.text,
            "placeholder": self.placeholder,
            "aria_label": self.aria_label,
            "selector": self.selector,
            "bounds": self.bounds.as_dict(),
        }

    def __str__(self) -> str:
        desc = f"<{self.tag}"
        if self.id:
            desc += f" id='{self.id}'"
        if self.type:
            desc += f" type='{self.type}'"
        if self.placeholder:
            desc += f" placeholder='{self.placeholder}'"
        desc += ">"
        if self.text:
            desc += f" '{self.text}'"
        elif self.aria_label:
            desc += f" [aria: {self.aria_label}]"
        return f"[{self.index}] {desc} at ({self.bounds.center.x:.1f}, {self.bounds.center.y:.1f})"


class DOMIndexer:
    """
    Automated DOM element scanner producing an indexed interactive element registry.
    Enables AI Agents to interact with web pages by index: click_index(i), type_index(i, text).
    """

    def __init__(self, cdp_client: SyncCdpClient, session: Optional[Any] = None) -> None:
        self.cdp = cdp_client
        self.session = session
        self._cached_elements: List[InteractiveElement] = []

    def scan(self) -> List[InteractiveElement]:
        """
        Scans active page DOM for visible interactive elements, filtering out honeypots and invisible traps.
        """
        script = """
        (() => {
            const isVisible = (elem, rect) => {
                if (rect.width <= 2 || rect.height <= 2) return false;
                const style = window.getComputedStyle(elem);
                if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
                if (style.pointerEvents === 'none') return false;
                return true;
            };

            const queryInteractive = [
                'a[href]',
                'button',
                'input:not([type="hidden"])',
                'textarea',
                'select',
                '[role="button"]',
                '[role="checkbox"]',
                '[role="link"]',
                '[role="tab"]',
                '[role="menuitem"]',
                '[onclick]',
                '[tabindex]:not([tabindex="-1"])'
            ];

            const foundNodes = Array.from(document.querySelectorAll(queryInteractive.join(',')));
            const results = [];
            let idx = 0;

            for (const el of foundNodes) {
                const rect = el.getBoundingClientRect();
                if (!isVisible(el, rect)) continue;

                // Build a CSS selector
                let sel = '';
                if (el.id) {
                    sel = '#' + CSS.escape(el.id);
                } else if (el.name) {
                    sel = `${el.tagName.toLowerCase()}[name="${CSS.escape(el.name)}"]`;
                } else {
                    // Path selector
                    let path = el.tagName.toLowerCase();
                    if (el.className && typeof el.className === 'string') {
                        const classes = el.className.trim().split(/\\s+/).filter(c => c && !c.includes(':')).slice(0, 2);
                        if (classes.length) path += '.' + classes.join('.');
                    }
                    sel = path;
                }

                results.push({
                    index: idx++,
                    tag: el.tagName.toLowerCase(),
                    type: el.getAttribute('type') || '',
                    id: el.id || '',
                    name: el.name || '',
                    text: (el.innerText || el.textContent || '').trim().slice(0, 60),
                    placeholder: el.getAttribute('placeholder') || '',
                    aria_label: el.getAttribute('aria-label') || '',
                    selector: sel,
                    x: Math.round(rect.left),
                    y: Math.round(rect.top),
                    width: Math.round(rect.width),
                    height: Math.round(rect.height),
                });
            }
            return results;
        })()
        """
        try:
            raw_list = self.cdp.evaluate(script) or []
            elements: List[InteractiveElement] = []
            for item in raw_list:
                elements.append(
                    InteractiveElement(
                        index=item["index"],
                        tag=item["tag"],
                        type=item["type"],
                        id=item["id"],
                        name=item["name"],
                        text=item["text"],
                        placeholder=item["placeholder"],
                        aria_label=item["aria_label"],
                        selector=item["selector"],
                        bounds=Rect(
                            x=float(item["x"]),
                            y=float(item["y"]),
                            width=float(item["width"]),
                            height=float(item["height"]),
                        ),
                    )
                )
            self._cached_elements = elements
            return elements
        except Exception:
            return []

    def get_summary(self) -> str:
        """Returns human-readable and LLM-friendly index list of all interactive elements."""
        elements = self.scan()
        if not elements:
            return "No visible interactive elements detected on page."

        lines = [f"=== Interactive Elements ({len(elements)}) ==="]
        for el in elements:
            lines.append(str(el))
        return "\n".join(lines)

    def get_by_index(self, index: int) -> Optional[InteractiveElement]:
        if not self._cached_elements:
            self.scan()
        for el in self._cached_elements:
            if el.index == index:
                return el
        return None

    def click_index(self, index: int, style: str = "minimum_jerk") -> Point:
        """Clicks an element by its numeric index using human kinematics."""
        el = self.get_by_index(index)
        if not el:
            raise IndexError(f"Interactive element index {index} not found.")

        pt = el.bounds.sample_human_point()
        if self.session and hasattr(self.session, "mouse"):
            return self.session.mouse.click(pt.x, pt.y, style=style)
        self.cdp.dispatch_mouse("mousePressed", pt.x, pt.y, button="left")
        self.cdp.dispatch_mouse("mouseReleased", pt.x, pt.y, button="left")
        return pt

    def type_index(self, index: int, text: str, wpm: float = 85.0) -> None:
        """Focuses and types into an element by its numeric index."""
        self.click_index(index)
        if self.session and hasattr(self.session, "dom"):
            el = self.get_by_index(index)
            if el and el.selector:
                self.session.dom.type_text(el.selector, text, wpm=wpm)


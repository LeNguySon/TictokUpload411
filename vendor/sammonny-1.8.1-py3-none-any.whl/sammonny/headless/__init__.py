"""
Headless Browser Acceleration and Autonomous AI Agent Primitives Subsystem.
"""

from sammonny.headless.accelerator import HeadlessAgentAccelerator
from sammonny.headless.tab_pool import HeadlessTabPool, HeadlessTab
from sammonny.headless.actions import AutonomousActionEngine, ActionResult, AgentStateSnapshot
from sammonny.headless.observer import NetworkIdleObserver, SPAConditionObserver
from sammonny.headless.canvas import HeadlessCanvasInspector

__all__ = [
    "HeadlessAgentAccelerator",
    "HeadlessTabPool",
    "HeadlessTab",
    "AutonomousActionEngine",
    "ActionResult",
    "AgentStateSnapshot",
    "NetworkIdleObserver",
    "SPAConditionObserver",
    "HeadlessCanvasInspector",
]

"""
Network and SPA Condition Observers for Headless AI Agents.
Monitors in-flight CDP network requests and Single-Page Application (SPA) DOM mutations.
"""

from __future__ import annotations
import re
import time
import threading
from typing import Any, Callable, Dict, Optional, Set

from sammonny.core.cdp import SyncCdpClient


class NetworkIdleObserver:
    """
    Accurately detects when a page has finished all asynchronous network traffic
    (AJAX, Fetch, dynamic assets, WebSocket handshakes).
    """

    def __init__(self, cdp: SyncCdpClient) -> None:
        self.cdp = cdp
        self._in_flight: Set[str] = set()
        self._lock = threading.Lock()
        self._last_activity = time.time()
        self._enabled = False

    def enable(self) -> None:
        """Enables Network domain and hooks event listeners."""
        if self._enabled:
            return
        try:
            self.cdp.send("Network.enable", {})
        except Exception:
            pass

        self.cdp.on("Network.requestWillBeSent", self._on_req_sent)
        self.cdp.on("Network.loadingFinished", self._on_req_finished)
        self.cdp.on("Network.loadingFailed", self._on_req_failed)
        self._enabled = True

    def _on_req_sent(self, params: Dict[str, Any]) -> None:
        req_id = params.get("requestId")
        if req_id:
            with self._lock:
                self._in_flight.add(req_id)
                self._last_activity = time.time()

    def _on_req_finished(self, params: Dict[str, Any]) -> None:
        req_id = params.get("requestId")
        if req_id:
            with self._lock:
                self._in_flight.discard(req_id)
                self._last_activity = time.time()

    def _on_req_failed(self, params: Dict[str, Any]) -> None:
        req_id = params.get("requestId")
        if req_id:
            with self._lock:
                self._in_flight.discard(req_id)
                self._last_activity = time.time()

    @property
    def in_flight_count(self) -> int:
        with self._lock:
            return len(self._in_flight)

    def wait_for_idle(self, idle_threshold_sec: float = 0.5, timeout_sec: float = 10.0) -> bool:
        """
        Blocks until active network requests remain zero for at least `idle_threshold_sec`.
        Returns True if idle was achieved, False if timed out.
        """
        if not self._enabled:
            self.enable()

        start_time = time.time()
        while time.time() - start_time < timeout_sec:
            time.sleep(0.05)
            now = time.time()
            with self._lock:
                count = len(self._in_flight)
                last_act = self._last_activity

            if count == 0 and (now - last_act) >= idle_threshold_sec:
                return True

        return False


class SPAConditionObserver:
    """
    Monitors DOM mutations and JavaScript conditions in V8 Isolated World.
    """

    def __init__(self, cdp: SyncCdpClient) -> None:
        self.cdp = cdp

    def wait_for_selector(
        self,
        selector: str,
        timeout_sec: float = 10.0,
        poll_interval: float = 0.1,
        visible_only: bool = True,
    ) -> bool:
        """Waits until an element matching CSS selector exists in DOM and is visible."""
        start = time.time()
        js = f"""
        (() => {{
            const el = document.querySelector({repr(selector)});
            if (!el) return false;
            if (!{str(visible_only).lower()}) return true;
            const r = el.getBoundingClientRect();
            const s = window.getComputedStyle(el);
            return (r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0');
        }})()
        """
        while time.time() - start < timeout_sec:
            try:
                res = self.cdp.evaluate_isolated(js)
                if res is True or (isinstance(res, dict) and res.get("value") is True):
                    return True
            except Exception:
                pass
            time.sleep(poll_interval)
        return False

    def wait_for_predicate(
        self,
        predicate_js: str,
        timeout_sec: float = 10.0,
        poll_interval: float = 0.1,
    ) -> Any:
        """Evaluates JavaScript expression in isolated world until it evaluates to truthy."""
        start = time.time()
        while time.time() - start < timeout_sec:
            try:
                res = self.cdp.evaluate_isolated(predicate_js)
                val = res.get("value") if isinstance(res, dict) and "value" in res else res
                if val:
                    return val
            except Exception:
                pass
            time.sleep(poll_interval)
        return None

    def wait_for_url(
        self,
        pattern: str,
        timeout_sec: float = 10.0,
        poll_interval: float = 0.1,
    ) -> bool:
        """Waits until current page URL matches regex or substring."""
        start = time.time()
        regex = re.compile(pattern)
        while time.time() - start < timeout_sec:
            try:
                current_url = self.cdp.evaluate("window.location.href")
                if current_url and (pattern in current_url or regex.search(current_url)):
                    return True
            except Exception:
                pass
            time.sleep(poll_interval)
        return False


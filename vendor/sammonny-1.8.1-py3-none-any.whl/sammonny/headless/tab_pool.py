"""
Headless Tab Pool & Multi-Target Parallel Execution Subsystem.
Enables running multiple concurrent headless tabs within a single Orbita Chromium process,
saving 70-90% RAM compared to launching separate browser instances.
"""

from __future__ import annotations
import time
import logging
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Union

from sammonny.core.cdp import SyncCdpClient
from sammonny.dom.mouse import HumanMouse
from sammonny.headless.accelerator import HeadlessAgentAccelerator
from sammonny.headless.actions import AutonomousActionEngine, ActionResult, AgentStateSnapshot
from sammonny.headless.observer import NetworkIdleObserver, SPAConditionObserver

if TYPE_CHECKING:
    from sammonny.engine.session import AntidetectSession

logger = logging.getLogger("sammonny.headless.pool")


class HeadlessTab:
    """
    Represents an independent page target (tab) running inside the headless browser.
    Each tab has its own dedicated CDP WebSocket connection, accelerator, and action engine.
    """

    def __init__(
        self,
        target_id: str,
        ws_url: str,
        session: AntidetectSession,
        cdp: Optional[SyncCdpClient] = None,
    ):
        self.target_id = target_id
        self.ws_url = ws_url
        self.session = session
        self.cdp = cdp or SyncCdpClient(ws_url).connect()
        self.mouse = HumanMouse(self.cdp)
        self.accelerator = HeadlessAgentAccelerator(self.cdp, session=session)
        self.actions = AutonomousActionEngine(
            self.cdp,
            mouse=self.mouse,
            accelerator=self.accelerator,
            session=session,
        )
        self.network_observer = NetworkIdleObserver(self.cdp)
        self.spa_observer = SPAConditionObserver(self.cdp)
        self._closed = False

    def goto(self, url: str) -> HeadlessTab:
        """Navigates this tab to destination URL."""
        self.cdp.navigate(url)
        time.sleep(0.5)
        return self

    def navigate(self, url: str) -> HeadlessTab:
        """Alias for goto(). Navigates this tab to destination URL."""
        return self.goto(url)

    def evaluate(self, expression: str) -> Any:
        """Evaluates JavaScript expression on this tab."""
        return self.cdp.evaluate(expression)

    def extract_markdown(self) -> str:
        """Extracts clean Fit-Markdown from this tab."""
        return self.accelerator.extract_markdown()

    def get_accessibility_tree(self, interactive_only: bool = True) -> List[Dict[str, Any]]:
        """Extracts actionable accessibility tree nodes from this tab."""
        return self.accelerator.get_accessibility_tree(interactive_only=interactive_only)

    def format_a11y_tree(self, max_nodes: int = 50) -> str:
        """Formats accessibility tree into token-efficient prompt string."""
        return self.accelerator.format_a11y_tree(max_nodes=max_nodes)

    def block_resources(self, preset_or_patterns: Union[str, List[str]] = "text_only") -> HeadlessTab:
        """Enables resource blocking for fast text scraping on this tab."""
        self.accelerator.block_resources(preset_or_patterns)
        return self

    def unblock_resources(self) -> HeadlessTab:
        """Restores full resource loading on this tab."""
        self.accelerator.unblock_resources()
        return self

    def wait_for_network_idle(self, idle_threshold_sec: float = 0.5, timeout_sec: float = 10.0) -> bool:
        """Waits until all in-flight network requests finish on this tab."""
        return self.network_observer.wait_for_idle(
            idle_threshold_sec=idle_threshold_sec,
            timeout_sec=timeout_sec,
        )

    def wait_for_selector(self, selector: str, timeout_sec: float = 10.0) -> bool:
        """Waits until CSS selector exists and is visible on this tab."""
        return self.spa_observer.wait_for_selector(selector=selector, timeout_sec=timeout_sec)

    def act(
        self,
        action: str,
        target: Optional[Union[str, int]] = None,
        value: Optional[str] = None,
        timeout_sec: float = 10.0,
    ) -> ActionResult:
        """Executes an autonomous action (click, type, scroll, hover, press_key) on this tab."""
        return self.actions.act(action=action, target=target, value=value, timeout_sec=timeout_sec)

    def get_agent_state(self, with_screenshot: bool = False) -> AgentStateSnapshot:
        """Captures full state snapshot of this tab for AI agents."""
        return self.actions.get_agent_state(with_screenshot=with_screenshot)

    def screenshot(self, save_path: Optional[Union[str, Path]] = None) -> bytes:
        """Captures Skia offscreen GPU surface of this tab."""
        raw_bytes = self.cdp.capture_screenshot(from_surface=True)
        if save_path:
            with open(save_path, "wb") as f:
                f.write(raw_bytes)
        return raw_bytes

    def activate(self) -> HeadlessTab:
        """Focuses and brings this tab to the foreground."""
        try:
            self.session.cdp.send("Target.activateTarget", {"targetId": self.target_id})
        except Exception:
            pass
        return self

    def close(self) -> bool:
        """Closes this tab and releases its CDP WebSocket connection."""
        if self._closed:
            return True
        self._closed = True
        try:
            self.cdp.close()
        except Exception:
            pass

        try:
            res = self.session.cdp.send("Target.closeTarget", {"targetId": self.target_id})
            return bool(res.get("success", False))
        except Exception:
            return False

    def __enter__(self) -> HeadlessTab:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class HeadlessTabPool:
    """
    Manages pools of headless tabs for concurrent AI scraping, multi-task crawling,
    and high-throughput worker pipelines.
    """

    def __init__(self, session: AntidetectSession):
        self.session = session
        self._tabs: Dict[str, HeadlessTab] = {}
        self._lock = threading.Lock()

    def _extract_host_port(self) -> str:
        clean = self.session.ws_url.replace("ws://", "").replace("wss://", "")
        return clean.split("/")[0]

    def open_tab(self, url: str = "about:blank") -> HeadlessTab:
        """
        Spawns a new tab via CDP Target.createTarget and connects a dedicated SyncCdpClient.
        """
        res = self.session.cdp.send("Target.createTarget", {"url": url})
        target_id = res.get("targetId")
        if not target_id:
            raise RuntimeError(f"Failed to create new CDP target: {res}")

        host_port = self._extract_host_port()
        tab_ws_url = f"ws://{host_port}/devtools/page/{target_id}"
        tab_cdp = SyncCdpClient(tab_ws_url).connect()

        tab = HeadlessTab(
            target_id=target_id,
            ws_url=tab_ws_url,
            session=self.session,
            cdp=tab_cdp,
        )
        with self._lock:
            self._tabs[target_id] = tab
        return tab

    def list_tabs(self) -> List[HeadlessTab]:
        """Returns list of currently tracked active tabs in this pool."""
        with self._lock:
            return list(self._tabs.values())

    def get_tab(self, target_id: str) -> Optional[HeadlessTab]:
        with self._lock:
            return self._tabs.get(target_id)

    def close_tab(self, tab_or_id: Union[HeadlessTab, str]) -> bool:
        """Closes a specific tab."""
        target_id = tab_or_id.target_id if isinstance(tab_or_id, HeadlessTab) else str(tab_or_id)
        with self._lock:
            tab = self._tabs.pop(target_id, None)

        if tab:
            return tab.close()

        try:
            res = self.session.cdp.send("Target.closeTarget", {"targetId": target_id})
            return bool(res.get("success", False))
        except Exception:
            return False

    def close_all(self) -> None:
        """Closes all secondary tabs managed by this pool."""
        with self._lock:
            active = list(self._tabs.values())
            self._tabs.clear()

        for tab in active:
            try:
                tab.close()
            except Exception:
                pass

    def parallel_map(
        self,
        items: List[Any],
        worker_fn: Callable[[HeadlessTab, Any], Any],
        max_concurrency: int = 4,
    ) -> List[Any]:
        """
        Distributes tasks across concurrent headless tabs within the same browser instance.
        - Spawns up to `max_concurrency` tabs.
        - Executes `worker_fn(tab, item)` in parallel threads.
        - Automatically collects results in original order and closes worker tabs cleanly.
        """
        results: List[Any] = [None] * len(items)
        concurrency = min(max_concurrency, len(items)) if items else 1

        def _task_runner(idx: int, item: Any):
            tab = self.open_tab("about:blank")
            try:
                out = worker_fn(tab, item)
                results[idx] = out
            finally:
                self.close_tab(tab)

        with ThreadPoolExecutor(max_workers=concurrency, thread_name_prefix="headless-pool") as pool:
            futures = [pool.submit(_task_runner, i, item) for i, item in enumerate(items)]
            for f in as_completed(futures):
                f.result()

        return results


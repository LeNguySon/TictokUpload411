"""
Offscreen HTML5 Canvas & WebGL Inspector for Headless AI Agents.
Enables inspection, pixel extraction, and relative coordinate dispatching
on Canvas/WebGL games (Cocos2d-js, Pixi.js, Phaser) in headless mode.
"""

from __future__ import annotations
import base64
import json
import time
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple

from sammonny.core.cdp import SyncCdpClient
from sammonny.core.models import Point, Rect
from sammonny.dom.mouse import HumanMouse

if TYPE_CHECKING:
    from sammonny.engine.session import AntidetectSession


class HeadlessCanvasInspector:
    """
    Offscreen Canvas & WebGL Controller.
    Allows inspection and interaction with non-DOM canvas gaming interfaces.
    """

    def __init__(
        self,
        cdp: SyncCdpClient,
        mouse: Optional[HumanMouse] = None,
        session: Optional[AntidetectSession] = None,
    ):
        self.cdp = cdp
        self.mouse = mouse or HumanMouse(cdp)
        self.session = session

    def get_canvas_info(self, selector: str = "canvas") -> Dict[str, Any]:
        """
        Inspects offscreen canvas element and its WebGL rendering context.
        """
        js = f"""
        (() => {{
            const canvas = document.querySelector({json.dumps(selector)});
            if (!canvas) return {{ found: false }};
            const r = canvas.getBoundingClientRect();

            let glInfo = {{}};
            try {{
                const gl = canvas.getContext('webgl2') || canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
                if (gl) {{
                    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
                    glInfo = {{
                        is_webgl: true,
                        renderer: dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER),
                        vendor: dbg ? gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR),
                        version: gl.getParameter(gl.VERSION),
                        shading_language_version: gl.getParameter(gl.SHADING_LANGUAGE_VERSION),
                    }};
                }}
            }} catch (e) {{}}

            return {{
                found: true,
                width: canvas.width,
                height: canvas.height,
                client_width: r.width,
                client_height: r.height,
                top: r.top,
                left: r.left,
                webgl: glInfo,
            }};
        }})()
        """
        val = self.cdp.evaluate(js)
        return val if isinstance(val, dict) else {"found": False}

    def export_canvas_image(self, selector: str = "canvas") -> Optional[bytes]:
        """
        Extracts offscreen canvas buffer as PNG bytes via canvas.toDataURL.
        """
        js = f"""
        (() => {{
            const canvas = document.querySelector({json.dumps(selector)});
            if (!canvas) return null;
            try {{
                return canvas.toDataURL('image/png');
            }} catch (e) {{
                return null;
            }}
        }})()
        """
        data_url = self.cdp.evaluate(js)
        if not data_url or not isinstance(data_url, str) or not data_url.startswith("data:image/png;base64,"):
            return None

        b64 = data_url.replace("data:image/png;base64,", "")
        return base64.b64decode(b64)

    def click_relative(
        self,
        selector: str = "canvas",
        rel_x: float = 0.5,
        rel_y: float = 0.5,
        style: str = "minimum_jerk",
    ) -> Point:
        """
        Clicks on canvas at relative normalized coordinates (0.0 to 1.0).
        (0.5, 0.5) is exact center.
        """
        rect = self.cdp.get_element_rect(selector)
        if not rect:
            raise ValueError(f"Canvas element '{selector}' not found or invisible.")

        target_x = rect.x + (rect.width * rel_x)
        target_y = rect.y + (rect.height * rel_y)

        self.mouse.click(target_x, target_y, style=style)
        return Point(target_x, target_y)


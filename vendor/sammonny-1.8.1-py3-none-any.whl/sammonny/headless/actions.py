"""
Autonomous AI Agent Action Engine & Multimodal State Synthesizer.
Provides high-level, resilient action primitives (click, type, scroll, hover, press_key, navigate)
specifically engineered for AI Agent autonomous operation (Gemini, Claude, GPT).
Resolves targets seamlessly across:
- Semantic Accessibility (AX) IDs: 'AX-15', 15
- DOM Indexer IDs: '#1', 1
- CSS Selectors: 'button.login', '#username'
- Text matches: 'text=Login Button', 'Login Button'
- XPath expressions: '//button[contains(text(), "Submit")]'
"""

from __future__ import annotations
import base64
import json
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

from sammonny.core.cdp import SyncCdpClient
from sammonny.core.models import Point, Rect
from sammonny.dom.mouse import HumanMouse

if TYPE_CHECKING:
    from sammonny.engine.session import AntidetectSession
    from sammonny.headless.accelerator import HeadlessAgentAccelerator


@dataclass
class ActionResult:
    success: bool
    action: str
    target: Optional[str] = None
    value: Optional[str] = None
    elapsed_ms: float = 0.0
    error: Optional[str] = None
    data: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "action": self.action,
            "target": self.target,
            "value": self.value,
            "elapsed_ms": round(self.elapsed_ms, 2),
            "error": self.error,
            "data": self.data or {},
        }


@dataclass
class AgentStateSnapshot:
    url: str
    title: str
    markdown: str
    a11y_tree: str
    nodes_count: int
    in_flight_requests: int
    ram_working_set_mb: Optional[float] = None
    screenshot_base64: Optional[str] = None
    screenshot_bytes: Optional[bytes] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "url": self.url,
            "title": self.title,
            "markdown": self.markdown,
            "a11y_tree": self.a11y_tree,
            "nodes_count": self.nodes_count,
            "in_flight_requests": self.in_flight_requests,
            "ram_working_set_mb": self.ram_working_set_mb,
            "has_screenshot": self.screenshot_base64 is not None,
        }


class AutonomousActionEngine:
    """
    Unified Action Dispatcher for AI Agents.
    Transforms high-level semantic intent into human-like CDP commands with zero-leak execution.
    """

    def __init__(
        self,
        cdp: SyncCdpClient,
        mouse: Optional[HumanMouse] = None,
        accelerator: Optional[HeadlessAgentAccelerator] = None,
        session: Optional[AntidetectSession] = None,
    ):
        self.cdp = cdp
        self.mouse = mouse or HumanMouse(cdp)
        self.accelerator = accelerator
        self.session = session

    def act(
        self,
        action: str,
        target: Optional[Union[str, int]] = None,
        value: Optional[str] = None,
        timeout_sec: float = 10.0,
    ) -> ActionResult:
        """
        Executes an autonomous action.
        Actions supported:
        - 'click': clicks element by AX ID, index, selector, or text
        - 'type': clicks element and types text with natural keystroke dynamics
        - 'press_key': dispatches specific key (Enter, Tab, Escape, Backspace)
        - 'scroll': scrolls page smoothly (value='down', 'up', or integer delta)
        - 'hover': moves mouse to element with Bézier spline
        - 'navigate': navigates to URL in value
        - 'wait': waits for duration or condition
        """
        start = time.time()
        act_lower = action.lower().strip()

        try:
            if act_lower == "click":
                res = self._execute_click(target, timeout_sec=timeout_sec)
            elif act_lower in ("type", "input", "fill"):
                res = self._execute_type(target, value or "", timeout_sec=timeout_sec)
            elif act_lower in ("press_key", "key"):
                res = self._execute_press_key(value or str(target or "Enter"))
            elif act_lower == "scroll":
                res = self._execute_scroll(value or str(target or "500"))
            elif act_lower == "hover":
                res = self._execute_hover(target, timeout_sec=timeout_sec)
            elif act_lower in ("navigate", "goto"):
                dest = value or str(target or "")
                res = self._execute_navigate(dest)
            elif act_lower == "wait":
                wait_sec = float(value or target or 1.0)
                time.sleep(wait_sec)
                res = {"waited_sec": wait_sec}
            else:
                return ActionResult(
                    success=False,
                    action=action,
                    target=str(target) if target is not None else None,
                    value=value,
                    elapsed_ms=(time.time() - start) * 1000,
                    error=f"Unsupported action: '{action}'",
                )

            elapsed = (time.time() - start) * 1000
            return ActionResult(
                success=True,
                action=action,
                target=str(target) if target is not None else None,
                value=value,
                elapsed_ms=elapsed,
                data=res,
            )
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            return ActionResult(
                success=False,
                action=action,
                target=str(target) if target is not None else None,
                value=value,
                elapsed_ms=elapsed,
                error=str(e),
            )

    # =========================================================================
    # Action Implementations
    # =========================================================================

    def _resolve_target_point(self, target: Union[str, int], timeout_sec: float = 10.0) -> Point:
        """
        Resolves target into screen coordinates (x, y):
        1. If integer or string 'AX-N', searches Accessibility Tree.
        2. If starts with '#' or is numeric, tries DOMIndexer.
        3. If starts with 'text=', searches element by textContent.
        4. If starts with '//', evaluates XPath.
        5. Otherwise, resolves via CSS selector.
        """
        target_str = str(target).strip()

        # 1. Accessibility Tree ID (e.g. 'AX-15' or integer if AX tree requested)
        if target_str.upper().startswith("AX-") or (isinstance(target, int) and target > 0 and self.accelerator):
            ax_id = int(target_str.upper().replace("AX-", "")) if target_str.upper().startswith("AX-") else target
            if self.accelerator:
                nodes = self.accelerator.get_accessibility_tree(interactive_only=False)
                for n in nodes:
                    if n.get("ax_id") == ax_id and n.get("backend_id"):
                        b_id = n["backend_id"]
                        self.cdp.send("DOM.enable", {})
                        box = self.cdp.send("DOM.getBoxModel", {"backendNodeId": b_id})
                        content = box.get("model", {}).get("content", [])
                        if len(content) >= 8:
                            cx = (content[0] + content[2] + content[4] + content[6]) / 4
                            cy = (content[1] + content[3] + content[5] + content[7]) / 4
                            return Point(cx, cy)

        # 2. Text match (e.g. 'text=Login' or 'Login')
        if target_str.startswith("text="):
            text_query = target_str[5:].strip()
            pt = self._resolve_by_text(text_query)
            if pt:
                return pt

        # 3. XPath expression
        if target_str.startswith("//") or target_str.startswith("(//"):
            pt = self._resolve_by_xpath(target_str)
            if pt:
                return pt

        # 4. Standard CSS selector
        rect = self.cdp.get_element_rect(target_str)
        if rect:
            return rect.center

        # 5. Fallback: fuzzy text search if target_str looks like button text
        if not any(c in target_str for c in "#.[>:"):
            pt = self._resolve_by_text(target_str)
            if pt:
                return pt

        raise ValueError(f"Could not resolve target '{target}' to visible screen coordinates.")

    def _resolve_by_text(self, text_query: str) -> Optional[Point]:
        js = f"""
        (() => {{
            const query = {json.dumps(text_query.lower())};
            const candidates = Array.from(document.querySelectorAll('button, a, input[type="submit"], input[type="button"], [role="button"], span, div, p, h1, h2, h3'));
            for (const el of candidates) {{
                const txt = (el.innerText || el.textContent || el.getAttribute('aria-label') || el.value || '').trim().toLowerCase();
                if (txt === query || (query.length > 3 && txt.includes(query))) {{
                    el.scrollIntoView({{ behavior: 'instant', block: 'center', inline: 'center' }});
                    const r = el.getBoundingClientRect();
                    if (r.width > 0 && r.height > 0) {{
                        return {{ x: r.x + r.width / 2, y: r.y + r.height / 2 }};
                    }}
                }}
            }}
            return null;
        }})()
        """
        val = self.cdp.evaluate(js)
        if isinstance(val, dict) and "x" in val and "y" in val:
            return Point(float(val["x"]), float(val["y"]))
        return None

    def _resolve_by_xpath(self, xpath: str) -> Optional[Point]:
        js = f"""
        (() => {{
            const res = document.evaluate({json.dumps(xpath)}, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
            const el = res.singleNodeValue;
            if (!el) return null;
            el.scrollIntoView({{ behavior: 'instant', block: 'center', inline: 'center' }});
            const r = el.getBoundingClientRect();
            if (r.width > 0 && r.height > 0) {{
                return {{ x: r.x + r.width / 2, y: r.y + r.height / 2 }};
            }}
            return null;
        }})()
        """
        val = self.cdp.evaluate(js)
        if isinstance(val, dict) and "x" in val and "y" in val:
            return Point(float(val["x"]), float(val["y"]))
        return None

    def _execute_click(self, target: Optional[Union[str, int]], timeout_sec: float) -> Dict[str, Any]:
        if target is None:
            raise ValueError("Target required for click action.")
        pt = self._resolve_target_point(target, timeout_sec=timeout_sec)
        self.mouse.click(pt.x, pt.y, style="minimum_jerk")
        return {"x": round(pt.x, 1), "y": round(pt.y, 1)}

    def _execute_type(self, target: Optional[Union[str, int]], text: str, timeout_sec: float) -> Dict[str, Any]:
        if target is not None:
            pt = self._resolve_target_point(target, timeout_sec=timeout_sec)
            self.mouse.click(pt.x, pt.y, style="minimum_jerk")
            time.sleep(0.08)

        # Dispatch keystrokes with natural delays
        for ch in text:
            self.cdp.send("Input.dispatchKeyEvent", {"type": "keyDown", "text": ch})
            self.cdp.send("Input.dispatchKeyEvent", {"type": "keyUp"})
            time.sleep(0.015)

        return {"typed_chars": len(text)}

    def _execute_press_key(self, key_name: str) -> Dict[str, Any]:
        key_map = {
            "enter": ("Enter", 13),
            "tab": ("Tab", 9),
            "escape": ("Escape", 27),
            "esc": ("Escape", 27),
            "backspace": ("Backspace", 8),
            "arrowdown": ("ArrowDown", 40),
            "arrowup": ("ArrowUp", 38),
            "space": (" ", 32),
        }
        k_lower = key_name.lower().strip()
        key_text, code = key_map.get(k_lower, (key_name, 0))

        self.cdp.send(
            "Input.dispatchKeyEvent",
            {
                "type": "rawKeyDown",
                "windowsVirtualKeyCode": code,
                "unmodifiedText": key_text,
                "text": key_text,
            },
        )
        time.sleep(0.03)
        self.cdp.send("Input.dispatchKeyEvent", {"type": "keyUp", "windowsVirtualKeyCode": code})
        return {"pressed_key": key_name}

    def _execute_scroll(self, scroll_arg: str) -> Dict[str, Any]:
        delta_y = 500
        if scroll_arg.lower() in ("down", "page_down"):
            delta_y = 600
        elif scroll_arg.lower() in ("up", "page_up"):
            delta_y = -600
        else:
            try:
                delta_y = int(scroll_arg)
            except ValueError:
                delta_y = 500

        # Dispatches mouseWheel event at viewport center
        cx, cy = 600.0, 400.0
        self.cdp.dispatch_mouse("mouseWheel", cx, cy, delta_y=float(delta_y))
        time.sleep(0.3)
        return {"delta_y": delta_y}

    def _execute_hover(self, target: Optional[Union[str, int]], timeout_sec: float) -> Dict[str, Any]:
        if target is None:
            raise ValueError("Target required for hover action.")
        pt = self._resolve_target_point(target, timeout_sec=timeout_sec)
        self.mouse.move_to(pt.x, pt.y, style="minimum_jerk")
        return {"hover_x": round(pt.x, 1), "hover_y": round(pt.y, 1)}

    def _execute_navigate(self, url: str) -> Dict[str, Any]:
        if not url:
            raise ValueError("URL required for navigate action.")
        self.cdp.navigate(url)
        time.sleep(0.5)
        return {"url": url}

    # =========================================================================
    # Multimodal AI Agent State Synthesizer
    # =========================================================================

    def get_agent_state(self, with_screenshot: bool = False) -> AgentStateSnapshot:
        """
        Synthesizes a complete multi-modal state snapshot in a single call:
        - URL and title
        - Clean Fit-Markdown for LLM reasoning
        - Semantic indexed Accessibility Tree (Stagehand-style)
        - In-flight network request count
        - Optional Skia offscreen rendered PNG (base64 & bytes)
        - Win32 RAM working set size
        """
        # 1. URL and Title
        try:
            url = str(self.cdp.evaluate("window.location.href") or "")
            title = str(self.cdp.evaluate("document.title") or "")
        except Exception:
            url, title = "", ""

        # 2. Markdown & Accessibility Tree via Accelerator
        if self.accelerator:
            md = self.accelerator.extract_markdown()
            a11y = self.accelerator.format_a11y_tree(max_nodes=60)
            nodes = self.accelerator.get_accessibility_tree(interactive_only=True)
            nodes_count = len(nodes)
        else:
            md = ""
            a11y = ""
            nodes_count = 0

        # 3. Network in-flight count
        in_flight = 0
        if self.session and hasattr(self.session, "_network_idle_observer") and self.session._network_idle_observer:
            in_flight = self.session._network_idle_observer.in_flight_count

        # 4. Working set RAM
        ram_mb = None
        if self.session:
            try:
                ram_mb = self.session.get_working_set_ram()
            except Exception:
                pass

        # 5. Screenshot
        b64_str = None
        raw_bytes = None
        if with_screenshot:
            try:
                raw_bytes = self.cdp.capture_screenshot(from_surface=True)
                b64_str = base64.b64encode(raw_bytes).decode("ascii")
            except Exception:
                pass

        return AgentStateSnapshot(
            url=url,
            title=title,
            markdown=md,
            a11y_tree=a11y,
            nodes_count=nodes_count,
            in_flight_requests=in_flight,
            ram_working_set_mb=ram_mb,
            screenshot_base64=b64_str,
            screenshot_bytes=raw_bytes,
        )

    def click(self, target: Union[str, int], timeout_sec: float = 10.0) -> ActionResult:
        """Convenience method to click a target by selector, AX ID, or text."""
        return self.act("click", target=target, timeout_sec=timeout_sec)

    def type(self, target: Union[str, int], value: str, timeout_sec: float = 10.0) -> ActionResult:
        """Convenience method to type into a target element."""
        return self.act("type", target=target, value=value, timeout_sec=timeout_sec)

    def hover(self, target: Union[str, int], timeout_sec: float = 10.0) -> ActionResult:
        """Convenience method to hover over a target element."""
        return self.act("hover", target=target, timeout_sec=timeout_sec)

    def scroll(self, value: Union[str, int] = "down", timeout_sec: float = 10.0) -> ActionResult:
        """Convenience method to scroll smoothly."""
        return self.act("scroll", value=str(value), timeout_sec=timeout_sec)

    def press_key(self, key: str, timeout_sec: float = 10.0) -> ActionResult:
        """Convenience method to dispatch a key press."""
        return self.act("press_key", value=key, timeout_sec=timeout_sec)


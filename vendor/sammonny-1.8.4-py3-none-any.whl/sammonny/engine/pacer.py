"""
Human Cadence & Temporal Pacer Engine.
======================================
Eliminates machine-like periodic requests and fixed timing bursts.
Implements:
1. Truncated Gaussian & Poisson delay distributions for human-like pauses.
2. Cognitive Dwell pauses (Fitts's Law pre-action orientation).
3. Variable keystroke cadence with bi-gram transition variations.
"""

from __future__ import annotations

import math
import random
import time
from typing import Optional


class HumanPacer:
    """Provides non-deterministic, human-like temporal pacing for automation."""

    @staticmethod
    def gaussian_delay(
        mean_sec: float,
        stddev_sec: float,
        min_sec: Optional[float] = None,
        max_sec: Optional[float] = None,
    ) -> float:
        """
        Samples a delay from a normal distribution with clamping.
        Defaults: min_sec = max(0.01, mean - 3*stddev), max_sec = mean + 3*stddev.
        """
        lower = min_sec if min_sec is not None else max(0.01, mean_sec - 3.0 * stddev_sec)
        upper = max_sec if max_sec is not None else (mean_sec + 3.0 * stddev_sec)

        val = random.gauss(mean_sec, stddev_sec)
        return max(lower, min(upper, val))

    @classmethod
    def sleep_gaussian(
        cls,
        mean_sec: float,
        stddev_sec: float,
        min_sec: Optional[float] = None,
        max_sec: Optional[float] = None,
    ) -> float:
        """Sleeps for a Gaussian-distributed duration and returns elapsed seconds."""
        delay = cls.gaussian_delay(mean_sec, stddev_sec, min_sec, max_sec)
        time.sleep(delay)
        return delay

    @classmethod
    def cognitive_pause(cls, intensity: float = 1.0) -> float:
        """
        Simulates natural human cognitive hesitation (reading, verifying form input, deciding to click).
        Range roughly 0.8s to 2.8s scaled by intensity.
        """
        mean = 1.6 * intensity
        std = 0.35 * intensity
        return cls.sleep_gaussian(mean, std, min_sec=0.7 * intensity, max_sec=3.2 * intensity)

    @classmethod
    def micro_jitter(cls) -> float:
        """
        Subtle micro-pause between immediate physical actions (45ms - 130ms).
        Matches biological motor nerve refractory periods.
        """
        return cls.sleep_gaussian(0.085, 0.020, min_sec=0.045, max_sec=0.140)

    @classmethod
    def keystroke_interval(cls, char: str) -> float:
        """
        Calculates realistic keystroke interval based on character complexity:
        - Common lowercase: 60 - 110ms
        - Uppercase / Shift: 120 - 180ms
        - Special characters / numbers: 140 - 220ms
        - Space / Enter: 80 - 160ms
        """
        if char.isupper():
            mean, std, low, high = 0.145, 0.025, 0.095, 0.210
        elif char in "!@#$%^&*()_+-=[]{}|;':\",./<>?":
            mean, std, low, high = 0.170, 0.035, 0.110, 0.260
        elif char in " \t":
            mean, std, low, high = 0.115, 0.020, 0.075, 0.170
        else:
            mean, std, low, high = 0.082, 0.018, 0.050, 0.130

        return cls.gaussian_delay(mean, std, low, high)


# Default global instance
human_pacer = HumanPacer()


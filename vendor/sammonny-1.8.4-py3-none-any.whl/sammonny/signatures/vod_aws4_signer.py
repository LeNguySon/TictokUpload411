"""
TikTok VOD AWS4-HMAC-SHA256 Signature Generator & Client.

Generates standard AWS Signature Version 4 (AWS4-HMAC-SHA256) signatures
for ByteDance/TikTok internal Video-On-Demand (VOD) endpoints:
  - top/v1?Action=ApplyUploadInner (GET)
  - top/v1?Action=CommitUploadInner (POST)

Credentials are derived offline from the STS temporary credentials returned by:
  POST/GET https://www.tiktok.com/api/v1/video/upload/auth/?aid=1988
specifically within the 'video_token_v5' payload:
  - access_key_id
  - secret_acess_key (or secret_access_key)
  - session_token (x-amz-security-token)
  - space_name (e.g. 'tiktok')

Zero Cloud Dependency: 100% pure offline cryptographic operations (hmac, hashlib).
Strictly adheres to Gloglin Invariant Rules: Rule 3 (Zero External Cloud).
"""

from __future__ import annotations

import datetime
import hashlib
import hmac
import json
import logging
import random
import string
from typing import Any, Dict, List, Optional, Tuple, Union
from urllib.parse import quote, urlparse

logger = logging.getLogger("sammonny.signatures.vod_aws4_signer")

VOD_DEFAULT_VERSION = "2020-11-19"
VOD_DEFAULT_REGION = "gcp"
VOD_DEFAULT_SERVICE = "vod"
VOD_DEFAULT_SPACE = "tiktok"
VOD_DEFAULT_ENDPOINT = "https://www.tiktok.com/top/v1"


def hmac_sha256(key: bytes, msg: str) -> bytes:
    """Computes HMAC-SHA256 digest of a message with a byte key."""
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def hash_sha256(msg: Union[str, bytes]) -> str:
    """Computes SHA-256 hexadecimal hash of string or bytes."""
    if isinstance(msg, str):
        msg = msg.encode("utf-8")
    return hashlib.sha256(msg).hexdigest()


class VodAws4Signer:
    """
    AWS4-HMAC-SHA256 signer customized for ByteDance VOD OpenAPI protocols.
    """

    def __init__(
        self,
        access_key_id: str,
        secret_access_key: str,
        session_token: str,
        space_name: str = VOD_DEFAULT_SPACE,
        region: str = VOD_DEFAULT_REGION,
        service: str = VOD_DEFAULT_SERVICE,
        version: str = VOD_DEFAULT_VERSION,
        endpoint: str = VOD_DEFAULT_ENDPOINT,
    ) -> None:
        if not access_key_id or not secret_access_key:
            raise ValueError("access_key_id and secret_access_key cannot be empty")

        self.access_key_id = access_key_id
        self.secret_access_key = secret_access_key
        self.session_token = session_token
        self.space_name = space_name or VOD_DEFAULT_SPACE
        self.region = region or VOD_DEFAULT_REGION
        self.service = service or VOD_DEFAULT_SERVICE
        self.version = version or VOD_DEFAULT_VERSION
        self.endpoint = endpoint or VOD_DEFAULT_ENDPOINT

        parsed = urlparse(self.endpoint)
        self.host = parsed.netloc or "www.tiktok.com"
        self.canonical_uri = parsed.path or "/top/v1"

    @classmethod
    def from_video_token_v5(
        cls,
        token_dict: Dict[str, Any],
        endpoint: str = VOD_DEFAULT_ENDPOINT,
    ) -> "VodAws4Signer":
        """
        Instantiates a signer from the video_token_v5 object returned by
        TikTok's /api/v1/video/upload/auth/ endpoint.
        Handles alternate spellings (e.g. TikTok's 'secret_acess_key' typo).
        """
        if not isinstance(token_dict, dict):
            raise ValueError(f"Expected dict for video_token_v5, got {type(token_dict)}")

        ak = token_dict.get("access_key_id") or token_dict.get("AccessKeyID") or token_dict.get("ak")
        sk = (
            token_dict.get("secret_acess_key")
            or token_dict.get("secret_access_key")
            or token_dict.get("SecretAccessKey")
            or token_dict.get("sk")
        )
        session_token = (
            token_dict.get("session_token")
            or token_dict.get("SessionToken")
            or token_dict.get("token")
        )
        space_name = (
            token_dict.get("space_name")
            or token_dict.get("SpaceName")
            or VOD_DEFAULT_SPACE
        )

        if not ak or not sk:
            raise ValueError(
                "Missing STS credentials in video_token_v5: access_key_id or secret_access_key not found"
            )

        return cls(
            access_key_id=str(ak),
            secret_access_key=str(sk),
            session_token=str(session_token or ""),
            space_name=str(space_name),
            endpoint=endpoint,
        )

    @staticmethod
    def generate_salt(length: int = 11) -> str:
        """
        Generates an 11-char alphanumeric salt matching TikTok web's
        `Math.random().toString(36).slice(2)`.
        """
        chars = string.ascii_lowercase + string.digits
        return "".join(random.choices(chars, k=length))

    def _derive_signing_key(self, date_stamp: str) -> bytes:
        """
        Derives AWS SigV4 composite signing key:
          kDate = HMAC("AWS4" + SecretKey, DateStamp)
          kRegion = HMAC(kDate, Region)
          kService = HMAC(kRegion, Service)
          kSigning = HMAC(kService, "aws4_request")
        """
        k_date = hmac_sha256(("AWS4" + self.secret_access_key).encode("utf-8"), date_stamp)
        k_region = hmac_sha256(k_date, self.region)
        k_service = hmac_sha256(k_region, self.service)
        k_signing = hmac_sha256(k_service, "aws4_request")
        return k_signing

    def sign_request(
        self,
        method: str,
        query_params: Dict[str, Any],
        body: Optional[Union[str, bytes]] = None,
        extra_headers: Optional[Dict[str, str]] = None,
        request_time: Optional[datetime.datetime] = None,
    ) -> Tuple[str, Dict[str, str]]:
        """
        Low-level AWS4-HMAC-SHA256 signature generator.

        Returns:
          (signed_url, request_headers)
        """
        method = method.upper()
        now = request_time or datetime.datetime.now(datetime.timezone.utc)
        amz_date = now.strftime("%Y%m%dT%H%M%SZ")
        date_stamp = now.strftime("%Y%m%d")

        # 1. Canonical Query String: RFC 3986 URL encoded, sorted by key
        canonical_qs = "&".join([
            f"{quote(str(k), safe='-_.~')}={quote(str(query_params[k]), safe='-_.~')}"
            for k in sorted(query_params.keys())
        ])

        # 2. Payload Hash
        if body is None:
            payload_hash = hash_sha256(b"")
        elif isinstance(body, str):
            payload_hash = hash_sha256(body.encode("utf-8"))
        else:
            payload_hash = hash_sha256(body)

        # 3. Headers to Sign
        headers_to_sign: Dict[str, str] = {
            "x-amz-date": amz_date,
        }
        if self.session_token:
            headers_to_sign["x-amz-security-token"] = self.session_token

        if method == "POST":
            headers_to_sign["x-amz-content-sha256"] = payload_hash

        signed_headers_keys = sorted(headers_to_sign.keys())
        signed_headers = ";".join(signed_headers_keys)
        canonical_headers = "".join([f"{k}:{headers_to_sign[k]}\n" for k in signed_headers_keys])

        # 4. Canonical Request
        canonical_request = (
            f"{method}\n"
            f"{self.canonical_uri}\n"
            f"{canonical_qs}\n"
            f"{canonical_headers}\n"
            f"{signed_headers}\n"
            f"{payload_hash}"
        )

        # 5. String to Sign
        credential_scope = f"{date_stamp}/{self.region}/{self.service}/aws4_request"
        string_to_sign = (
            f"AWS4-HMAC-SHA256\n"
            f"{amz_date}\n"
            f"{credential_scope}\n"
            f"{hash_sha256(canonical_request)}"
        )

        # 6. Signature calculation
        signing_key = self._derive_signing_key(date_stamp)
        signature = hmac.new(
            signing_key,
            string_to_sign.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        # 7. Construct final headers
        auth_header = (
            f"AWS4-HMAC-SHA256 Credential={self.access_key_id}/{credential_scope}, "
            f"SignedHeaders={signed_headers}, Signature={signature}"
        )

        out_headers: Dict[str, str] = {
            "Authorization": auth_header,
            "X-Amz-Date": amz_date,
        }
        if self.session_token:
            out_headers["x-amz-security-token"] = self.session_token

        if method == "POST":
            out_headers["X-Amz-Content-Sha256"] = payload_hash
            out_headers["Content-Type"] = "text/plain;charset=UTF-8"

        if extra_headers:
            for k, v in extra_headers.items():
                if k not in out_headers:
                    out_headers[k] = v

        full_url = f"{self.endpoint}?{canonical_qs}" if canonical_qs else self.endpoint
        return full_url, out_headers

    def sign_apply_upload(
        self,
        file_size: int,
        file_type: str = "video",
        is_inner: int = 1,
        client_best_hosts: Optional[str] = None,
        salt: Optional[str] = None,
        extra_params: Optional[Dict[str, Any]] = None,
        request_time: Optional[datetime.datetime] = None,
    ) -> Tuple[str, Dict[str, str]]:
        """
        Generates signed GET request for ApplyUploadInner.
        
        Endpoint: /top/v1?Action=ApplyUploadInner...
        """
        s_val = salt or self.generate_salt()
        query_params: Dict[str, Any] = {
            "Action": "ApplyUploadInner",
            "Version": self.version,
            "SpaceName": self.space_name,
            "FileType": file_type,
            "IsInner": str(is_inner),
            "FileSize": str(file_size),
            "s": s_val,
            "device_platform": "web",
            "business_tag": "tiktok_video_submission_web",
        }
        if client_best_hosts:
            query_params["ClientBestHosts"] = client_best_hosts

        if extra_params:
            query_params.update(extra_params)

        return self.sign_request(
            method="GET",
            query_params=query_params,
            request_time=request_time,
        )

    def sign_commit_upload(
        self,
        session_key: str,
        functions: Optional[List[Any]] = None,
        extra_params: Optional[Dict[str, Any]] = None,
        request_time: Optional[datetime.datetime] = None,
    ) -> Tuple[str, Dict[str, str], str]:
        """
        Generates signed POST request for CommitUploadInner.

        Endpoint: /top/v1?Action=CommitUploadInner&SpaceName=...&Version=...
        Returns:
          (signed_url, request_headers, body_str)
        """
        query_params: Dict[str, Any] = {
            "Action": "CommitUploadInner",
            "Version": self.version,
            "SpaceName": self.space_name,
        }
        if extra_params:
            query_params.update(extra_params)

        body_payload = {
            "SessionKey": session_key,
            "Functions": functions or [],
        }
        body_str = json.dumps(body_payload, separators=(",", ":"))

        url, headers = self.sign_request(
            method="POST",
            query_params=query_params,
            body=body_str,
            request_time=request_time,
        )
        return url, headers, body_str


class TikTokVODClient:
    """
    High-level client for executing signed ByteDance VOD API operations
    over HTTP (using requests and optional proxy / cookie sessions).
    """

    def __init__(
        self,
        signer: VodAws4Signer,
        cookies: Optional[Dict[str, str]] = None,
        proxies: Optional[Dict[str, str]] = None,
        timeout: int = 30,
        user_agent: Optional[str] = None,
    ) -> None:
        self.signer = signer
        self.cookies = cookies or {}
        self.proxies = proxies
        self.timeout = timeout
        self.user_agent = user_agent or (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
        )

    def _default_browser_headers(self) -> Dict[str, str]:
        cookie_header = "; ".join([f"{k}={v}" for k, v in self.cookies.items()]) if self.cookies else ""
        headers = {
            "User-Agent": self.user_agent,
            "Referer": "https://www.tiktok.com/tiktokstudio/upload",
            "sec-ch-ua": '"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
        }
        if cookie_header:
            headers["Cookie"] = cookie_header
        return headers

    def apply_upload_inner(
        self,
        file_size: int,
        file_type: str = "video",
        client_best_hosts: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Executes ApplyUploadInner, returning extracted VOD upload credentials:
          - vid: Real ByteDance video id (e.g. 'v24025gl...')
          - upload_host: TOS upload host
          - store_uri: Target store URI
          - upload_token: TOS auth token
          - upload_id: TOS multipart ID
          - session_key: Token string needed for CommitUploadInner
          - store_infos: Raw StoreInfos list
        """
        import requests

        url, signed_headers = self.signer.sign_apply_upload(
            file_size=file_size,
            file_type=file_type,
            client_best_hosts=client_best_hosts,
        )

        headers = self._default_browser_headers()
        headers.update(signed_headers)

        logger.debug("Calling VOD ApplyUploadInner: %s", url)
        resp = requests.get(
            url,
            headers=headers,
            proxies=self.proxies,
            timeout=self.timeout,
        )

        if resp.status_code != 200:
            raise RuntimeError(
                f"ApplyUploadInner failed with HTTP {resp.status_code}: {resp.text[:200]}"
            )

        data = resp.json()
        result = data.get("Result") or {}
        inner_addr = result.get("InnerUploadAddress") or result.get("UploadAddress") or {}
        nodes = inner_addr.get("UploadNodes") or []

        if not nodes:
            # Check if Error present
            err = (data.get("ResponseMetadata") or {}).get("Error") or {}
            msg = err.get("Message") or "No UploadNodes returned in InnerUploadAddress"
            raise RuntimeError(f"ApplyUploadInner rejected: {msg} (raw: {data})")

        node0 = nodes[0]
        vid = node0.get("Vid") or ""
        session_key = node0.get("SessionKey") or ""
        upload_host = node0.get("UploadHost") or ""
        store_infos = node0.get("StoreInfos") or []

        store_uri = ""
        upload_token = ""
        upload_id = ""
        if store_infos:
            si0 = store_infos[0]
            store_uri = si0.get("StoreUri") or ""
            upload_token = si0.get("Auth") or ""
            upload_id = si0.get("UploadID") or ""

        return {
            "vid": vid,
            "session_key": session_key,
            "upload_host": upload_host,
            "store_uri": store_uri,
            "upload_token": upload_token,
            "upload_id": upload_id,
            "store_infos": store_infos,
            "raw_response": data,
        }

    def commit_upload_inner(
        self,
        session_key: str,
        functions: Optional[List[Any]] = None,
    ) -> Dict[str, Any]:
        """
        Executes CommitUploadInner after all chunks are uploaded to TOS.
        """
        import requests

        url, signed_headers, body_str = self.signer.sign_commit_upload(
            session_key=session_key,
            functions=functions,
        )

        headers = self._default_browser_headers()
        headers.update(signed_headers)

        logger.debug("Calling VOD CommitUploadInner: %s", url)
        resp = requests.post(
            url,
            headers=headers,
            data=body_str,
            proxies=self.proxies,
            timeout=self.timeout,
        )

        if resp.status_code != 200:
            raise RuntimeError(
                f"CommitUploadInner failed with HTTP {resp.status_code}: {resp.text[:200]}"
            )

        data = resp.json()
        resp_meta = data.get("ResponseMetadata") or {}
        err = resp_meta.get("Error")
        if err and (err.get("Code") or err.get("CodeN")):
            logger.warning("CommitUploadInner reported error: %s", err)

        return data

"""
SamMonny Antidetect Browser - Python SDK & CLI Suite
High-Performance Stealth Automation, Human Biometrics, Vision Locator & Cookie Engine
"""

from sammonny.gologin.gologin import GoLogin
from sammonny.core.models import Point, Rect, CookieItem, ProfileInfo, ProxyItem, ProxyHealthResult
from sammonny.core.client import SamMonnyDaemonClient
from sammonny.core.cdp import SyncCdpClient, AsyncCdpClient
from sammonny.dom.controller import DOMController
from sammonny.dom.kinematics import WindMouseGenerator, MinimumJerkGenerator, WindMouseConfig
from sammonny.dom.mouse import HumanMouse
from sammonny.dom.ghost_cursor import GhostCursor
from sammonny.vision.locator import ImageLocator
from sammonny.cookies.sqlite_manager import CookieSqliteManager
from sammonny.cookies.cdp_extractor import CdpCookieClient
from sammonny.cookies.cookie_bot import CookieBot
from sammonny.proxy.parser import parse_proxy, bulk_parse_proxies
from sammonny.proxy.checker import check_proxy_health, measure_tcp_ping, trigger_ip_rotation
from sammonny.proxy.pool import ProxyPool
from sammonny.vpn.wireguard import WireGuardConfig
from sammonny.vpn.layered import LayeredTunnelConfig
from sammonny.vpn.audit import NetworkLeakAuditor, LeakAuditReport
from sammonny.solver.color_captcha import ColorCaptchaSolver

from sammonny.solver.slider import SliderCaptchaSolver
from sammonny.solver.checkbox import CheckboxCaptchaSolver
from sammonny.fingerprint.generator import BrowserFingerprint, FingerprintGenerator
from sammonny.system.memory import MemoryManager, ProcessMemoryInfo, MemoryTrimResult, HostMemoryStatus
from sammonny.system.orphan_sweeper import OrphanSweeper
from sammonny.system.job import WindowsJobSupervisor
from sammonny.network.models import NetworkRequest, NetworkResponse, WebSocketFrame
from sammonny.network.monitor import NetworkMonitor
from sammonny.network.telemetry_decoder import AntiBotTelemetryDecoder, TelemetryReport
from sammonny.network.telemetry_supervisor import TelemetrySupervisor
from sammonny.network.kernel_http import KernelHttpClient, KernelResponse
from sammonny.network.connection_pool import KernelConnectionPool
from sammonny.network.interceptor import KernelRequestInterceptor
from sammonny.network.circuit_breaker import NetworkCircuitBreaker
from sammonny.core.tab_manager import TabManager
from sammonny.dom.scroller import HumanScroller
from sammonny.dom.indexer import DOMIndexer
from sammonny.headless.accelerator import HeadlessAgentAccelerator
from sammonny.headless.tab_pool import HeadlessTabPool, HeadlessTab
from sammonny.headless.actions import AutonomousActionEngine, ActionResult, AgentStateSnapshot
from sammonny.headless.observer import NetworkIdleObserver, SPAConditionObserver
from sammonny.headless.canvas import HeadlessCanvasInspector
from sammonny.fingerprint.audio_guard import AudioGuard
from sammonny.fingerprint.hygiene_guard import RuntimeHygieneGuard
from sammonny.system.memory_scanner import ProcessMemoryScanner, MemoryScanResult
from sammonny.memory.decoder import MemoryDecoder
from sammonny.memory.wasm_inspector import WasmMemoryInspector, WasmMemoryInfo
from sammonny.fingerprint.font_guard import FontMetricsGuard, FontMetricItem
from sammonny.dom.stealth_controller import StealthDOMController, HoneypotDetectedError
from sammonny.signatures.bytedance_direct import compute_xgorgon, compute_xbogus, compute_abogus, ttencrypt_payload, ttdecrypt_payload
from sammonny.signatures.device_context import ProfileDeviceContext, get_profile_device_context, resolve_idc_endpoint
from sammonny.signatures.kernel_live import CDPLiveSigner
from sammonny.signatures.harvester import KernelSignatureHarvester
from sammonny.engine.session import AntidetectSession
from sammonny.engine.core import AntidetectEngine
from sammonny.platforms.tiktok import (
    TikTokPipeline,
    TikTokDirectPostClient,
    TikTokHeadlessStudioUploader,
    TikTokPublisherAdapter,
    UploadMode,
    RemoteStatus,
    CapabilityResult,
    DraftResult,
    UploadResult,
)

__version__ = "1.8.3"
__all__ = [
    "GoLogin",
    "Point",
    "Rect",
    "CookieItem",
    "ProfileInfo",
    "ProxyItem",
    "ProxyHealthResult",
    "SamMonnyDaemonClient",
    "SyncCdpClient",
    "AsyncCdpClient",
    "DOMController",
    "StealthDOMController",
    "HoneypotDetectedError",
    "WindMouseGenerator",
    "MinimumJerkGenerator",
    "WindMouseConfig",
    "HumanMouse",
    "GhostCursor",
    "HumanScroller",
    "DOMIndexer",
    "HeadlessAgentAccelerator",
    "HeadlessTabPool",
    "HeadlessTab",
    "AutonomousActionEngine",
    "ActionResult",
    "AgentStateSnapshot",
    "NetworkIdleObserver",
    "SPAConditionObserver",
    "HeadlessCanvasInspector",
    "ImageLocator",
    "CookieSqliteManager",
    "CdpCookieClient",
    "CookieBot",
    "parse_proxy",
    "bulk_parse_proxies",
    "check_proxy_health",
    "measure_tcp_ping",
    "trigger_ip_rotation",
    "ProxyPool",
    "WireGuardConfig",
    "LayeredTunnelConfig",
    "NetworkLeakAuditor",
    "LeakAuditReport",
    "ColorCaptchaSolver",
    "SliderCaptchaSolver",
    "CheckboxCaptchaSolver",
    "BrowserFingerprint",
    "FingerprintGenerator",
    "AudioGuard",
    "RuntimeHygieneGuard",
    "MemoryManager",
    "ProcessMemoryInfo",
    "MemoryTrimResult",
    "HostMemoryStatus",
    "OrphanSweeper",
    "WindowsJobSupervisor",
    "ProcessMemoryScanner",
    "MemoryScanResult",
    "MemoryDecoder",
    "NetworkRequest",
    "NetworkResponse",
    "WebSocketFrame",
    "NetworkMonitor",
    "AntiBotTelemetryDecoder",
    "TelemetryReport",
    "TelemetrySupervisor",
    "KernelHttpClient",
    "KernelResponse",
    "KernelConnectionPool",
    "KernelRequestInterceptor",
    "NetworkCircuitBreaker",
    "TabManager",
    "WasmMemoryInspector",
    "WasmMemoryInfo",
    "FontMetricsGuard",
    "FontMetricItem",
    "KernelSignatureHarvester",
    "CDPLiveSigner",
    "ProfileDeviceContext",
    "get_profile_device_context",
    "resolve_idc_endpoint",
    "compute_xgorgon",
    "compute_xbogus",
    "compute_abogus",
    "ttencrypt_payload",
    "ttdecrypt_payload",
    "AntidetectSession",
    "AntidetectEngine",
    "TikTokPipeline",
    "TikTokDirectPostClient",
    "TikTokHeadlessStudioUploader",
    "TikTokPublisherAdapter",
    "UploadMode",
    "RemoteStatus",
    "CapabilityResult",
    "DraftResult",
    "UploadResult",
]




"""
Unified Antidetect Session.
High-level reusable context manager providing fluent access to DOM, Vision,
Mouse, Cookies, Navigation, and Screenshot operations on an active profile.
"""

from __future__ import annotations
import time
from pathlib import Path
from typing import Optional, Union, Any, Dict, List

from sammonny.core.cdp import SyncCdpClient
from sammonny.core.client import SamMonnyDaemonClient
from sammonny.core.models import Point, Rect, CookieItem
from sammonny.dom.controller import DOMController
from sammonny.dom.mouse import HumanMouse
from sammonny.vision.locator import ImageLocator
from sammonny.cookies.cdp_extractor import CdpCookieClient
from sammonny.cookies.sqlite_manager import CookieSqliteManager


class AntidetectSession:
    """Fluent, reusable execution session for a single browser profile."""

    def __init__(
        self,
        profile_id: str,
        daemon_client: SamMonnyDaemonClient,
        ws_url: Optional[str] = None,
        profile_dir: Optional[Path] = None,
        auto_stop_on_exit: bool = True,
    ):
        self.profile_id = profile_id
        self.daemon = daemon_client
        self.ws_url = ws_url
        self.profile_dir = profile_dir or (Path("profiles") / profile_id)
        self.auto_stop = auto_stop_on_exit

        self._cdp: Optional[SyncCdpClient] = None
        self._dom: Optional[DOMController] = None
        self._mouse: Optional[HumanMouse] = None
        self._vision: Optional[ImageLocator] = None
        self._cookies: Optional[CdpCookieClient] = None
        self._offline_cookies: Optional[CookieSqliteManager] = None

    def start(self, headless: bool = False) -> AntidetectSession:
        if not self.ws_url:
            self.ws_url = self.daemon.start_profile(self.profile_id, headless=headless)

        self._cdp = SyncCdpClient(self.ws_url).connect()
        self._mouse = HumanMouse(self._cdp)
        self._dom = DOMController(self._cdp, self._mouse)
        self._vision = ImageLocator(self._cdp, self._mouse)
        self._cookies = CdpCookieClient(self._cdp)
        self._offline_cookies = CookieSqliteManager(self.profile_dir)
        return self

    def close(self) -> None:
        if self._cdp:
            try:
                self._cdp.close()
            except Exception:
                pass
            self._cdp = None

        if self.auto_stop:
            try:
                self.daemon.stop_profile(self.profile_id)
            except Exception:
                pass

    def __enter__(self) -> AntidetectSession:
        return self.start()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    # =========================================================================
    # Subsystem Properties
    # =========================================================================

    @property
    def cdp(self) -> SyncCdpClient:
        if not self._cdp:
            raise RuntimeError("Session is not active. Call .start() or use 'with' context manager.")
        return self._cdp

    @property
    def dom(self) -> DOMController:
        if not self._dom:
            raise RuntimeError("Session is not active.")
        return self._dom

    @property
    def mouse(self) -> HumanMouse:
        if not self._mouse:
            raise RuntimeError("Session is not active.")
        return self._mouse

    @property
    def vision(self) -> ImageLocator:
        if not self._vision:
            raise RuntimeError("Session is not active.")
        return self._vision

    @property
    def live_cookies(self) -> CdpCookieClient:
        if not self._cookies:
            raise RuntimeError("Session is not active.")
        return self._cookies

    @property
    def sqlite_cookies(self) -> CookieSqliteManager:
        if not self._offline_cookies:
            self._offline_cookies = CookieSqliteManager(self.profile_dir)
        return self._offline_cookies

    @property
    def auditor(self):
        from sammonny.vpn.audit import NetworkLeakAuditor
        return NetworkLeakAuditor(self.cdp)

    def audit_leaks(self):
        """Runs preflight security leak audit (WebRTC, DNS, IPv6)."""
        return self.auditor.audit_full()


    # =========================================================================
    # Fluent Shortcuts
    # =========================================================================

    def goto(self, url: str) -> AntidetectSession:
        self.cdp.navigate(url)
        time.sleep(1.0)
        return self

    def click(self, target: Union[str, Path], style: str = "minimum_jerk") -> Point:
        """
        Smart click:
        - If target is a file path or ends with .png/.jpg, uses Computer Vision template matching.
        - Otherwise, treats target as a CSS selector in DOM.
        """
        target_str = str(target)
        if target_str.endswith((".png", ".jpg", ".jpeg", ".webp")) or Path(target_str).exists():
            return self.vision.click_image(target_str, style=style)
        return self.dom.click(target_str, style=style)

    def type(self, selector: str, text: str, wpm: float = 85.0) -> AntidetectSession:
        self.dom.type_text(selector, text, wpm=wpm)
        return self

    def screenshot(self, save_path: Optional[Union[str, Path]] = None) -> bytes:
        return self.vision.screenshot(save_path)

    def enable_ghost_cursor(self) -> AntidetectSession:
        """Injects in-DOM visual tracking cursor for real-time visual inspection."""
        from sammonny.dom.ghost_cursor import GhostCursor
        GhostCursor(self.cdp).enable()
        return self

    def export_cookies(self, format: str = "json") -> Any:

        """Exports cookies either from live CDP or directly from SQLite."""
        try:
            return [c.to_dict() for c in self.live_cookies.get_all_cookies()]
        except Exception:
            if format == "netscape":
                return self.sqlite_cookies.export_netscape()
            return [c.to_dict() for c in self.sqlite_cookies.export_cookies()]

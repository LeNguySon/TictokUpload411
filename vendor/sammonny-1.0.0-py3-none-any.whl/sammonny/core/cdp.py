"""
Direct Chrome DevTools Protocol (CDP) WebSocket Client.
Provides both Synchronous and Asynchronous interfaces for DOM-aware automation,
mouse event dispatching, cookie harvesting, and Skia surface capture.
"""

from __future__ import annotations
import json
import time
import base64
import urllib.request
import threading
from typing import Any, Dict, Optional, Tuple, List
from sammonny.core.exceptions import CdpError
from sammonny.core.models import Point, Rect, CookieItem

try:
    import websockets
    import websockets.sync.client as ws_sync
    HAS_WEBSOCKETS = True
except ImportError:
    HAS_WEBSOCKETS = False


def resolve_page_ws_url(ws_url: str, timeout: float = 3.0) -> str:
    """
    If ws_url is a Browser target (e.g. /devtools/browser/uuid), query
    http://host:port/json to find an active 'page' target WebSocket URL.
    """
    if "/devtools/browser/" not in ws_url:
        return ws_url

    clean = ws_url.replace("ws://", "").replace("wss://", "")
    host_port = clean.split("/")[0]
    json_url = f"http://{host_port}/json"

    try:
        req = urllib.request.Request(json_url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            for target in data:
                if target.get("type") == "page" and "webSocketDebuggerUrl" in target:
                    return target["webSocketDebuggerUrl"]
    except Exception:
        pass

    return ws_url


class SyncCdpClient:
    """Synchronous CDP Client using websockets.sync."""

    def __init__(self, ws_url: str, timeout: float = 30.0):
        if not HAS_WEBSOCKETS:
            raise CdpError("The 'websockets' package is required for direct CDP connectivity.")
        self.raw_ws_url = ws_url
        self.resolved_ws_url = resolve_page_ws_url(ws_url)
        self.timeout = timeout
        self.ws: Optional[Any] = None
        self._cmd_id = 0
        self._lock = threading.Lock()
        self.last_mouse_pos = Point(100.0, 100.0)

    def connect(self) -> SyncCdpClient:
        try:
            self.ws = ws_sync.connect(self.resolved_ws_url, open_timeout=self.timeout)
            return self
        except Exception as e:
            raise CdpError(f"Failed to connect CDP WebSocket to {self.resolved_ws_url}: {e}") from e

    def close(self) -> None:
        if self.ws:
            try:
                self.ws.close()
            except Exception:
                pass
            self.ws = None

    def __enter__(self) -> SyncCdpClient:
        return self.connect()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def send(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        with self._lock:
            if not self.ws:
                self.connect()

            self._cmd_id += 1
            cmd_id = self._cmd_id
            payload = {
                "id": cmd_id,
                "method": method,
                "params": params or {},
            }
            try:
                self.ws.send(json.dumps(payload))

                start_time = time.time()
                while time.time() - start_time < self.timeout:
                    try:
                        raw_msg = self.ws.recv(timeout=self.timeout)
                    except (TimeoutError, Exception) as recv_err:
                        raise CdpError(f"CDP command '{method}' failed during recv: {recv_err}") from recv_err

                    msg = json.loads(raw_msg)
                    if msg.get("id") == cmd_id:
                        if "error" in msg:
                            raise CdpError(f"CDP command '{method}' failed: {msg['error']}")
                        return msg.get("result", {})
            except CdpError:
                raise
            except Exception as e:
                raise CdpError(f"CDP command '{method}' communication error: {e}") from e

            raise CdpError(f"CDP command '{method}' timed out after {self.timeout}s")

    # =========================================================================
    # Navigation & Evaluation
    # =========================================================================

    def navigate(self, url: str) -> Dict[str, Any]:
        return self.send("Page.navigate", {"url": url})

    def evaluate(self, expression: str) -> Any:
        res = self.send(
            "Runtime.evaluate",
            {
                "expression": expression,
                "returnByValue": True,
                "awaitPromise": True,
            },
        )
        result = res.get("result", {})
        return result.get("value")

    # =========================================================================
    # DOM Node & Bounding Box Queries
    # =========================================================================

    def get_element_rect(self, selector: str) -> Optional[Rect]:
        """
        Calculates viewport-relative BoundingClientRect of selector via in-DOM evaluation.
        Works across all modern HTML5 and Web components.
        """
        js = f"""
        (() => {{
            const el = document.querySelector({json.dumps(selector)});
            if (!el) return null;
            el.scrollIntoView({{ behavior: 'instant', block: 'center', inline: 'center' }});
            const r = el.getBoundingClientRect();
            return {{
                x: r.x,
                y: r.y,
                width: r.width,
                height: r.height,
                top: r.top,
                left: r.left,
                visible: r.width > 0 && r.height > 0
            }};
        }})()
        """
        val = self.evaluate(js)
        if not val or not val.get("visible", False):
            return None
        return Rect(
            x=float(val["x"]),
            y=float(val["y"]),
            width=float(val["width"]),
            height=float(val["height"]),
        )

    # =========================================================================
    # Screenshots
    # =========================================================================

    def capture_screenshot(self, from_surface: bool = True) -> bytes:
        """Capture Skia GPU surface screenshot even if minimized."""
        res = self.send(
            "Page.captureScreenshot",
            {
                "format": "png",
                "fromSurface": from_surface,
                "captureBeyondViewport": False,
            },
        )
        data = res.get("data", "")
        return base64.b64decode(data)

    # =========================================================================
    # Cookies
    # =========================================================================

    def get_cookies(self) -> List[CookieItem]:
        res = self.send("Network.getCookies", {})
        cookies_raw = res.get("cookies", [])
        return [CookieItem.from_dict(c) for c in cookies_raw]

    def set_cookie(self, cookie: CookieItem) -> None:
        params: Dict[str, Any] = {
            "name": cookie.name,
            "value": cookie.value,
            "domain": cookie.domain,
            "path": cookie.path,
            "secure": cookie.secure,
            "httpOnly": cookie.httpOnly,
        }
        if cookie.expirationDate:
            params["expires"] = cookie.expirationDate
        self.send("Network.setCookie", params)

    # =========================================================================
    # Native Mouse Dispatch
    # =========================================================================

    def dispatch_mouse(
        self,
        event_type: str,
        x: float,
        y: float,
        button: str = "none",
        click_count: int = 0,
        delta_x: float = 0.0,
        delta_y: float = 0.0,
    ) -> None:
        """
        Dispatches low-level mouse event directly to Chromium's RenderWidgetHost.
        Generates genuine event.isTrusted === true in DOM.
        """
        params: Dict[str, Any] = {
            "type": event_type,
            "x": round(x, 1),
            "y": round(y, 1),
            "button": button,
            "clickCount": click_count,
            "pointerType": "mouse",
            "timestamp": time.time(),
        }
        if event_type == "mouseWheel":
            params["deltaX"] = delta_x
            params["deltaY"] = delta_y

        self.send("Input.dispatchMouseEvent", params)
        if event_type == "mouseMoved":
            self.last_mouse_pos = Point(x, y)


class AsyncCdpClient:
    """Asynchronous CDP Client using websockets."""

    def __init__(self, ws_url: str, timeout: float = 30.0):
        if not HAS_WEBSOCKETS:
            raise CdpError("The 'websockets' package is required for direct CDP connectivity.")
        self.raw_ws_url = ws_url
        self.resolved_ws_url = resolve_page_ws_url(ws_url)
        self.timeout = timeout
        self.ws: Optional[Any] = None
        self._cmd_id = 0
        self._lock = threading.Lock()
        self.last_mouse_pos = Point(100.0, 100.0)

    async def connect(self) -> AsyncCdpClient:
        try:
            self.ws = await websockets.connect(self.resolved_ws_url, open_timeout=self.timeout)
            return self
        except Exception as e:
            raise CdpError(f"Failed to connect CDP WebSocket to {self.resolved_ws_url}: {e}") from e

    async def close(self) -> None:
        if self.ws:
            try:
                await self.ws.close()
            except Exception:
                pass
            self.ws = None

    async def __aenter__(self) -> AsyncCdpClient:
        return await self.connect()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def send(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        if not self.ws:
            await self.connect()

        self._cmd_id += 1
        cmd_id = self._cmd_id
        payload = {
            "id": cmd_id,
            "method": method,
            "params": params or {},
        }
        await self.ws.send(json.dumps(payload))

        start_time = time.time()
        while time.time() - start_time < self.timeout:
            raw_msg = await self.ws.recv()
            msg = json.loads(raw_msg)
            if msg.get("id") == cmd_id:
                if "error" in msg:
                    raise CdpError(f"CDP command '{method}' failed: {msg['error']}")
                return msg.get("result", {})

        raise CdpError(f"CDP command '{method}' timed out after {self.timeout}s")

    async def get_element_rect(self, selector: str) -> Optional[Rect]:
        js = f"""
        (() => {{
            const el = document.querySelector({json.dumps(selector)});
            if (!el) return null;
            el.scrollIntoView({{ behavior: 'instant', block: 'center', inline: 'center' }});
            const r = el.getBoundingClientRect();
            return {{
                x: r.x,
                y: r.y,
                width: r.width,
                height: r.height,
                visible: r.width > 0 && r.height > 0
            }};
        }})()
        """
        res = await self.send(
            "Runtime.evaluate",
            {"expression": js, "returnByValue": True, "awaitPromise": True},
        )
        val = res.get("result", {}).get("value")
        if not val or not val.get("visible", False):
            return None
        return Rect(
            x=float(val["x"]),
            y=float(val["y"]),
            width=float(val["width"]),
            height=float(val["height"]),
        )

    async def dispatch_mouse(
        self,
        event_type: str,
        x: float,
        y: float,
        button: str = "none",
        click_count: int = 0,
    ) -> None:
        params: Dict[str, Any] = {
            "type": event_type,
            "x": round(x, 1),
            "y": round(y, 1),
            "button": button,
            "clickCount": click_count,
            "pointerType": "mouse",
            "timestamp": time.time(),
        }
        await self.send("Input.dispatchMouseEvent", params)
        if event_type == "mouseMoved":
            self.last_mouse_pos = Point(x, y)

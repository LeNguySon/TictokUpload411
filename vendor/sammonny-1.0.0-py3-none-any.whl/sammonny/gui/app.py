"""
Main Application Window for SamMonny Antidetect Suite Desktop Control Center.
"""

from __future__ import annotations
import sys
import os
from pathlib import Path

try:
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QTabWidget, QStatusBar, QLabel, QWidget
    )
    from PyQt5.QtGui import QIcon
except ImportError:
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QTabWidget, QStatusBar, QLabel, QWidget
    )
    from PySide6.QtGui import QIcon

from sammonny.engine.core import AntidetectEngine
from sammonny.gui.theme import DARK_THEME_QSS
from sammonny.gui.tabs.tab_profiles import ProfilesTab
from sammonny.gui.tabs.tab_proxy import ProxyTab
from sammonny.gui.tabs.tab_system import SystemTab
from sammonny.gui.tabs.tab_cookies import CookiesTab
from sammonny.gui.tabs.tab_fingerprint import FingerprintTab
from sammonny.gui.tabs.tab_extensions import ExtensionsTab


class MainWindow(QMainWindow):
    """Antidetect Suite Desktop Control Center."""

    def __init__(self, profiles_dir: Optional[Path] = None, proxies_file: Optional[Path] = None):
        super().__init__()
        self.setWindowTitle("SamMonny Antidetect Browser Suite - Control Center v1.0")
        self.resize(1100, 720)

        # Setup Engine
        prof_dir = profiles_dir or Path(os.environ.get("SAMMONNY_PROFILES_DIR", "profiles"))
        proxy_path = proxies_file or Path("proxies.json")
        self.engine = AntidetectEngine(profiles_dir=prof_dir, proxy_storage=proxy_path)

        # Central Tabs
        self.tabs = QTabWidget()
        self.tab_profiles = ProfilesTab(self.engine, self)
        self.tab_proxy = ProxyTab(self.engine.proxy_pool, self)
        self.tab_system = SystemTab(prof_dir, self)
        self.tab_cookies = CookiesTab(prof_dir, self)
        self.tab_fingerprint = FingerprintTab(self)
        self.tab_extensions = ExtensionsTab(prof_dir, self)

        self.tabs.addTab(self.tab_profiles, "🌐 Profiles")
        self.tabs.addTab(self.tab_proxy, "🛡️ Proxy Pool")
        self.tabs.addTab(self.tab_system, "⚡ System RAM & Sweeper")
        self.tabs.addTab(self.tab_cookies, "🍪 Cookie Station")
        self.tabs.addTab(self.tab_fingerprint, "🧬 Fingerprint Studio")
        self.tabs.addTab(self.tab_extensions, "🧩 Extensions")

        self.setCentralWidget(self.tabs)

        # Status Bar
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage("SamMonny Antidetect Engine Ready | Daemon Ports: 7654 / 36912")

        # Apply Dark Theme
        self.setStyleSheet(DARK_THEME_QSS)


def run_gui():
    """Entry point for the Desktop GUI."""
    app = QApplication.instance() or QApplication(sys.argv)
    window = MainWindow()
    window.show()
    return app.exec_() if hasattr(app, "exec_") else app.exec()


if __name__ == "__main__":
    sys.exit(run_gui())

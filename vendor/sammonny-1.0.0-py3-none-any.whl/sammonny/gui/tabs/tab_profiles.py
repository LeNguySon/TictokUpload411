"""
Profiles Management Tab for SamMonny Antidetect Suite.
"""

from __future__ import annotations
import threading
from typing import Optional, List

try:
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
        QTableWidgetItem, QHeaderView, QMessageBox, QInputDialog, QLabel
    )
    from PyQt5.QtCore import Qt, pyqtSignal, QObject
except ImportError:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
        QTableWidgetItem, QHeaderView, QMessageBox, QInputDialog, QLabel
    )
    from PySide6.QtCore import Qt, Signal as pyqtSignal, QObject

from sammonny.core.client import SamMonnyDaemonClient
from sammonny.core.models import ProfileInfo
from sammonny.engine.core import AntidetectEngine


class ProfilesTab(QWidget):
    """Manages browser profiles lifecycle and fingerprint cloning."""

    def __init__(self, engine: AntidetectEngine, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.engine = engine
        self.daemon = engine.daemon
        self._init_ui()
        self.refresh_profiles()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        # Toolbar
        toolbar = QHBoxLayout()
        self.btn_refresh = QPushButton("🔄 Refresh")
        self.btn_refresh.clicked.connect(self.refresh_profiles)

        self.btn_create = QPushButton("➕ New Profile")
        self.btn_create.setObjectName("btn-success")
        self.btn_create.clicked.connect(self.on_create_profile)

        self.btn_start = QPushButton("▶ Launch")
        self.btn_start.clicked.connect(self.on_start_profile)

        self.btn_stop = QPushButton("⏹ Stop")
        self.btn_stop.setObjectName("btn-danger")
        self.btn_stop.clicked.connect(self.on_stop_profile)

        self.btn_clone = QPushButton("🧬 Clone & Mutate")
        self.btn_clone.clicked.connect(self.on_clone_profile)

        self.btn_delete = QPushButton("🗑 Delete")
        self.btn_delete.setObjectName("btn-danger")
        self.btn_delete.clicked.connect(self.on_delete_profile)

        toolbar.addWidget(self.btn_refresh)
        toolbar.addWidget(self.btn_create)
        toolbar.addWidget(self.btn_start)
        toolbar.addWidget(self.btn_stop)
        toolbar.addWidget(self.btn_clone)
        toolbar.addWidget(self.btn_delete)
        toolbar.addStretch()

        layout.addLayout(toolbar)

        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Profile ID", "Name", "OS", "Proxy", "Status"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        layout.addWidget(self.table)

    def refresh_profiles(self):
        def _task():
            try:
                profiles = self.engine.list_profiles()
            except Exception:
                profiles = []
            return profiles

        # Fast background query or direct
        profiles = _task()
        self.table.setRowCount(len(profiles))
        for row, p in enumerate(profiles):
            self.table.setItem(row, 0, QTableWidgetItem(p.id))
            self.table.setItem(row, 1, QTableWidgetItem(p.name))
            self.table.setItem(row, 2, QTableWidgetItem(p.os.upper()))
            self.table.setItem(row, 3, QTableWidgetItem(p.proxy or "Direct (No Proxy)"))
            self.table.setItem(row, 4, QTableWidgetItem(p.status.upper()))

    def _get_selected_profile_id(self) -> Optional[str]:
        selected = self.table.selectedItems()
        if not selected:
            return None
        row = selected[0].row()
        return self.table.item(row, 0).text()

    def on_create_profile(self):
        name, ok = QInputDialog.getText(self, "Create Profile", "Enter Profile Name:")
        if ok and name:
            try:
                self.engine.create_profile(name=name.strip())
                self.refresh_profiles()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to create profile: {e}")

    def on_start_profile(self):
        pid = self._get_selected_profile_id()
        if not pid:
            QMessageBox.warning(self, "Warning", "Please select a profile to launch.")
            return

        try:
            ws_url = self.daemon.start_profile(pid)
            QMessageBox.information(self, "Launched", f"Profile {pid} launched successfully!\nCDP WS: {ws_url}")
            self.refresh_profiles()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to launch profile: {e}")

    def on_stop_profile(self):
        pid = self._get_selected_profile_id()
        if not pid:
            return
        try:
            self.daemon.stop_profile(pid)
            self.refresh_profiles()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to stop profile: {e}")

    def on_clone_profile(self):
        pid = self._get_selected_profile_id()
        if not pid:
            QMessageBox.warning(self, "Warning", "Please select a profile to clone.")
            return

        name, ok = QInputDialog.getText(self, "Clone Profile", "Enter Cloned Profile Name:")
        if ok and name:
            try:
                cloned = self.engine.clone_profile(source_id=pid, new_name=name.strip())
                QMessageBox.information(
                    self, "Success",
                    f"Profile cloned successfully!\nNew ID: {cloned.id}\nFingerprint mutated with unique Canvas/Audio noise."
                )
                self.refresh_profiles()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to clone profile: {e}")

    def on_delete_profile(self):
        pid = self._get_selected_profile_id()
        if not pid:
            return
        confirm = QMessageBox.question(
            self, "Confirm Delete", f"Are you sure you want to delete profile {pid}?",
            QMessageBox.Yes | QMessageBox.No
        )
        if confirm == QMessageBox.Yes:
            try:
                self.daemon.delete_profile(pid)
                self.refresh_profiles()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to delete profile: {e}")

"""
Industrial Dark Theme Stylesheet for SamMonny Antidetect Suite.
"""

DARK_THEME_QSS = """
QMainWindow, QDialog {
    background-color: #121418;
    color: #e2e8f0;
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    font-size: 13px;
}

QWidget {
    background-color: #121418;
    color: #e2e8f0;
}

QTabWidget::pane {
    border: 1px solid #232730;
    background-color: #181b22;
    border-radius: 6px;
    margin-top: -1px;
}

QTabBar::tab {
    background-color: #181b22;
    color: #94a3b8;
    padding: 10px 20px;
    margin-right: 4px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    border: 1px solid #232730;
    font-weight: 600;
}

QTabBar::tab:selected {
    background-color: #232730;
    color: #38bdf8;
    border-bottom: 2px solid #38bdf8;
}

QTabBar::tab:hover:!selected {
    background-color: #1e222a;
    color: #cbd5e1;
}

QGroupBox {
    border: 1px solid #232730;
    border-radius: 6px;
    margin-top: 12px;
    padding-top: 14px;
    font-weight: bold;
    color: #38bdf8;
}

QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 0 8px;
    background-color: #181b22;
}

QTableWidget {
    background-color: #181b22;
    border: 1px solid #232730;
    gridline-color: #232730;
    border-radius: 6px;
    selection-background-color: #2563eb;
    selection-color: #ffffff;
}

QHeaderView::section {
    background-color: #121418;
    color: #94a3b8;
    padding: 6px;
    border: 1px solid #232730;
    font-weight: bold;
}

QPushButton {
    background-color: #2563eb;
    color: #ffffff;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
    font-weight: 600;
}

QPushButton:hover {
    background-color: #1d4ed8;
}

QPushButton:pressed {
    background-color: #1e40af;
}

QPushButton:disabled {
    background-color: #1e293b;
    color: #64748b;
}

QPushButton#btn-danger {
    background-color: #dc2626;
}

QPushButton#btn-danger:hover {
    background-color: #b91c1c;
}

QPushButton#btn-success {
    background-color: #16a34a;
}

QPushButton#btn-success:hover {
    background-color: #15803d;
}

QLineEdit, QComboBox, QTextEdit {
    background-color: #0f1115;
    border: 1px solid #2d3340;
    border-radius: 4px;
    padding: 6px 10px;
    color: #f8fafc;
}

QLineEdit:focus, QComboBox:focus, QTextEdit:focus {
    border: 1px solid #38bdf8;
}

QProgressBar {
    border: 1px solid #232730;
    border-radius: 4px;
    text-align: center;
    color: #f8fafc;
    background-color: #0f1115;
}

QProgressBar::chunk {
    background-color: #0284c7;
    border-radius: 3px;
}

QStatusBar {
    background-color: #0f1115;
    color: #94a3b8;
    border-top: 1px solid #232730;
}
"""

"""
Anti-Bot & Web Tracking Telemetry Inspector and Decoder.
Intercepts, parses, and decodes user-tracking and bot-detection telemetry packets sent to:
- Cloudflare Turnstile & Bot Management (/cdn-cgi/challenge-platform/)
- DataDome Sensor Tags (datadome.co)
- Akamai Bot Manager (sensor_data, /_bm/_data)
- FingerprintJS Pro / CreepJS Fingerprinting Beacons
- Google reCAPTCHA / Signals Enterprise
- General Canvas/Audio/WebGL/Biometric Surveillance Beacons
"""

from __future__ import annotations
import base64
import json
import re
import urllib.parse
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Union

from sammonny.network.models import NetworkRequest, NetworkResponse


@dataclass
class TelemetryReport:
    """Detailed audit of an intercepted web surveillance / anti-bot packet."""
    request_id: str
    target_platform: str  # Cloudflare, DataDome, Akamai, FingerprintJS, Google, or Generic
    beacon_url: str
    method: str
    timestamp: float
    probed_vectors: List[str] = field(default_factory=list)
    raw_payload_size: int = 0
    decoded_parameters: Dict[str, Any] = field(default_factory=dict)
    orbita_defense_applied: List[str] = field(default_factory=list)

    def summary(self) -> str:
        vectors_str = ", ".join(self.probed_vectors) if self.probed_vectors else "General Beacon"
        return f"[{self.target_platform}] {self.beacon_url[:60]}... | Vectors: {vectors_str} ({len(self.decoded_parameters)} params)"


class AntiBotTelemetryDecoder:
    """
    Decodes complex anti-bot surveillance payloads sent by websites to track users.
    Maps probed fingerprint parameters to Orbita's native C++ kernel masking defenses.
    """

    KNOWN_PLATFORMS = {
        "cloudflare": [
            "challenges.cloudflare.com",
            "/cdn-cgi/challenge-platform/",
            "cf-chl-widget",
            "cloudflare-turnstile",
        ],
        "datadome": [
            "datadome.co",
            "api-js.datadome.co",
            "tags.js",
            "dd.js",
        ],
        "akamai": [
            "/_bm/_data",
            "sensor_data",
            "akamai",
            "akamaitechnologies",
        ],
        "kasada": [
            "149e9513-01fa-4fb0-a84e-568686de6038",
            "kasada",
            "kpsdk",
        ],
        "fingerprintjs": [
            "api.fpjs.io",
            "fingerprintjs",
            "fpjs",
            "getbrowserfingerprint",
        ],
        "google_recaptcha": [
            "google.com/recaptcha",
            "recaptcha/api2",
            "recaptchaenterprise",
        ],
    }

    @classmethod
    def identify_platform(cls, url: str) -> Optional[str]:
        """Identifies known anti-bot / telemetry surveillance provider."""
        url_lower = url.lower()
        for platform, patterns in cls.KNOWN_PLATFORMS.items():
            if any(p in url_lower for p in patterns):
                return platform
        return None

    @classmethod
    def is_telemetry_request(cls, request: NetworkRequest) -> bool:
        """Determines if an outgoing network request is a surveillance / anti-bot probe."""
        if cls.identify_platform(request.url):
            return True

        # Check URL or query params for telemetry indicators
        telemetry_keywords = [
            "telemetry", "fingerprint", "collect", "analytics",
            "beacon", "tracking", "device_id", "bot_detector",
            "fp_data", "sensor", "audit", "challenge"
        ]
        url_lower = request.url.lower()
        if any(kw in url_lower for kw in telemetry_keywords):
            return True

        # Check post data
        if request.post_data and any(kw in request.post_data.lower() for kw in ["webgl", "canvas", "audiocontext", "webrtc"]):
            return True

        return False

    @classmethod
    def decode_request(
        cls,
        request: NetworkRequest,
        profile_preferences: Optional[Dict[str, Any]] = None,
    ) -> Optional[TelemetryReport]:
        """
        Inspects, parses, and unpacks an intercepted surveillance packet.
        Correlates probed properties with Orbita C++ kernel masking defenses.
        """
        if not cls.is_telemetry_request(request):
            return None

        platform = cls.identify_platform(request.url) or "Generic Surveillance"
        raw_body = request.post_data or ""
        decoded_params: Dict[str, Any] = {}
        probed_vectors: List[str] = []
        orbita_defenses: List[str] = []

        # 1. Parse Payload
        if raw_body:
            # Try JSON parsing
            try:
                decoded_params = json.loads(raw_body)
            except Exception:
                # Try URL-encoded query string parsing
                try:
                    parsed_qs = urllib.parse.parse_qs(raw_body)
                    decoded_params = {k: v[0] if len(v) == 1 else v for k, v in parsed_qs.items()}
                except Exception:
                    # Check for Base64 encoded payload
                    try:
                        b64_clean = re.sub(r'[^A-Za-z0-9+/=]', '', raw_body)
                        if len(b64_clean) > 20:
                            decoded_raw = base64.b64decode(b64_clean).decode('utf-8', errors='ignore')
                            try:
                                decoded_params = json.loads(decoded_raw)
                            except Exception:
                                decoded_params = {"raw_decoded": decoded_raw[:500]}
                    except Exception:
                        decoded_params = {"raw_payload": raw_body[:300]}

        # If payload was in query parameters of URL
        if not decoded_params and "?" in request.url:
            qs = request.url.split("?", 1)[1]
            try:
                parsed_qs = urllib.parse.parse_qs(qs)
                decoded_params = {k: v[0] if len(v) == 1 else v for k, v in parsed_qs.items()}
            except Exception:
                pass

        # 2. Analyze Probed Vectors & Map to Orbita C++ Defenses
        param_str = json.dumps(decoded_params).lower()

        # Canvas Fingerprinting Probe
        if any(w in param_str for w in ["canvas", "todataurl", "getimagedata", "canvas_hash", "canvas_noise"]):
            probed_vectors.append("Canvas 2D Hash")
            orbita_defenses.append(
                "Orbita C++ Kernel html_canvas_element.cc: Sub-pixel noise (gologin.canvasNoise) applied directly in SkCanvas buffer."
            )

        # WebGL & GPU Probe
        if any(w in param_str for w in ["webgl", "unmasked_renderer", "unmasked_vendor", "shader", "webgpu", "gl_vendor"]):
            probed_vectors.append("WebGL / GPU Architecture")
            orbita_defenses.append(
                "Orbita C++ Kernel gl.getParameter(): Replaced native GPU strings with ANGLE metadata & noise."
            )

        # AudioContext Fingerprinting Probe
        if any(w in param_str for w in ["audiocontext", "oscillator", "analyser", "dynamicscompressor", "audio_hash"]):
            probed_vectors.append("AudioContext Acoustic Signature")
            orbita_defenses.append(
                "Orbita C++ Kernel AudioBuffer::getChannelData: Micro-float noise injection (1e-7) applied before JS readback."
            )

        # WebRTC / Local IP Probe
        if any(w in param_str for w in ["webrtc", "rtcpeerconnection", "ice_candidates", "local_ip", "stun"]):
            probed_vectors.append("WebRTC Virtual NIC & Local IP")
            orbita_defenses.append(
                "Chromium Launch Flag: --force-webrtc-ip-handling-policy=disable_non_proxied_udp blocked local subnets."
            )

        # Navigator & Hardware Emulation Probe
        if any(w in param_str for w in ["hardwareconcurrency", "devicememory", "platform", "useragent", "dpr", "cores"]):
            probed_vectors.append("Hardware Specs (CPU/RAM/Platform)")
            orbita_defenses.append(
                "Orbita C++ Kernel Navigator overrides: Emulated genuine platform without prototype getter traps."
            )

        # Biometric Behavioral Probe (Mouse & Keystroke kinematics)
        if any(w in param_str for w in ["mouse", "moves", "clicks", "keystroke", "dwell", "trajectory", "fitts"]):
            probed_vectors.append("Human Biometric Movement Curves")
            orbita_defenses.append(
                "SamMonny SDK Kinematics: Minimum Jerk 5th-order Spline + 10Hz physiological tremor + 2D Gaussian clicks."
            )

        # Automation Flag Probe (navigator.webdriver)
        if any(w in param_str for w in ["webdriver", "automation", "phantom", "selenium", "cdc_", "chromedriver"]):
            probed_vectors.append("Automation Driver Flags (navigator.webdriver)")
            orbita_defenses.append(
                "Orbita C++ Kernel Patch: navigator.webdriver forced to false/undefined at Chromium C++ source level."
            )

        if not probed_vectors:
            probed_vectors.append("Telemetry Metadata Probe")

        return TelemetryReport(
            request_id=request.request_id,
            target_platform=platform,
            beacon_url=request.url,
            method=request.method,
            timestamp=request.timestamp,
            probed_vectors=probed_vectors,
            raw_payload_size=len(raw_body),
            decoded_parameters=decoded_params,
            orbita_defense_applied=orbita_defenses,
        )

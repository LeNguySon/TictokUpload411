"""
Core Antidetect Automation Engine.
Unified facade integrating Profiles, Proxy Pool, DOM Automation,
Computer Vision, Batch Workers, and Resource Management.
"""

from __future__ import annotations
import shutil
import uuid
import json
import time
from pathlib import Path
from typing import List, Dict, Optional, Union, Callable, Any
from concurrent.futures import ThreadPoolExecutor, as_completed

from sammonny.core.client import SamMonnyDaemonClient
from sammonny.core.models import ProfileInfo, ProxyItem
from sammonny.proxy.pool import ProxyPool
from sammonny.engine.session import AntidetectSession


class AntidetectEngine:
    """The central unified Antidetect Engine instance."""

    def __init__(
        self,
        base_url: str = "http://127.0.0.1:7654",
        sdk_url: str = "http://127.0.0.1:36912",
        profiles_dir: Optional[Union[str, Path]] = None,
        proxy_storage: Optional[Union[str, Path]] = None,
    ):
        self.daemon = SamMonnyDaemonClient(base_url=base_url, sdk_url=sdk_url)
        self.profiles_dir = Path(profiles_dir or "profiles")
        self.proxy_pool = ProxyPool(storage_path=proxy_storage or "proxies.json")

    # =========================================================================
    # Session Factory
    # =========================================================================

    def session(
        self,
        profile_id: str,
        proxy: Optional[Union[str, ProxyItem]] = None,
        headless: bool = False,
        auto_stop_on_exit: bool = True,
        auto_proxy: bool = False,
    ) -> AntidetectSession:
        """
        Creates a fluent, reusable AntidetectSession for profile_id.
        Optionally assigns a static proxy or allocates one from the proxy pool.
        """
        if auto_proxy and not proxy:
            allocated = self.proxy_pool.sticky(profile_id)
            if allocated:
                proxy = allocated

        if proxy:
            proxy_url = proxy.to_url() if isinstance(proxy, ProxyItem) else proxy
            # Update profile proxy via daemon if needed
            try:
                self.daemon._request("PUT", f"/api/v1/profiles/{profile_id}", {"proxy": proxy_url})
            except Exception:
                pass

        prof_dir = self.profiles_dir / profile_id
        return AntidetectSession(
            profile_id=profile_id,
            daemon_client=self.daemon,
            profile_dir=prof_dir,
            auto_stop_on_exit=auto_stop_on_exit,
        )

    # =========================================================================
    # Profile Operations & Cloning
    # =========================================================================

    def list_profiles(self) -> List[ProfileInfo]:
        return self.daemon.list_profiles()

    def create_profile(
        self,
        name: str,
        os_name: str = "win",
        proxy: Optional[Union[str, ProxyItem]] = None,
        group: Optional[str] = None,
    ) -> ProfileInfo:
        p_url = proxy.to_url() if isinstance(proxy, ProxyItem) else proxy
        return self.daemon.create_profile(name=name, os_name=os_name, proxy=p_url, group=group)

    def clone_profile(self, source_id: str, new_name: Optional[str] = None) -> ProfileInfo:
        """
        Deep-clones a profile directory, regenerates noisy hardware fingerprints
        (Canvas, AudioContext, WebGL), and registers a new profile ID.
        """
        source_dir = self.profiles_dir / source_id
        if not source_dir.exists():
            default_env = os.environ.get("SAMMONNY_PROFILES_DIR")
            if default_env and (Path(default_env) / source_id).exists():
                source_dir = Path(default_env) / source_id

        new_id = str(uuid.uuid4())
        target_dir = self.profiles_dir / new_id
        name = new_name or f"Clone_{source_id[:6]}"

        # Copy directory tree if exists
        if source_dir.exists():
            shutil.copytree(source_dir, target_dir, dirs_exist_ok=True)
            # Remove lockfiles
            for lock in target_dir.glob("**/lockfile"):
                try:
                    lock.unlink()
                except Exception:
                    pass

            # Mutate Preferences JSON with randomized canvas & audio noise
            pref_file = target_dir / "Default" / "Preferences"
            if pref_file.exists():
                try:
                    with open(pref_file, "r", encoding="utf-8") as f:
                        prefs = json.load(f)
                    gl_cfg = prefs.setdefault("gologin", {})
                    gl_cfg["profile_id"] = new_id
                    gl_cfg["name"] = name
                    # Add micro-variation to canvas noise
                    import random
                    gl_cfg["canvasNoise"] = round(random.uniform(5.0, 15.0), 8)
                    gl_cfg.setdefault("audioContext", {})["noiseValue"] = random.uniform(1e-7, 9e-7)

                    with open(pref_file, "w", encoding="utf-8") as f:
                        json.dump(prefs, f, indent=2)
                except Exception:
                    pass

        # Register in daemon if online, otherwise return local ProfileInfo
        try:
            return self.daemon.create_profile(name=name)
        except Exception:
            return ProfileInfo(id=new_id, name=name, os="win", status="stopped")


    # =========================================================================
    # Parallel Batch Runner
    # =========================================================================

    def batch_run(
        self,
        profile_ids: List[str],
        task_fn: Callable[[AntidetectSession], Any],
        max_workers: int = 3,
        headless: bool = True,
        auto_proxy: bool = True,
    ) -> Dict[str, Any]:
        """
        Executes task_fn concurrently across multiple browser profiles.
        Automatically distributes proxies and handles individual worker lifecycle.
        """
        results: Dict[str, Any] = {}

        def _worker(pid: str) -> Tuple[str, Any, Optional[str]]:
            try:
                with self.session(pid, headless=headless, auto_proxy=auto_proxy) as sess:
                    res = task_fn(sess)
                    return (pid, res, None)
            except Exception as e:
                return (pid, None, str(e))

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_pid = {executor.submit(_worker, pid): pid for pid in profile_ids}
            for fut in as_completed(future_to_pid):
                pid, res, err = fut.result()
                results[pid] = {"success": err is None, "result": res, "error": err}

        return results

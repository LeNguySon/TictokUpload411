"""
sammonny.platforms
==================
High-level vertical platform automation workflows (TikTok, Social, Gaming, E-commerce).
"""

from sammonny.platforms.tiktok import TikTokPipeline

__all__ = ["TikTokPipeline"]


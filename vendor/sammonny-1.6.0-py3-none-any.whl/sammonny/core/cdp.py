"""
Direct Chrome DevTools Protocol (CDP) WebSocket Client.
Provides both Synchronous and Asynchronous interfaces for DOM-aware automation,
mouse event dispatching, cookie harvesting, and Skia surface capture.
"""

from __future__ import annotations
import json
import time
import base64
import logging
import urllib.request
import threading
import queue
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, Optional, Tuple, List, Callable
from sammonny.core.exceptions import CdpError
from sammonny.core.models import Point, Rect, CookieItem

logger = logging.getLogger("sammonny.cdp")

try:
    import websockets
    import websockets.sync.client as ws_sync
    HAS_WEBSOCKETS = True
except ImportError:
    HAS_WEBSOCKETS = False


def resolve_page_ws_url(ws_url: str, timeout: float = 3.0) -> str:
    """
    If ws_url is a Browser target (e.g. /devtools/browser/uuid), query
    http://host:port/json to find an active 'page' target WebSocket URL.
    """
    if "/devtools/browser/" not in ws_url:
        return ws_url

    clean = ws_url.replace("ws://", "").replace("wss://", "")
    host_port = clean.split("/")[0]
    json_url = f"http://{host_port}/json"

    try:
        req = urllib.request.Request(json_url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            for target in data:
                if target.get("type") == "page" and "webSocketDebuggerUrl" in target:
                    return target["webSocketDebuggerUrl"]
    except Exception:
        pass

    return ws_url


class SyncCdpClient:
    """
    Synchronous Duplex CDP Client using websockets.sync.
    Supports concurrent request/response commands and asynchronous background event streaming.
    """

    def __init__(self, ws_url: str, timeout: float = 30.0):
        if not HAS_WEBSOCKETS:
            raise CdpError("The 'websockets' package is required for direct CDP connectivity.")
        self.raw_ws_url = ws_url
        self.resolved_ws_url = resolve_page_ws_url(ws_url)
        self.timeout = timeout
        self.ws: Optional[Any] = None
        self._cmd_id = 0
        self._send_lock = threading.Lock()
        self._pending_commands: Dict[int, queue.Queue] = {}
        self._event_handlers: Dict[str, List[Callable[[Dict[str, Any]], None]]] = {}
        self._reader_thread: Optional[threading.Thread] = None
        self._running = False
        self._event_executor: Optional[ThreadPoolExecutor] = None
        self._isolated_context_id: Optional[int] = None
        self.last_mouse_pos = Point(100.0, 100.0)

    def connect(self) -> SyncCdpClient:
        try:
            self.ws = ws_sync.connect(self.resolved_ws_url, open_timeout=self.timeout)
            self._running = True
            if not self._event_executor:
                self._event_executor = ThreadPoolExecutor(max_workers=8, thread_name_prefix="cdp-evt")
            self._reader_thread = threading.Thread(target=self._reader_loop, daemon=True)
            self._reader_thread.start()
            return self
        except Exception as e:
            raise CdpError(f"Failed to connect CDP WebSocket to {self.resolved_ws_url}: {e}") from e

    def close(self) -> None:
        self._running = False
        if self._event_executor:
            try:
                self._event_executor.shutdown(wait=False)
            except Exception:
                pass
            self._event_executor = None
        if self.ws:
            try:
                self.ws.close()
            except Exception:
                pass
            self.ws = None
        if self._reader_thread and self._reader_thread.is_alive():
            self._reader_thread.join(timeout=1.0)
            self._reader_thread = None

    def __enter__(self) -> SyncCdpClient:
        return self.connect()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def _reader_loop(self) -> None:
        """Background thread continuously reading messages from WebSocket."""
        while self._running and self.ws:
            try:
                raw_msg = self.ws.recv(timeout=0.3)
                if not raw_msg:
                    continue
                msg = json.loads(raw_msg)

                # Check if it's a response to a command
                if "id" in msg:
                    cmd_id = msg["id"]
                    q = self._pending_commands.get(cmd_id)
                    if q:
                        q.put(msg)
                # Check if it's a server push event
                elif "method" in msg:
                    self._dispatch_event(msg["method"], msg.get("params", {}))
            except (TimeoutError, Exception) as e:
                # Normal timeout from recv()
                if "timed out" in str(e).lower():
                    continue
                if not self._running:
                    break
                time.sleep(0.01)

    def on(self, event_name: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """Register an event listener for CDP events (e.g. 'Network.responseReceived', 'Network.*', '*')."""
        self._event_handlers.setdefault(event_name, []).append(handler)

    def off(self, event_name: str, handler: Optional[Callable] = None) -> None:
        """Unregister an event listener."""
        if handler:
            if event_name in self._event_handlers:
                self._event_handlers[event_name] = [
                    h for h in self._event_handlers[event_name] if h != handler
                ]
        else:
            self._event_handlers.pop(event_name, None)

    def _dispatch_event(self, method: str, params: Dict[str, Any]) -> None:
        handlers = list(self._event_handlers.get(method, []))
        if "." in method:
            domain = method.split(".", 1)[0] + ".*"
            handlers.extend(self._event_handlers.get(domain, []))
        handlers.extend(self._event_handlers.get("*", []))
        if not handlers:
            return

        executor = self._event_executor
        for h in handlers:
            if executor and not executor._shutdown:
                executor.submit(self._safe_call_handler, h, params, method)
            else:
                self._safe_call_handler(h, params, method)

    def _safe_call_handler(self, handler: Callable, params: Dict[str, Any], method: str) -> None:
        try:
            handler(params)
        except Exception as e:
            logger.error(f"Error in CDP event handler for {method}: {e}")

    def send(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        if not self.ws or not self._running:
            self.connect()

        with self._send_lock:
            self._cmd_id += 1
            cmd_id = self._cmd_id

        q: queue.Queue = queue.Queue(maxsize=1)
        self._pending_commands[cmd_id] = q
        payload = {
            "id": cmd_id,
            "method": method,
            "params": params or {},
        }

        try:
            with self._send_lock:
                self.ws.send(json.dumps(payload))

            try:
                msg = q.get(timeout=self.timeout)
            except queue.Empty:
                raise CdpError(f"CDP command '{method}' timed out after {self.timeout}s")

            if "error" in msg:
                raise CdpError(f"CDP command '{method}' failed: {msg['error']}")
            return msg.get("result", {})
        except CdpError:
            raise
        except Exception as e:
            raise CdpError(f"CDP command '{method}' communication error: {e}") from e
        finally:
            self._pending_commands.pop(cmd_id, None)

    # =========================================================================
    # Navigation & Evaluation
    # =========================================================================

    def navigate(self, url: str) -> Dict[str, Any]:
        self._isolated_context_id = None
        return self.send("Page.navigate", {"url": url})

    def evaluate(self, expression: str) -> Any:
        res = self.send(
            "Runtime.evaluate",
            {
                "expression": expression,
                "returnByValue": True,
                "awaitPromise": True,
            },
        )
        result = res.get("result", {})
        return result.get("value")

    def get_or_create_isolated_world(self, world_name: str = "SamMonnyStealthWorld") -> Optional[int]:
        """
        Creates or retrieves an Isolated Execution World (V8 Isolated World).
        JavaScript in the webpage cannot observe or access variables created in this world.
        """
        if self._isolated_context_id is not None:
            return self._isolated_context_id

        try:
            tree = self.send("Page.getFrameTree", {})
            frame_id = tree.get("frameTree", {}).get("frame", {}).get("id")
            if not frame_id:
                return None
            world_res = self.send(
                "Page.createIsolatedWorld",
                {
                    "frameId": frame_id,
                    "worldName": world_name,
                    "grantUniveralAccess": True,
                },
            )
            self._isolated_context_id = world_res.get("executionContextId")
            return self._isolated_context_id
        except Exception as e:
            logger.debug(f"Isolated world creation fallback: {e}")
            return None

    def evaluate_isolated(self, expression: str, world_name: str = "SamMonnyStealthWorld") -> Any:
        """
        Executes JavaScript inside a stealth V8 Isolated World.
        Completely invisible to Kasada, DataDome, Cloudflare Turnstile, and page scripts.
        Falls back to regular evaluate if isolated world creation is unsupported.
        """
        ctx_id = self.get_or_create_isolated_world(world_name=world_name)
        params: Dict[str, Any] = {
            "expression": expression,
            "returnByValue": True,
            "awaitPromise": True,
        }
        if ctx_id is not None:
            params["contextId"] = ctx_id

        res = self.send("Runtime.evaluate", params)
        result = res.get("result", {})
        return result.get("value")

    # =========================================================================
    # DOM Node & Bounding Box Queries
    # =========================================================================

    def get_element_rect(self, selector: str) -> Optional[Rect]:
        """
        Calculates viewport-relative BoundingClientRect of selector via in-DOM evaluation.
        Works across all modern HTML5 and Web components.
        """
        js = f"""
        (() => {{
            const el = document.querySelector({json.dumps(selector)});
            if (!el) return null;
            el.scrollIntoView({{ behavior: 'instant', block: 'center', inline: 'center' }});
            const r = el.getBoundingClientRect();
            return {{
                x: r.x,
                y: r.y,
                width: r.width,
                height: r.height,
                top: r.top,
                left: r.left,
                visible: r.width > 0 && r.height > 0
            }};
        }})()
        """
        val = self.evaluate(js)
        if not val or not val.get("visible", False):
            return None
        return Rect(
            x=float(val["x"]),
            y=float(val["y"]),
            width=float(val["width"]),
            height=float(val["height"]),
        )

    # =========================================================================
    # Screenshots
    # =========================================================================

    def capture_screenshot(self, from_surface: bool = True) -> bytes:
        """Capture Skia GPU surface screenshot even if minimized."""
        res = self.send(
            "Page.captureScreenshot",
            {
                "format": "png",
                "fromSurface": from_surface,
                "captureBeyondViewport": False,
            },
        )
        data = res.get("data", "")
        return base64.b64decode(data)

    # =========================================================================
    # Cookies
    # =========================================================================

    def get_cookies(self, urls: Optional[List[str]] = None) -> List[CookieItem]:
        if urls:
            res = self.send("Network.getCookies", {"urls": urls})
        else:
            try:
                res = self.send("Storage.getCookies", {})
            except Exception:
                res = self.send("Network.getCookies", {})
        cookies_raw = res.get("cookies", [])
        return [CookieItem.from_dict(c) for c in cookies_raw]

    def set_cookie(self, cookie: CookieItem) -> None:
        params: Dict[str, Any] = {
            "name": cookie.name,
            "value": cookie.value,
            "domain": cookie.domain,
            "path": cookie.path,
            "secure": cookie.secure,
            "httpOnly": cookie.httpOnly,
        }
        if cookie.domain:
            clean_dom = cookie.domain.lstrip(".")
            params["url"] = f"https://{clean_dom}{cookie.path}" if cookie.secure else f"http://{clean_dom}{cookie.path}"
        if cookie.expirationDate:
            params["expires"] = cookie.expirationDate
        self.send("Network.setCookie", params)

    # =========================================================================
    # Native Mouse Dispatch
    # =========================================================================

    def dispatch_mouse(
        self,
        event_type: str,
        x: float,
        y: float,
        button: str = "none",
        click_count: int = 0,
        delta_x: float = 0.0,
        delta_y: float = 0.0,
    ) -> None:
        """
        Dispatches low-level mouse event directly to Chromium's RenderWidgetHost.
        Generates genuine event.isTrusted === true in DOM.
        """
        params: Dict[str, Any] = {
            "type": event_type,
            "x": round(x, 1),
            "y": round(y, 1),
            "button": button,
            "clickCount": click_count,
            "pointerType": "mouse",
            "timestamp": time.time(),
        }
        if event_type == "mouseWheel":
            params["deltaX"] = delta_x
            params["deltaY"] = delta_y

        self.send("Input.dispatchMouseEvent", params)
        if event_type == "mouseMoved":
            self.last_mouse_pos = Point(x, y)


class AsyncCdpClient:
    """Asynchronous CDP Client using websockets."""

    def __init__(self, ws_url: str, timeout: float = 30.0):
        if not HAS_WEBSOCKETS:
            raise CdpError("The 'websockets' package is required for direct CDP connectivity.")
        self.raw_ws_url = ws_url
        self.resolved_ws_url = resolve_page_ws_url(ws_url)
        self.timeout = timeout
        self.ws: Optional[Any] = None
        self._cmd_id = 0
        self._lock = threading.Lock()
        self.last_mouse_pos = Point(100.0, 100.0)

    async def connect(self) -> AsyncCdpClient:
        try:
            self.ws = await websockets.connect(self.resolved_ws_url, open_timeout=self.timeout)
            return self
        except Exception as e:
            raise CdpError(f"Failed to connect CDP WebSocket to {self.resolved_ws_url}: {e}") from e

    async def close(self) -> None:
        if self.ws:
            try:
                await self.ws.close()
            except Exception:
                pass
            self.ws = None

    async def __aenter__(self) -> AsyncCdpClient:
        return await self.connect()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def send(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        if not self.ws:
            await self.connect()

        self._cmd_id += 1
        cmd_id = self._cmd_id
        payload = {
            "id": cmd_id,
            "method": method,
            "params": params or {},
        }
        await self.ws.send(json.dumps(payload))

        start_time = time.time()
        while time.time() - start_time < self.timeout:
            raw_msg = await self.ws.recv()
            msg = json.loads(raw_msg)
            if msg.get("id") == cmd_id:
                if "error" in msg:
                    raise CdpError(f"CDP command '{method}' failed: {msg['error']}")
                return msg.get("result", {})

        raise CdpError(f"CDP command '{method}' timed out after {self.timeout}s")

    async def get_element_rect(self, selector: str) -> Optional[Rect]:
        js = f"""
        (() => {{
            const el = document.querySelector({json.dumps(selector)});
            if (!el) return null;
            el.scrollIntoView({{ behavior: 'instant', block: 'center', inline: 'center' }});
            const r = el.getBoundingClientRect();
            return {{
                x: r.x,
                y: r.y,
                width: r.width,
                height: r.height,
                visible: r.width > 0 && r.height > 0
            }};
        }})()
        """
        res = await self.send(
            "Runtime.evaluate",
            {"expression": js, "returnByValue": True, "awaitPromise": True},
        )
        val = res.get("result", {}).get("value")
        if not val or not val.get("visible", False):
            return None
        return Rect(
            x=float(val["x"]),
            y=float(val["y"]),
            width=float(val["width"]),
            height=float(val["height"]),
        )

    async def dispatch_mouse(
        self,
        event_type: str,
        x: float,
        y: float,
        button: str = "none",
        click_count: int = 0,
    ) -> None:
        params: Dict[str, Any] = {
            "type": event_type,
            "x": round(x, 1),
            "y": round(y, 1),
            "button": button,
            "clickCount": click_count,
            "pointerType": "mouse",
            "timestamp": time.time(),
        }
        await self.send("Input.dispatchMouseEvent", params)
        if event_type == "mouseMoved":
            self.last_mouse_pos = Point(x, y)

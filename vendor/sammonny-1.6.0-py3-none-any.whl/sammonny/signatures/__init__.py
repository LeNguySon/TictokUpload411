"""
sammonny.signatures
===================
Enterprise signature extraction and generation suite for browser-kernel and hardware-bound requests.
Provides dual-engine operation:
1. In-Kernel Live Harvesting via CDP (V8 runtime, byted_acrawler.sign, webmssdk, SecSDK, biometric warmup).
2. Profile-Bound Synthetic Computation (X-Gorgon, X-Bogus, A-Bogus, IDC geo-affinity, deterministic hardware tokens).
"""

from __future__ import annotations

from sammonny.signatures.bytedance_direct import (
    BYTE_DANCE_BOGUS_ALPHABET,
    compute_xgorgon,
    compute_xbogus,
    compute_abogus,
    compute_mobile_envelope,
    ttencrypt_payload,
)
from sammonny.signatures.device_context import (
    ProfileDeviceContext,
    get_profile_device_context,
    resolve_idc_endpoint,
)
from sammonny.signatures.kernel_live import CDPLiveSigner
from sammonny.signatures.harvester import KernelSignatureHarvester

__all__ = [
    "BYTE_DANCE_BOGUS_ALPHABET",
    "compute_xgorgon",
    "compute_xbogus",
    "compute_abogus",
    "compute_mobile_envelope",
    "ttencrypt_payload",
    "ProfileDeviceContext",
    "get_profile_device_context",
    "resolve_idc_endpoint",
    "CDPLiveSigner",
    "KernelSignatureHarvester",
]


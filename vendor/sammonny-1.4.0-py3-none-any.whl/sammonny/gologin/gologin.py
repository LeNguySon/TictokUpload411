"""
100% Drop-in Compatible Replacement for Official GoLogin Python SDK (`gologin`).
Allows seamless migration from `from gologin import GoLogin` with zero code changes,
while adding direct integration with Playwright, Selenium, and SamMonny High-Performance Daemon.
"""

from __future__ import annotations
import os
import time
from typing import Any, Dict, List, Optional, Union
from pathlib import Path

from sammonny.core.client import SamMonnyDaemonClient
from sammonny.core.exceptions import ProfileError
from sammonny.core.models import CookieItem, ProfileInfo


class GoLogin:
    """
    GoLogin API client class matching official 'pygologin' signature and capabilities.
    """

    def __init__(self, options: Optional[Dict[str, Any]] = None):
        options = options or {}
        self.options = options
        self.token = options.get("token", "local_dummy_token")
        self.profile_id = options.get("profile_id") or options.get("profileId", "")
        self.port = options.get("port", 36912)
        self.daemon_port = options.get("daemon_port", 7654)
        self.auto_sync = options.get("sync", False)
        self.headless = options.get("headless", False)
        self.executable_path = options.get("executablePath")

        # Daemon Clients
        self.client = SamMonnyDaemonClient(
            base_url=f"http://127.0.0.1:{self.daemon_port}",
            sdk_url=f"http://127.0.0.1:{self.port}",
        )

        self._debugger_address: Optional[str] = None
        self._ws_url: Optional[str] = None

    @property
    def debugger_address(self) -> Optional[str]:
        return self._debugger_address

    @property
    def ws_url(self) -> Optional[str]:
        return self._ws_url

    def start(self) -> str:
        """
        Starts the profile and returns the Chrome debugger address string (e.g. '127.0.0.1:port')
        or WebSocket URL depending on format requested by automation framework.
        """
        if not self.profile_id:
            raise ProfileError("Cannot start profile: 'profile_id' is not specified.")

        # Try starting via port 36912 (SDK standard) or fallback to 7654
        try:
            self._ws_url = self.client.start_profile(
                self.profile_id,
                sync=self.auto_sync,
                headless=self.headless,
                prefer_sdk_port=True,
            )
        except Exception:
            self._ws_url = self.client.start_profile(
                self.profile_id,
                sync=self.auto_sync,
                headless=self.headless,
                prefer_sdk_port=False,
            )

        if not self._ws_url:
            raise ProfileError(f"Failed to start profile '{self.profile_id}': No WebSocket URL returned.")

        # Parse debuggerAddress (e.g., 127.0.0.1:PORT) from WebSocket URL
        clean_ws = self._ws_url.replace("ws://", "").replace("wss://", "")
        host_port = clean_ws.split("/")[0]
        self._debugger_address = host_port

        return self._debugger_address

    def stop(self) -> bool:
        """Stops the currently running profile session."""
        if not self.profile_id:
            return False

        # Attempt stopping via both ports
        res = self.client.stop_profile(self.profile_id, prefer_sdk_port=True)
        if not res:
            res = self.client.stop_profile(self.profile_id, prefer_sdk_port=False)

        self._debugger_address = None
        self._ws_url = None
        return res

    # =========================================================================
    # Profile CRUD APIs
    # =========================================================================

    def get_profiles(self) -> List[Dict[str, Any]]:
        """List all profiles available in local storage."""
        profiles = self.client.list_profiles()
        return [p.raw_data or {"id": p.id, "name": p.name} for p in profiles]

    def create(self, options: Dict[str, Any]) -> str:
        """Creates a profile with specified settings and returns its ID."""
        name = options.get("name", f"Profile_{int(time.time())}")
        os_type = options.get("os", "win")
        proxy = options.get("proxy")
        p = self.client.create_profile(name=name, os_name=os_type, proxy=proxy)
        self.profile_id = p.id
        return p.id

    def delete(self, profile_id: Optional[str] = None) -> bool:
        target_id = profile_id or self.profile_id
        if not target_id:
            return False
        return self.client.delete_profile(target_id)

    # =========================================================================
    # Automation Framework Adapters
    # =========================================================================

    def connect_playwright(self, playwright_instance: Any) -> Any:
        """
        Connects Playwright Chromium directly over CDP to this running profile.
        Usage:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                browser = gl.connect_playwright(p)
                page = browser.contexts[0].new_page()
        """
        if not self._ws_url and not self._debugger_address:
            self.start()

        endpoint = self._ws_url or f"http://{self._debugger_address}"
        return playwright_instance.chromium.connect_over_cdp(endpoint)

    def connect_selenium(self, chrome_options: Optional[Any] = None) -> Any:
        """
        Connects Selenium Chrome WebDriver to this running profile.
        Usage:
            driver = gl.connect_selenium()
            driver.get("https://iphey.com")
        """
        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options
        except ImportError:
            raise ImportError("Selenium is required to use 'connect_selenium()'. Run 'pip install selenium'.")

        if not self._debugger_address:
            self.start()

        options = chrome_options or Options()
        options.add_experimental_option("debuggerAddress", self._debugger_address)
        return webdriver.Chrome(options=options)

    # =========================================================================
    # Cookie Sync APIs
    # =========================================================================

    def get_cookies(self, profile_id: Optional[str] = None) -> List[Dict[str, Any]]:
        target_id = profile_id or self.profile_id
        cookies = self.client.get_cookies(target_id)
        return [c.to_dict() for c in cookies]

    def post_cookies(self, cookies: List[Dict[str, Any]], profile_id: Optional[str] = None) -> bool:
        target_id = profile_id or self.profile_id
        cookie_items = [CookieItem.from_dict(c) for c in cookies]
        return self.client.set_cookies(target_id, cookie_items)

"""
In-Memory Payload Decoders & Deserializers.
Decodes MessagePack, XOR obfuscation, Base64 chunked buffers, and structured network packets.
"""

from __future__ import annotations
import base64
import json
from typing import Any, Dict, List, Optional, Union

try:
    import msgpack
    HAS_MSGPACK = True
except ImportError:
    HAS_MSGPACK = False


class MemoryDecoder:
    """Decodes in-memory obfuscated and serialized payloads."""

    @staticmethod
    def xor_decrypt(data: Union[bytes, bytearray], key: Union[bytes, str, int]) -> bytes:
        """Decrypts XOR-obfuscated byte buffers."""
        if isinstance(key, str):
            key_bytes = key.encode("utf-8")
        elif isinstance(key, int):
            key_bytes = bytes([key & 0xFF])
        else:
            key_bytes = key

        if not key_bytes:
            return bytes(data)

        key_len = len(key_bytes)
        return bytes([b ^ key_bytes[i % key_len] for i, b in enumerate(data)])

    @staticmethod
    def decode_base64(data: Union[str, bytes]) -> bytes:
        """Decodes standard or URL-safe base64 strings with automatic padding."""
        s = data.decode("utf-8") if isinstance(data, bytes) else str(data)
        s = s.strip()
        # Add required padding
        missing_padding = len(s) % 4
        if missing_padding:
            s += "=" * (4 - missing_padding)
        return base64.b64decode(s.replace("-", "+").replace("_", "/"))

    @staticmethod
    def decode_msgpack(data: bytes) -> Optional[Any]:
        """Decodes Cocos Creator / SystemJS MessagePack binary frames."""
        if not HAS_MSGPACK:
            return None
        try:
            return msgpack.unpackb(data, raw=False)
        except Exception:
            return None

    @staticmethod
    def extract_strings(data: bytes, min_len: int = 4) -> List[str]:
        """Extracts ASCII/UTF-8 readable string sequences from raw memory bytes."""
        result: List[str] = []
        current: List[int] = []

        for b in data:
            if 32 <= b <= 126 or b in (9, 10, 13):
                current.append(b)
            else:
                if len(current) >= min_len:
                    result.append(bytes(current).decode("utf-8", errors="ignore"))
                current = []

        if len(current) >= min_len:
            result.append(bytes(current).decode("utf-8", errors="ignore"))

        return result


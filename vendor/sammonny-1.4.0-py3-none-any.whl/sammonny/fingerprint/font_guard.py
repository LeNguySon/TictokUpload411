"""
sammonny.fingerprint.font_guard
===============================
Sub-Pixel Font Glyph Metrics & Anti-Fingerprinting Guard.
Detects, measures, and validates font layout metrics via HTML5 Canvas TextMetrics:
- ActualBoundingBoxAscent, ActualBoundingBoxDescent, and Sub-pixel Width.
- Audits OS Font Parity (DirectWrite on Windows vs CoreText on macOS vs FreeType on Linux).
- Protects against subtle Font Fingerprinting traps that measure DOM text bounds.
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
from typing import Any, Dict, List, Optional

from sammonny.core.cdp import SyncCdpClient

logger = logging.getLogger("sammonny.fingerprint.font_guard")

STANDARD_TEST_FONTS = [
    "Arial",
    "Times New Roman",
    "Segoe UI",
    "Calibri",
    "Courier New",
    "Georgia",
    "Verdana",
    "Trebuchet MS",
    "Tahoma",
]


@dataclass
class FontMetricItem:
    font_name: str
    width: float
    ascent: float
    descent: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "font": self.font_name,
            "width": self.width,
            "ascent": self.ascent,
            "descent": self.descent,
        }


class FontMetricsGuard:
    """
    Measures and audits sub-pixel font layout metrics inside the active browser runtime.
    """

    def __init__(self, cdp_client: SyncCdpClient) -> None:
        self.cdp = cdp_client

    def measure_fonts(
        self,
        fonts: Optional[List[str]] = None,
        font_size: int = 72,
        sample_text: str = "mmmmmmmmmmlliWWWWWW",
    ) -> Dict[str, FontMetricItem]:
        """
        Measures precise sub-pixel text bounding boxes across specified fonts
        using Canvas 2D TextMetrics in the running Chromium page context.
        """
        target_fonts = fonts or STANDARD_TEST_FONTS
        import json as py_json

        js_script = f"""
        (() => {{
            const fonts = {py_json.dumps(target_fonts)};
            const fontSize = {font_size};
            const testText = {py_json.dumps(sample_text)};
            const canvas = document.createElement('canvas');
            canvas.width = 1920;
            canvas.height = 200;
            const ctx = canvas.getContext('2d');
            const results = {{}};

            for (const f of fonts) {{
                ctx.font = `${{fontSize}}px "${{f}}", sans-serif`;
                const m = ctx.measureText(testText);
                results[f] = {{
                    width: Math.round(m.width * 100) / 100,
                    ascent: Math.round((m.actualBoundingBoxAscent || 0) * 100) / 100,
                    descent: Math.round((m.actualBoundingBoxDescent || 0) * 100) / 100
                }};
            }}
            return results;
        }})()
        """
        try:
            res = self.cdp.evaluate(js_script)
            if isinstance(res, dict):
                return {
                    f: FontMetricItem(
                        font_name=f,
                        width=data.get("width", 0.0),
                        ascent=data.get("ascent", 0.0),
                        descent=data.get("descent", 0.0),
                    )
                    for f, data in res.items()
                }
        except Exception as e:
            logger.debug("measure_fonts error: %s", e)
        return {}

    def audit_os_parity(self, expected_os: str = "win") -> Dict[str, Any]:
        """
        Audits font metrics to confirm the rendering engine matches expected OS characteristics.
        Windows (DirectWrite) vs macOS (CoreText) have distinct sub-pixel anti-aliasing ratios.
        """
        metrics = self.measure_fonts()
        if not metrics:
            return {"passed": False, "reason": "Could not measure font metrics in page context"}

        # Arial is standard reference
        arial = metrics.get("Arial")
        if not arial:
            return {"passed": False, "reason": "Reference font Arial missing"}

        # DirectWrite on Windows typically produces specific width ratio for Arial 72px
        os_lower = expected_os.lower()
        leak_detected = False
        notes = []

        if "win" in os_lower:
            # Expected width range for 19 chars 'mmmmmmmmmmlliWWWWWW' on Windows DirectWrite
            if arial.width < 900 or arial.width > 1200:
                leak_detected = True
                notes.append(f"Arial width {arial.width} out of expected DirectWrite range [900, 1200]")
            else:
                notes.append(f"Arial width {arial.width} matches Windows DirectWrite engine")

        return {
            "passed": not leak_detected,
            "expected_os": expected_os,
            "leak_detected": leak_detected,
            "notes": notes,
            "measured_count": len(metrics),
            "sample_arial": arial.to_dict() if arial else None,
        }


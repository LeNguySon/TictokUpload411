"""
Bayesian Browser Fingerprint Generator & Mutator.
Generates mathematically consistent antidetect configurations adhering to real-world browser telemetry:
Screen resolution, User-Agent, Client Hints, WebGL, AudioContext, Canvas noise, and Hardware specs.
"""

from __future__ import annotations
import random
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, asdict


COMMON_RESOLUTIONS = [
    (1920, 1080),  # 68% market share
    (2560, 1440),  # 16%
    (1536, 864),   # 8%
    (1366, 768),   # 8%
]

WEBGL_RENDERERS_WIN = [
    ("Google Inc. (NVIDIA)", "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)"),
    ("Google Inc. (NVIDIA)", "ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 Direct3D11 vs_5_0 ps_5_0, D3D11)"),
    ("Google Inc. (NVIDIA)", "ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER Direct3D11 vs_5_0 ps_5_0, D3D11)"),
    ("Google Inc. (Intel)", "ANGLE (Intel, Intel(R) Iris(R) Xe Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)"),
    ("Google Inc. (Intel)", "ANGLE (Intel, Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0, D3D11)"),
    ("Google Inc. (AMD)", "ANGLE (AMD, AMD Radeon RX 6700 XT Direct3D11 vs_5_0 ps_5_0, D3D11)"),
]

WEBGL_RENDERERS_MAC = [
    ("Apple Inc.", "Apple M1"),
    ("Apple Inc.", "Apple M2"),
    ("Apple Inc.", "Apple M3 Pro"),
]


@dataclass
class BrowserFingerprint:
    os: str
    user_agent: str
    screen_width: int
    screen_height: int
    device_pixel_ratio: float
    hardware_concurrency: int
    device_memory: int
    webgl_vendor: str
    webgl_renderer: str
    canvas_noise: float
    audio_noise: float
    timezone: str
    language: str

    def to_dict(self) -> Dict[str, Any]:
        """Serializes fingerprint to standard dictionary."""
        return self.to_gologin_preferences(profile_id="default", name="Default")

    def to_gologin_dict(self) -> Dict[str, Any]:
        return self.to_dict()

    def to_gologin_preferences(self, profile_id: str, name: str) -> Dict[str, Any]:
        """Maps to Orbita C++ Preferences structure under 'gologin' key."""
        return {
            "profile_id": profile_id,
            "name": name,
            "is_m1": self.os == "mac" and "Apple M" in self.webgl_renderer,
            "screenWidth": self.screen_width,
            "screenHeight": self.screen_height,
            "devicePixelRatio": self.device_pixel_ratio,
            "userAgent": self.user_agent,
            "navigator": {
                "platform": "Win32" if self.os == "win" else ("MacIntel" if self.os == "mac" else "Linux x86_64"),
                "max_touch_points": 0,
                "hardwareConcurrency": self.hardware_concurrency,
                "deviceMemory": self.device_memory,
            },
            "canvasMode": "noise",
            "canvasNoise": self.canvas_noise,
            "audioContext": {
                "enable": True,
                "noiseValue": self.audio_noise,
            },
            "webgl": {
                "mode": "noise",
                "vendor": self.webgl_vendor,
                "renderer": self.webgl_renderer,
            },
            "timezone": {
                "fillBasedOnIp": True,
                "timezone": self.timezone,
            },
            "languages": {
                "fillBasedOnIp": True,
                "languages": [self.language],
            },
        }


class FingerprintGenerator:
    """Generates authentic browser fingerprints sampled from real device distributions."""

    @staticmethod
    def generate(
        target_os: str = "win",
        country_code: Optional[str] = None,
        chrome_major_version: int = 124,
    ) -> BrowserFingerprint:
        # 1. Screen resolution
        w, h = random.choices(
            COMMON_RESOLUTIONS, weights=[0.68, 0.16, 0.08, 0.08], k=1
        )[0]

        # 2. Hardware specs
        cores = random.choice([4, 8, 12, 16])
        ram = random.choice([8, 16, 32])

        # 3. User Agent
        if target_os == "mac":
            ua = f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_major_version}.0.0.0 Safari/537.36"
            vendor, renderer = random.choice(WEBGL_RENDERERS_MAC)
        elif target_os == "lin":
            ua = f"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_major_version}.0.0.0 Safari/537.36"
            vendor, renderer = random.choice(WEBGL_RENDERERS_WIN)
        else:
            ua = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_major_version}.0.0.0 Safari/537.36"
            vendor, renderer = random.choice(WEBGL_RENDERERS_WIN)

        # 4. Noise factors
        canvas_noise = round(random.uniform(5.0, 15.0), 8)
        audio_noise = random.uniform(1e-7, 9e-7)

        # 5. Geolocation defaults
        cc = (country_code or "VN").upper()
        geo_map = {
            "VN": ("Asia/Ho_Chi_Minh", "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7"),
            "US": ("America/New_York", "en-US,en;q=0.9"),
            "GB": ("Europe/London", "en-GB,en;q=0.9"),
            "DE": ("Europe/Berlin", "de-DE,de;q=0.9,en;q=0.8"),
            "FR": ("Europe/Paris", "fr-FR,fr;q=0.9,en;q=0.8"),
            "JP": ("Asia/Tokyo", "ja-JP,ja;q=0.9,en;q=0.8"),
            "SG": ("Asia/Singapore", "en-SG,en;q=0.9,zh-CN;q=0.8"),
        }
        tz, lang = geo_map.get(cc, ("Asia/Ho_Chi_Minh", "vi-VN,vi;q=0.9,en-US;q=0.8"))

        return BrowserFingerprint(
            os=target_os,
            user_agent=ua,
            screen_width=w,
            screen_height=h,
            device_pixel_ratio=1.0 if w >= 1920 else 1.25,
            hardware_concurrency=cores,
            device_memory=ram,
            webgl_vendor=vendor,
            webgl_renderer=renderer,
            canvas_noise=canvas_noise,
            audio_noise=audio_noise,
            timezone=tz,
            language=lang,
        )

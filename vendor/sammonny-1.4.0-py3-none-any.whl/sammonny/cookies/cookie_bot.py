"""
Automated Cookie Bot & Profile Warm-up Agent.
Navigates through target websites, detects cookie banners across 15+ languages,
dispatches human-like interactions, and seeds authentic cookies & history.
"""

from __future__ import annotations
import time
import random
from typing import List, Optional, Callable
from sammonny.core.cdp import SyncCdpClient
from sammonny.dom.controller import DOMController
from sammonny.dom.mouse import HumanMouse

COOKIE_CONSENT_KEYWORDS = [
    # English
    "accept", "agree", "allow", "allow all", "accept all", "accept cookies", "i accept", "got it", "consent",
    # Vietnamese
    "chấp nhận", "chấp nhận tất cả", "đồng ý", "cho phép", "cho phép tất cả",
    # French
    "accepter", "accepter tout", "j'accepte", "autoriser", "tout autoriser",
    # German
    "akzeptieren", "alle akzeptieren", "zustimmen", "erlauben", "einverstanden",
    # Spanish
    "aceptar", "aceptar todo", "acepto", "permitir",
    # Portuguese
    "aceitar", "aceitar tudo", "concordo",
    # Italian
    "accetta", "accetta tutto", "acconsento",
]


class CookieBot:
    def __init__(
        self,
        cdp_client: SyncCdpClient,
        mouse: Optional[HumanMouse] = None,
        log_callback: Optional[Callable[[str], None]] = None,
    ):
        self.cdp = cdp_client
        self.dom = DOMController(cdp_client)
        self.mouse = mouse or HumanMouse(cdp_client)
        self.log = log_callback or (lambda msg: None)

    def warm_up(
        self,
        urls: List[str],
        dwell_min_sec: float = 3.0,
        dwell_max_sec: float = 7.0,
        scroll_pages: bool = True,
    ) -> int:
        """
        Navigates each URL in order, attempts consent acceptance, and dwells.
        Returns total number of cookies collected.
        """
        visited = 0
        for url in urls:
            url = url.strip()
            if not url:
                continue

            if not url.startswith("http://") and not url.startswith("https://"):
                url = f"https://{url}"

            self.log(f"CookieBot: Navigating to {url}...")
            try:
                self.cdp.navigate(url)
                # Wait for initial load
                time.sleep(random.uniform(2.0, 3.5))

                # Attempt consent banner detection
                self._handle_cookie_consent()

                # Natural scroll
                if scroll_pages:
                    self._simulate_reading_scroll()

                # Biological dwell
                dwell = random.uniform(dwell_min_sec, dwell_max_sec)
                self.log(f"CookieBot: Dwelling for {dwell:.1f}s on {url}")
                time.sleep(dwell)
                visited += 1
            except Exception as e:
                self.log(f"CookieBot warning on {url}: {e}")

        cookies = self.cdp.get_cookies()
        self.log(f"CookieBot: Finished {visited} sites. Total cookies collected: {len(cookies)}")
        return len(cookies)

    def _handle_cookie_consent(self) -> bool:
        """Finds any button or link whose text matches common consent keywords and clicks it."""
        for kw in COOKIE_CONSENT_KEYWORDS:
            selector = f"button, a, div[role='button']"
            js = f"""
            (() => {{
                const targetText = {json.dumps(kw.lower())};
                const elements = Array.from(document.querySelectorAll("{selector}"));
                for (const el of elements) {{
                    const txt = (el.innerText || el.textContent || "").trim().toLowerCase();
                    if (txt === targetText || (txt.includes(targetText) && txt.length < 35)) {{
                        const r = el.getBoundingClientRect();
                        if (r.width > 10 && r.height > 10 && r.top >= 0) {{
                            el.scrollIntoView({{ behavior: 'instant', block: 'center' }});
                            const nr = el.getBoundingClientRect();
                            return {{ x: nr.x, y: nr.y, width: nr.width, height: nr.height }};
                        }}
                    }}
                }}
                return null;
            }})()
            """
            rect_val = self.cdp.evaluate(js)
            if rect_val:
                self.log(f"CookieBot: Found consent button matching '{kw}', clicking naturally...")
                from sammonny.core.models import Rect
                r = Rect(rect_val["x"], rect_val["y"], rect_val["width"], rect_val["height"])
                click_pt = r.sample_human_point()
                self.mouse.click(click_pt.x, click_pt.y)
                time.sleep(1.0)
                return True
        return False

    def _simulate_reading_scroll(self) -> None:
        """Simulates human reading by scrolling down in small chunks with pauses."""
        num_scrolls = random.randint(2, 4)
        for _ in range(num_scrolls):
            delta = random.randint(150, 450)
            self.cdp.dispatch_mouse("mouseWheel", x=500, y=400, delta_x=0, delta_y=delta)
            time.sleep(random.uniform(0.6, 1.4))

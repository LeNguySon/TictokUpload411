"""
Live CDP Cookie Extractor & Manager.
Fetches and injects cookies directly into an active browser session via WebSocket CDP.
"""

from __future__ import annotations
from typing import List, Dict, Any, Optional
from sammonny.core.cdp import SyncCdpClient
from sammonny.core.models import CookieItem


class CdpCookieClient:
    """Extracts and manages cookies on a live running browser instance."""

    def __init__(self, cdp_client: SyncCdpClient):
        self.cdp = cdp_client

    def get_all_cookies(self) -> List[CookieItem]:
        """Harvests all session and persistent cookies from the live browser."""
        return self.cdp.get_cookies()

    def set_cookie(self, cookie: CookieItem) -> None:
        """Injects a cookie into the live browser session."""
        self.cdp.set_cookie(cookie)

    def import_cookies(self, cookies: List[CookieItem]) -> int:
        count = 0
        for c in cookies:
            try:
                self.set_cookie(c)
                count += 1
            except Exception:
                pass
        return count

    def clear_browser_cookies(self) -> None:
        """Wipes all cookies in the active browser context."""
        self.cdp.send("Network.clearBrowserCookies", {})

"""
Proxy Health Checker, Latency Diagnostic & IP Rotation Service.
Measures TCP connect latency, tests proxy tunneling egress IP, and triggers mobile IP change.
"""

from __future__ import annotations
import socket
import time
import json
import urllib.request
import urllib.error
from typing import Optional, Dict, Any

from sammonny.core.models import ProxyItem, ProxyHealthResult


def measure_tcp_ping(host: str, port: int, timeout_sec: float = 3.0) -> Optional[float]:
    """Measures raw TCP handshake latency in milliseconds."""
    start = time.perf_counter()
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout_sec)
        sock.connect((host, port))
        sock.close()
        return round((time.perf_counter() - start) * 1000.0, 2)
    except Exception:
        return None


def check_proxy_health(
    proxy: ProxyItem,
    test_url: str = "http://ip-api.com/json/?fields=status,message,country,countryCode,city,query,timezone",
    timeout_sec: float = 8.0,
) -> ProxyHealthResult:
    """
    Validates proxy connectivity and resolves its public egress IP & geolocation.
    """
    # 1. Quick TCP socket test
    tcp_ping = measure_tcp_ping(proxy.host, proxy.port, timeout_sec=min(timeout_sec, 3.0))
    if tcp_ping is None:
        return ProxyHealthResult(
            is_alive=False,
            latency_ms=9999.0,
            error=f"TCP connection to {proxy.host}:{proxy.port} timed out or was refused.",
        )

    # 2. HTTP Egress & GeoIP Check
    proxy_url = proxy.to_url()
    proxies = {"http": proxy_url, "https": proxy_url}
    proxy_handler = urllib.request.ProxyHandler(proxies)
    opener = urllib.request.build_opener(proxy_handler)

    req = urllib.request.Request(
        test_url,
        headers={"User-Agent": "SamMonny-Proxy-Checker/1.0", "Accept": "application/json"},
    )

    start = time.perf_counter()
    try:
        with opener.open(req, timeout=timeout_sec) as resp:
            elapsed_ms = round((time.perf_counter() - start) * 1000.0, 2)
            body = resp.read().decode("utf-8")
            data = json.loads(body)

            egress_ip = data.get("query")
            country = data.get("countryCode") or data.get("country")
            city = data.get("city")
            tz = data.get("timezone")

            # Update proxy item in place
            proxy.is_alive = True
            proxy.latency_ms = elapsed_ms
            proxy.country = country
            proxy.last_checked = time.time()

            return ProxyHealthResult(
                is_alive=True,
                latency_ms=elapsed_ms,
                egress_ip=egress_ip,
                country=country,
                city=city,
                timezone=tz,
            )
    except Exception as e:
        proxy.is_alive = False
        proxy.latency_ms = 9999.0
        proxy.last_checked = time.time()
        return ProxyHealthResult(
            is_alive=False,
            latency_ms=9999.0,
            error=f"Proxy tunnel test failed: {e}",
        )


def trigger_ip_rotation(proxy: ProxyItem, timeout_sec: float = 10.0) -> Dict[str, Any]:
    """
    Triggers rotating proxy endpoint (e.g. mobile 4G/5G proxy change IP URL).
    """
    if not proxy.change_ip_url:
        return {"success": False, "message": "No change_ip_url configured for this proxy."}

    req = urllib.request.Request(
        proxy.change_ip_url,
        headers={"User-Agent": "SamMonny-IP-Rotator/1.0"},
    )
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            elapsed = round((time.perf_counter() - start) * 1000.0, 2)
            return {
                "success": True,
                "elapsed_ms": elapsed,
                "response": body[:200],
            }
    except Exception as e:
        return {"success": False, "error": str(e)}

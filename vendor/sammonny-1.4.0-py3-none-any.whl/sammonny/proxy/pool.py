"""
Enterprise Proxy Pool & Lifecycle Rotation Manager.
Supports Round-Robin, Random, Least-Used, and Sticky Session strategies,
with health tracking, automatic failure rotation, and persistent caching.
"""

from __future__ import annotations
import json
import os
import random
import time
import tempfile
import threading
from pathlib import Path
from typing import List, Dict, Optional, Union
from concurrent.futures import ThreadPoolExecutor, as_completed

from sammonny.core.models import ProxyItem, ProxyHealthResult
from sammonny.proxy.parser import parse_proxy, bulk_parse_proxies
from sammonny.proxy.checker import check_proxy_health, trigger_ip_rotation


class ProxyPool:
    """Manages a collection of proxies with rotation strategies and health metrics."""

    def __init__(self, storage_path: Optional[Union[str, Path]] = None):
        self._lock = threading.RLock()
        self.storage_path = Path(storage_path) if storage_path else None
        self._proxies: Dict[str, ProxyItem] = {}
        self._usage_counts: Dict[str, int] = {}
        self._failure_counts: Dict[str, int] = {}
        self._profile_assignments: Dict[str, str] = {}  # profile_id -> proxy_id
        self._round_robin_idx: int = 0

        if self.storage_path and self.storage_path.exists():
            self.load()

    def add(self, proxy: Union[ProxyItem, str], save: bool = True) -> ProxyItem:
        if isinstance(proxy, str):
            p = parse_proxy(proxy)
        else:
            p = proxy

        with self._lock:
            self._proxies[p.id] = p
            self._usage_counts.setdefault(p.id, 0)
            self._failure_counts.setdefault(p.id, 0)

            if save and self.storage_path:
                self.save()
            return p

    def add_bulk(self, proxies_text_or_list: Union[str, List[str]], save: bool = True) -> int:
        parsed_list = bulk_parse_proxies(proxies_text_or_list)
        count = 0
        with self._lock:
            for p in parsed_list:
                self.add(p, save=False)
                count += 1
            if save and self.storage_path:
                self.save()
            return count

    def remove(self, proxy_id: str) -> bool:
        with self._lock:
            if proxy_id in self._proxies:
                del self._proxies[proxy_id]
                self._usage_counts.pop(proxy_id, None)
                self._failure_counts.pop(proxy_id, None)
                # Remove any profile bindings to this proxy
                for prof_id, bound_proxy in list(self._profile_assignments.items()):
                    if bound_proxy == proxy_id:
                        del self._profile_assignments[prof_id]
                if self.storage_path:
                    self.save()
                return True
            return False

    def get_all(self, alive_only: bool = False) -> List[ProxyItem]:
        with self._lock:
            if alive_only:
                return [p for p in self._proxies.values() if p.is_alive]
            return list(self._proxies.values())

    def get(self, proxy_id: str) -> Optional[ProxyItem]:
        with self._lock:
            return self._proxies.get(proxy_id)

    def size(self) -> int:
        with self._lock:
            return len(self._proxies)

    # =========================================================================
    # Rotation & Allocation Strategies
    # =========================================================================

    def next_round_robin(self, alive_only: bool = True) -> Optional[ProxyItem]:
        with self._lock:
            candidates = [p for p in self._proxies.values() if (not alive_only or p.is_alive)]
            if not candidates and alive_only:
                candidates = list(self._proxies.values())
            if not candidates:
                return None
            self._round_robin_idx = (self._round_robin_idx + 1) % len(candidates)
            chosen = candidates[self._round_robin_idx]
            self._usage_counts[chosen.id] = self._usage_counts.get(chosen.id, 0) + 1
            return chosen

    def next_random(self, alive_only: bool = True) -> Optional[ProxyItem]:
        with self._lock:
            candidates = [p for p in self._proxies.values() if (not alive_only or p.is_alive)]
            if not candidates and alive_only:
                candidates = list(self._proxies.values())
            if not candidates:
                return None
            chosen = random.choice(candidates)
            self._usage_counts[chosen.id] = self._usage_counts.get(chosen.id, 0) + 1
            return chosen

    def next_least_used(self, alive_only: bool = True) -> Optional[ProxyItem]:
        with self._lock:
            candidates = [p for p in self._proxies.values() if (not alive_only or p.is_alive)]
            if not candidates and alive_only:
                candidates = list(self._proxies.values())
            if not candidates:
                return None
            candidates.sort(key=lambda p: self._usage_counts.get(p.id, 0))
            chosen = candidates[0]
            self._usage_counts[chosen.id] = self._usage_counts.get(chosen.id, 0) + 1
            return chosen

    def sticky(self, profile_id: str, strategy: str = "least_used") -> Optional[ProxyItem]:
        """
        Returns the proxy permanently bound to profile_id.
        If none bound or currently bound proxy is dead, allocates a fresh alive proxy.
        """
        with self._lock:
            bound_id = self._profile_assignments.get(profile_id)
            if bound_id and bound_id in self._proxies:
                bound_proxy = self._proxies[bound_id]
                if bound_proxy.is_alive:
                    self._usage_counts[bound_id] = self._usage_counts.get(bound_id, 0) + 1
                    return bound_proxy

            # Need to allocate a new proxy
            new_proxy = self.next_least_used() if strategy == "least_used" else self.next_round_robin()
            if not new_proxy and self._proxies:
                new_proxy = self.next_least_used(alive_only=False)
            if new_proxy:
                self._profile_assignments[profile_id] = new_proxy.id
                if self.storage_path:
                    self.save()
            return new_proxy

    def rotate(self, profile_id: str) -> Optional[ProxyItem]:
        """
        Rotates the proxy assigned to a profile:
        1. If proxy has change_ip_url, triggers IP renewal API.
        2. Otherwise, switches to a different alive proxy from the pool.
        """
        with self._lock:
            bound_id = self._profile_assignments.get(profile_id)
            if bound_id and bound_id in self._proxies:
                current = self._proxies[bound_id]
                if current.change_ip_url:
                    res = trigger_ip_rotation(current)
                    if res.get("success"):
                        return current

            # Switch to next proxy
            candidates = [p for p in self._proxies.values() if p.is_alive and p.id != bound_id]
            if not candidates:
                candidates = [p for p in self._proxies.values() if p.is_alive]
            if not candidates:
                return None

            chosen = random.choice(candidates)
            self._profile_assignments[profile_id] = chosen.id
            self._usage_counts[chosen.id] = self._usage_counts.get(chosen.id, 0) + 1
            if self.storage_path:
                self.save()
            return chosen

    def mark_failure(self, proxy_id: str, max_failures: int = 3) -> None:
        """Marks a connection failure. Deactivates proxy if failures exceed threshold."""
        with self._lock:
            fails = self._failure_counts.get(proxy_id, 0) + 1
            self._failure_counts[proxy_id] = fails
            if fails >= max_failures and proxy_id in self._proxies:
                self._proxies[proxy_id].is_alive = False
                if self.storage_path:
                    self.save()

    def report_failure(self, proxy_id: str, max_failures: int = 3) -> None:
        """Alias for mark_failure."""
        self.mark_failure(proxy_id, max_failures=max_failures)

    def test_all(self, max_workers: int = 8, timeout_sec: float = 6.0) -> Dict[str, ProxyHealthResult]:
        """Runs concurrent health tests across all proxies in pool."""
        results: Dict[str, ProxyHealthResult] = {}
        with self._lock:
            items_to_test = list(self._proxies.values())

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_id = {
                executor.submit(check_proxy_health, p, timeout_sec=timeout_sec): p.id
                for p in items_to_test
            }
            for fut in as_completed(future_to_id):
                pid = future_to_id[fut]
                try:
                    res = fut.result()
                    results[pid] = res
                    if not res.is_alive:
                        self.mark_failure(pid, max_failures=1)
                except Exception as e:
                    results[pid] = ProxyHealthResult(is_alive=False, latency_ms=9999.0, error=str(e))
                    self.mark_failure(pid, max_failures=1)

        if self.storage_path:
            self.save()
        return results

    # =========================================================================
    # Persistence
    # =========================================================================

    def save(self) -> None:
        if not self.storage_path:
            return
        with self._lock:
            self.storage_path.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "proxies": [p.to_dict() for p in self._proxies.values()],
                "assignments": self._profile_assignments,
                "usage_counts": self._usage_counts,
            }
            # Atomic file replacement
            tmp_file = self.storage_path.with_suffix(".tmp")
            with open(tmp_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp_file, self.storage_path)

    def load(self) -> None:
        if not self.storage_path or not self.storage_path.exists():
            return
        with self._lock:
            try:
                with open(self.storage_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self._proxies = {
                    p["id"]: ProxyItem.from_dict(p) for p in data.get("proxies", [])
                }
                self._profile_assignments = data.get("assignments", {})
                self._usage_counts = data.get("usage_counts", {})
            except Exception:
                pass
            pass

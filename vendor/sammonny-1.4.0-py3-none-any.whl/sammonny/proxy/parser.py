"""
Proxy String Parser for SamMonny Antidetect Python SDK.
Parses any standard or non-standard proxy notation:
- protocol://user:pass@host:port
- protocol://host:port:user:pass
- host:port:user:pass
- host:port
- user:pass@host:port
"""

from __future__ import annotations
import re
import uuid
from typing import List, Optional, Union
from urllib.parse import urlparse

from sammonny.core.models import ProxyItem
from sammonny.core.exceptions import SamMonnyError


class ProxyParseError(SamMonnyError):
    pass


def parse_proxy(raw: str, default_mode: str = "http", name: Optional[str] = None) -> ProxyItem:
    """
    Parses a single proxy string into a structured ProxyItem.
    """
    s = raw.strip()
    if not s:
        raise ProxyParseError("Empty proxy string")

    change_ip_url = None
    # Check if change_ip_url is delimited by '|' or ';' (common in proxy providers)
    if "|" in s:
        parts = s.split("|", 1)
        s = parts[0].strip()
        change_ip_url = parts[1].strip()
    elif ";" in s and "://" in s.split(";", 1)[1]:
        parts = s.split(";", 1)
        s = parts[0].strip()
        change_ip_url = parts[1].strip()

    mode = default_mode
    username = None
    password = None

    # Case 1: Standard URL notation with protocol (e.g. socks5://user:pass@host:port)
    if "://" in s:
        parsed = urlparse(s)
        mode = parsed.scheme.lower() or default_mode
        host = parsed.hostname or ""
        port = parsed.port or (1080 if "socks" in mode else 8080)
        username = parsed.username
        password = parsed.password
    else:
        # Notation without scheme: could be host:port:user:pass or host:port or user:pass@host:port
        if "@" in s:
            user_part, host_part = s.split("@", 1)
            if ":" in user_part:
                username, password = user_part.split(":", 1)
            else:
                username = user_part
            if ":" in host_part:
                host, port_str = host_part.split(":", 1)
                port = int(port_str)
            else:
                host = host_part
                port = 8080
        else:
            tokens = s.split(":")
            if len(tokens) == 2:
                # host:port
                host = tokens[0]
                port = int(tokens[1])
            elif len(tokens) == 4:
                # host:port:user:pass
                host = tokens[0]
                port = int(tokens[1])
                username = tokens[2]
                password = tokens[3]
            else:
                raise ProxyParseError(f"Unrecognized proxy format: '{raw}'")

    if not host or not port:
        raise ProxyParseError(f"Invalid host or port parsed from: '{raw}'")

    proxy_id = str(uuid.uuid4())[:12]
    return ProxyItem(
        id=proxy_id,
        mode=mode,
        host=host,
        port=port,
        username=username,
        password=password,
        change_ip_url=change_ip_url,
        name=name or f"{host}:{port}",
    )


def bulk_parse_proxies(text_or_lines: Union[str, List[str]], default_mode: str = "http") -> List[ProxyItem]:
    """
    Parses a multiline string or list of proxy strings, ignoring empty lines and comments (#).
    """
    if isinstance(text_or_lines, str):
        lines = text_or_lines.splitlines()
    else:
        lines = text_or_lines

    results: List[ProxyItem] = []
    for line in lines:
        cleaned = line.strip()
        if not cleaned or cleaned.startswith("#") or cleaned.startswith("//"):
            continue
        try:
            p = parse_proxy(cleaned, default_mode=default_mode)
            results.append(p)
        except Exception:
            continue

    return results

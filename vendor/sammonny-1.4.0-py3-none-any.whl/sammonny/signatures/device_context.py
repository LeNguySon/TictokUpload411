"""
sammonny.signatures.device_context
==================================
Deterministic, high-trust hardware and device context generator.
Maps profile identity and hardware settings into persistent device tokens:
- device_id, install_id, webid, openudid (19-digit numerical and hex schemas).
- msToken (high-entropy Base64 telemetry token).
- verify_fp (risk control fingerprint token).
- IDC Geo-Affinity resolver (prevents Cross-Region Risk flags).
"""

from __future__ import annotations

import base64
from dataclasses import dataclass, field
import hashlib
from pathlib import Path
import time
from typing import Any, Dict, Optional, Tuple


def resolve_idc_endpoint(region: str | None = None) -> Tuple[str, str]:
    """
    Maps geographical region to the optimal ByteDance IDC cluster and endpoint.
    Guarantees IDC Geo-Affinity to prevent Cross-Region Risk flags.
    Supports over 50 regional country codes across APAC, Americas, and Europe.
    """
    reg = (region or "US").upper()

    # Americas -> useast2a cluster
    if reg in {"US", "CA", "MX", "BR", "AR", "CL", "CO", "PE"}:
        return "https://web-va.tiktok.com", "useast2a"

    # Europe & Middle East -> eucentral / maliva16 cluster
    if reg in {
        "GB", "DE", "FR", "ES", "IT", "NL", "SE", "NO", "PL",
        "FI", "DK", "CH", "AT", "BE", "CZ", "RO", "UA", "TR",
        "AE", "SA", "IL", "ZA", "EG", "GR", "PT", "HU", "IE",
    }:
        return "https://web-va.tiktok.com", "eucentral"

    # APAC & Rest of the world -> alisg (Singapore) cluster
    return "https://web-sg.tiktok.com", "alisg"


@dataclass
class ProfileDeviceContext:
    """Immutable, deterministic hardware and identity tokens for a browser profile."""
    profile_id: str
    device_id: str
    install_id: str
    webid: str
    openudid: str
    verify_fp: str
    ms_token: str
    region: str
    idc: str
    base_endpoint: str
    telemetry: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "device_id": self.device_id,
            "install_id": self.install_id,
            "webid": self.webid,
            "openudid": self.openudid,
            "verify_fp": self.verify_fp,
            "msToken": self.ms_token,
            "region": self.region,
            "idc": self.idc,
            "base_endpoint": self.base_endpoint,
            "telemetry": self.telemetry,
        }

    def get_query_params(self, aid: int = 1988) -> str:
        """Standard ByteDance web query parameter block."""
        return (
            f"aid={aid}&region={self.region}&device_id={self.device_id}&"
            f"install_id={self.install_id}&os=windows&app_name=tiktok_web"
        )


def get_profile_device_context(
    profile_id: int | str,
    region: str = "US",
    telemetry: Optional[Dict[str, Any]] = None,
    db_path: Path | str | None = None,
) -> ProfileDeviceContext:
    """
    Generates deterministic, consistent hardware and device tokens for a given profile.
    Maintains persistent device_id, install_id, and telemetry entropy so server risk
    engines recognize familiar, genuine hardware across restarts.
    """
    pid_str = str(profile_id)
    # Generate deterministic integer seed from profile_id
    seed_hash = hashlib.sha256(pid_str.encode("utf-8")).hexdigest()
    seed_int = int(seed_hash[:8], 16)

    # Derive deterministic tokens
    dev_hash = hashlib.sha256(f"sammonny-profile-device-{seed_int}".encode()).hexdigest()

    device_id = str(int(dev_hash[:16], 16))[:19]
    install_id = str(int(dev_hash[16:32], 16))[:19]
    webid = str(int(dev_hash[32:48], 16))[:19]
    openudid = dev_hash[48:64]

    # Deterministic msToken (128 characters Base64) with hourly rotation
    ms_seed = hashlib.sha256(f"mstoken-{pid_str}-{int(time.time() // 3600)}".encode()).digest()
    ms_token = base64.b64encode(ms_seed * 4).decode("ascii")[:128].rstrip("=")

    # Deterministic verify_fp
    fp_hash = hashlib.md5(f"verify_fp_{pid_str}".encode()).hexdigest()
    verify_fp = f"verify_{fp_hash}"

    base_endpoint, idc = resolve_idc_endpoint(region)

    telem = dict(telemetry or {})
    telem.setdefault("screen_width", 1920)
    telem.setdefault("screen_height", 1080)
    telem.setdefault("cpu_cores", 8)
    telem.setdefault("memory_gb", 8)
    telem.setdefault("canvas_noise", 42)
    telem.setdefault("webgl_vendor", "Google Inc. (NVIDIA)")
    telem.setdefault("webgl_renderer", "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)")
    telem.setdefault("platform", "Win32")

    return ProfileDeviceContext(
        profile_id=pid_str,
        device_id=device_id,
        install_id=install_id,
        webid=webid,
        openudid=openudid,
        verify_fp=verify_fp,
        ms_token=ms_token,
        region=region.upper(),
        idc=idc,
        base_endpoint=base_endpoint,
        telemetry=telem,
    )


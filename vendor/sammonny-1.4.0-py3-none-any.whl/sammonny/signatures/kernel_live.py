"""
sammonny.signatures.kernel_live
===============================
CDP Live Context Signature Engine for Orbita Browser Kernel.
Leverages the running Chromium V8 JavaScript runtime in active browser tabs to:
1. Extract authentic ByteDance signatures directly via `window.byted_acrawler.sign()`.
2. Retrieve runtime cookie tokens (`msToken`, `passport_csrf_token`, `ttwid`).
3. Execute subtle biometric warmup (window focus, micro mouse jitter) to populate SecSDK buffers.
4. Execute in-browser `window.fetch()`, which triggers ByteDance internal network hooks
   to sign and dispatch requests with zero algorithmic drift.
"""

from __future__ import annotations

import logging
import random
import time
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

from sammonny.core.cdp import SyncCdpClient

logger = logging.getLogger("sammonny.signatures.kernel_live")


class CDPLiveSigner:
    """Live signature generator querying the active Orbita Chromium runtime via CDP."""

    def __init__(self, cdp_client: SyncCdpClient) -> None:
        self.cdp = cdp_client

    def warmup_biometrics(self) -> None:
        """
        Executes a subtle, natural biometric warm-up in the page context before API operations:
        1. Ensures document has active window/tab focus.
        2. Dispatches micro mouse movements so that ByteDance SecSDK / acrawler records
           legitimate interaction telemetry in its internal buffer.
        """
        try:
            self.cdp.evaluate("""(() => {
                try {
                    if (document.body && !document.hasFocus()) {
                        window.focus();
                    }
                } catch (e) {}
            })()""")
        except Exception:
            pass

        try:
            start_x = random.randint(280, 520)
            start_y = random.randint(200, 450)
            self.cdp.send("Input.dispatchMouseEvent", {
                "type": "mouseMoved",
                "x": start_x,
                "y": start_y,
            })
            self.cdp.send("Input.dispatchMouseEvent", {
                "type": "mouseMoved",
                "x": start_x + random.randint(-15, 20),
                "y": start_y + random.randint(-10, 15),
            })
        except Exception:
            pass

    def extract_kernel_hardware_fingerprint(self) -> Dict[str, Any]:
        """
        Queries the active V8 runtime to inspect the actual hardware parameters
        exposed to web scripts by the Orbita C++ engine.
        """
        js_code = """
        (() => {
            let canvasNoise = null;
            try {
                const c = document.createElement('canvas');
                c.width = 16;
                c.height = 16;
                const ctx = c.getContext('2d');
                ctx.fillText('SamMonny', 2, 2);
                canvasNoise = c.toDataURL().slice(-16);
            } catch (e) {}

            let webglVendor = "";
            let webglRenderer = "";
            try {
                const glCanvas = document.createElement('canvas');
                const gl = glCanvas.getContext('webgl') || glCanvas.getContext('experimental-webgl');
                if (gl) {
                    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
                    if (dbg) {
                        webglVendor = gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL);
                        webglRenderer = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL);
                    }
                }
            } catch (e) {}

            return {
                screen_width: window.screen.width,
                screen_height: window.screen.height,
                cpu_cores: navigator.hardwareConcurrency || 8,
                memory_gb: navigator.deviceMemory || 8,
                platform: navigator.platform,
                user_agent: navigator.userAgent,
                webdriver: navigator.webdriver,
                canvas_sample: canvasNoise,
                webgl_vendor: webglVendor,
                webgl_renderer: webglRenderer
            };
        })()
        """
        try:
            res = self.cdp.evaluate(js_code)
            if isinstance(res, dict):
                return res
        except Exception as exc:
            logger.debug("Failed to extract kernel hardware fingerprint: %s", exc)
        return {}

    def sign_url_live(self, raw_url: str) -> Dict[str, Any]:
        """
        Executes in-page JavaScript evaluation in the active tab context (V8).
        Leverages native `window.byted_acrawler.sign()` and cookies to sign target URL.
        """
        js_script = f"""
        (() => {{
            const targetUrl = {repr(raw_url)};
            let signature = null;
            let msToken = null;
            let csrfToken = null;
            let ttwid = null;
            let aBogus = null;

            try {{
                // 1. Extract msToken from cookie
                const mMatch = document.cookie.match(/(?:^|;\\s*)msToken=([^;]+)/);
                if (mMatch) msToken = decodeURIComponent(mMatch[1]);
            }} catch (e) {{}}

            try {{
                // 2. Extract passport_csrf_token from cookie
                const cMatch = document.cookie.match(/(?:^|;\\s*)passport_csrf_token=([^;]+)/);
                if (cMatch) csrfToken = decodeURIComponent(cMatch[1]);
            }} catch (e) {{}}

            try {{
                // Extract ttwid from cookie
                const tMatch = document.cookie.match(/(?:^|;\\s*)ttwid=([^;]+)/);
                if (tMatch) ttwid = decodeURIComponent(tMatch[1]);
            }} catch (e) {{}}

            // 3. Invoke byted_acrawler live signing if available
            try {{
                if (window.byted_acrawler && typeof window.byted_acrawler.sign === "function") {{
                    const sRes = window.byted_acrawler.sign({{ url: targetUrl }});
                    if (typeof sRes === "object" && sRes !== null) {{
                        signature = sRes.signature || sRes._signature || sRes.xbogus || sRes.abogus || JSON.stringify(sRes);
                        if (sRes.a_bogus) aBogus = sRes.a_bogus;
                    }} else {{
                        signature = sRes;
                    }}
                }} else if (window._sign && typeof window._sign === "function") {{
                    signature = window._sign(targetUrl);
                }}
            }} catch (e) {{
                signature = null;
            }}

            // 4. Append msToken, _signature, and a_bogus to URL
            let fullUrl = targetUrl;
            if (msToken && !fullUrl.includes("msToken=")) {{
                const sep = fullUrl.includes("?") ? "&" : "?";
                fullUrl = `${{fullUrl}}${{sep}}msToken=${{encodeURIComponent(msToken)}}`;
            }}
            if (signature && !fullUrl.includes("_signature=")) {{
                const sep = fullUrl.includes("?") ? "&" : "?";
                fullUrl = `${{fullUrl}}${{sep}}_signature=${{encodeURIComponent(signature)}}`;
            }}
            if (aBogus && !fullUrl.includes("a_bogus=")) {{
                const sep = fullUrl.includes("?") ? "&" : "?";
                fullUrl = `${{fullUrl}}${{sep}}a_bogus=${{encodeURIComponent(aBogus)}}`;
            }}

            const hdrs = {{
                "x-secsdk-csrf-token": csrfToken || "",
                "x-tt-token": csrfToken || ""
            }};
            if (ttwid) hdrs["ttwid"] = ttwid;

            return {{
                url: fullUrl,
                signature: signature,
                msToken: msToken,
                csrfToken: csrfToken,
                ttwid: ttwid,
                aBogus: aBogus,
                headers: hdrs
            }};
        }})()
        """
        try:
            res = self.cdp.evaluate(js_script)
            if isinstance(res, dict) and "url" in res:
                return {
                    "status": "ok",
                    "url": res.get("url", raw_url),
                    "headers": res.get("headers", {}),
                    "signature": res.get("signature"),
                    "msToken": res.get("msToken"),
                    "aBogus": res.get("aBogus"),
                    "engine": "cdp_kernel_live",
                }
        except Exception as exc:
            logger.debug("sign_url_live evaluation exception: %s", exc)

        return {
            "status": "fallback",
            "url": raw_url,
            "signature": None,
            "msToken": None,
            "csrfToken": None,
            "headers": {},
            "engine": "cdp_kernel_live",
        }

    def execute_in_browser_fetch(
        self,
        endpoint: str,
        method: str = "POST",
        json_data: Optional[Dict[str, Any]] = None,
        custom_headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Executes in-browser fetch inside the page context (V8 runtime of Orbita).
        Automatically triggers ByteDance's internal monkey-patched fetch hooks,
        ensuring 100% genuine signatures (_signature, msToken, X-Bogus, cookies).
        """
        self.warmup_biometrics()

        import json
        payload_json = json.dumps(json_data) if json_data else "null"
        headers_json = json.dumps(custom_headers or {})

        js_code = f"""
        (async () => {{
            const endpoint = {repr(endpoint)};
            const method = {repr(method)};
            const data = {payload_json};
            const customHeaders = {headers_json};

            let csrfToken = "";
            try {{
                const match = document.cookie.match(/(?:^|;\\s*)(?:passport_csrf_token|tt_csrf_token)=([^;]+)/);
                if (match) csrfToken = decodeURIComponent(match[1]);
            }} catch (e) {{}}

            const headers = {{
                "content-type": "application/json",
                "accept": "application/json, text/plain, */*",
                ...(csrfToken ? {{ "x-secsdk-csrf-token": csrfToken, "x-tt-token": csrfToken }} : {{}}),
                ...(customHeaders || {{}})
            }};

            try {{
                const res = await window.fetch(endpoint, {{
                    method: method || "POST",
                    headers: headers,
                    body: data ? JSON.stringify(data) : undefined,
                    credentials: "include",
                    mode: "cors"
                }});
                let body = null;
                try {{
                    body = await res.json();
                }} catch (e) {{
                    body = {{ raw: await res.text().catch(() => "") }};
                }}
                return {{
                    status: res.status,
                    ok: res.ok,
                    body: body,
                    status_code: (body && typeof body.status_code !== 'undefined') ? body.status_code : (res.ok ? 0 : -1)
                }};
            }} catch (err) {{
                return {{
                    status: 0,
                    ok: false,
                    error: err.toString(),
                    status_code: -1
                }};
            }}
        }})()
        """
        try:
            res = self.cdp.evaluate(js_code)
            if isinstance(res, dict):
                return res
        except Exception as exc:
            logger.error("execute_in_browser_fetch failed: %s", exc)

        return {
            "status": 0,
            "ok": False,
            "error": "CDP evaluation unavailable",
            "status_code": -1,
        }

"""
SamMonny Antidetect Python CLI Suite.
Full command-line interface for Profiles, Cookies, Vision Locator, DOM Mouse, and Daemon diagnostics.
"""

from __future__ import annotations
import sys
import json
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from sammonny.core.client import SamMonnyDaemonClient
from sammonny.core.cdp import SyncCdpClient
from sammonny.core.models import CookieItem, Rect, Point
from sammonny.cookies.sqlite_manager import CookieSqliteManager
from sammonny.vision.locator import ImageLocator
from sammonny.dom.controller import DOMController
from sammonny.dom.mouse import HumanMouse

console = Console()


@click.group()
@click.version_option(version="1.0.0", prog_name="SamMonny CLI")
@click.pass_context
def cli(ctx):
    """SamMonny Antidetect Browser - Automation & Stealth SDK CLI."""
    ctx.ensure_object(dict)
    ctx.obj["client"] = SamMonnyDaemonClient()


# =============================================================================
# DAEMON COMMANDS
# =============================================================================

@cli.group()
def daemon():
    """Diagnose and monitor local daemon servers."""
    pass


@daemon.command(name="status")
@click.pass_context
def daemon_status(ctx):
    """Check connectivity to local ports 7654 and 36912."""
    client: SamMonnyDaemonClient = ctx.obj["client"]
    status = client.check_health()

    table = Table(title="SamMonny Daemon Status")
    table.add_column("Service", style="cyan")
    table.add_column("Port", style="magenta")
    table.add_column("Status", style="bold")

    status_7654 = "[green]ONLINE[/green]" if status["daemon_7654"] else "[red]OFFLINE[/red]"
    status_36912 = "[green]ONLINE[/green]" if status["sdk_36912"] else "[red]OFFLINE[/red]"

    table.add_row("Astro Daemon API", "7654", status_7654)
    table.add_row("Official GoLogin SDK API", "36912", status_36912)

    console.print(table)


# =============================================================================
# PROFILE COMMANDS
# =============================================================================

@cli.group()
def profile():
    """Manage browser profiles (create, list, start, stop, delete)."""
    pass


@profile.command(name="list")
@click.pass_context
def profile_list(ctx):
    """List all profiles in local storage."""
    client: SamMonnyDaemonClient = ctx.obj["client"]
    try:
        profiles = client.list_profiles()
    except Exception as e:
        console.print(f"[red]Error fetching profiles:[/red] {e}")
        return

    table = Table(title=f"Local Profiles ({len(profiles)})")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="bold white")
    table.add_column("OS", style="green")
    table.add_column("Status", style="yellow")
    table.add_column("Proxy", style="blue")

    for p in profiles:
        table.add_row(p.id, p.name, p.os, p.status, p.proxy or "Direct")

    console.print(table)


@profile.command(name="create")
@click.option("--name", "-n", required=True, help="Profile name")
@click.option("--os", "os_name", default="win", help="Target OS (win, mac, lin)")
@click.option("--proxy", "-p", default=None, help="Proxy URL (socks5://host:port)")
@click.pass_context
def profile_create(ctx, name: str, os_name: str, proxy: Optional[str]):
    """Create a new profile with offline Bayesian fingerprint."""
    client: SamMonnyDaemonClient = ctx.obj["client"]
    try:
        p = client.create_profile(name=name, os_name=os_name, proxy=proxy)
        console.print(f"[green]Profile created successfully![/green] ID: [cyan]{p.id}[/cyan]")
    except Exception as e:
        console.print(f"[red]Failed to create profile:[/red] {e}")


@profile.command(name="start")
@click.option("--id", "profile_id", required=True, help="Profile ID to launch")
@click.option("--headless", is_flag=True, help="Run browser in headless mode")
@click.pass_context
def profile_start(ctx, profile_id: str, headless: bool):
    """Launch a profile and display the CDP WebSocket debugger URL."""
    client: SamMonnyDaemonClient = ctx.obj["client"]
    try:
        ws_url = client.start_profile(profile_id, headless=headless)
        console.print(Panel(f"[bold green]Browser Launched Successfully![/bold green]\nWebSocket URL: [cyan]{ws_url}[/cyan]", title="Profile Active"))
    except Exception as e:
        console.print(f"[red]Failed to start profile:[/red] {e}")


@profile.command(name="stop")
@click.option("--id", "profile_id", required=True, help="Profile ID to stop")
@click.pass_context
def profile_stop(ctx, profile_id: str):
    """Stop an active browser profile."""
    client: SamMonnyDaemonClient = ctx.obj["client"]
    try:
        ok = client.stop_profile(profile_id)
        if ok:
            console.print(f"[green]Profile [cyan]{profile_id}[/cyan] stopped successfully.[/green]")
        else:
            console.print(f"[yellow]Profile [cyan]{profile_id}[/cyan] was already stopped or not found.[/yellow]")
    except Exception as e:
        console.print(f"[red]Failed to stop profile:[/red] {e}")


@profile.command(name="clone")
@click.option("--id", "source_id", required=True, help="Source Profile ID to clone")
@click.option("--name", default=None, help="New profile name")
@click.pass_context
def profile_clone(ctx, source_id: str, name: Optional[str]):
    """Clone an existing profile with a fresh mutated fingerprint."""
    from sammonny.engine.core import AntidetectEngine
    engine = AntidetectEngine()
    try:
        new_prof = engine.clone_profile(source_id, new_name=name)
        console.print(f"[green]Profile cloned successfully![/green] New ID: [cyan]{new_prof.id}[/cyan] (Name: {new_prof.name})")
    except Exception as e:
        console.print(f"[red]Failed to clone profile:[/red] {e}")


# =============================================================================
# PROXY COMMANDS
# =============================================================================

@cli.group()
def proxy():
    """Manage proxy pool, health diagnostics, and IP rotation."""
    pass


@proxy.command(name="list")
@click.option("--storage", default="proxies.json", help="Path to proxy storage JSON")
def proxy_list(storage: str):
    """List all proxies in the pool with health and latency."""
    from sammonny.proxy.pool import ProxyPool
    pool = ProxyPool(storage)
    proxies = pool.get_all()

    table = Table(title=f"Proxy Pool ({len(proxies)} proxies)")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Type", style="magenta")
    table.add_column("Endpoint", style="bold white")
    table.add_column("Country", style="green")
    table.add_column("Ping (ms)", style="yellow")
    table.add_column("Status", style="bold")

    for p in proxies:
        status_str = "[green]ALIVE[/green]" if p.is_alive else "[red]DEAD[/red]"
        lat_str = f"{p.latency_ms:.0f}" if p.latency_ms is not None else "--"
        table.add_row(
            p.id,
            p.mode.upper(),
            f"{p.host}:{p.port}",
            p.country or "--",
            lat_str,
            status_str,
        )

    console.print(table)


@proxy.command(name="add")
@click.option("--proxy", "proxy_str", default=None, help="Proxy string (e.g. socks5://user:pass@host:port)")
@click.option("--file", "file_path", default=None, help="Text file with proxy list")
@click.option("--mode", default="http", help="Default mode if omitted (http/socks5)")
@click.option("--storage", default="proxies.json", help="Path to proxy storage JSON")
def proxy_add(proxy_str: Optional[str], file_path: Optional[str], mode: str, storage: str):
    """Add one or more proxies to the pool."""
    from sammonny.proxy.pool import ProxyPool
    pool = ProxyPool(storage)

    if file_path:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        count = pool.add_bulk(lines)
        console.print(f"[green]Successfully added [bold]{count}[/bold] proxies from [cyan]{file_path}[/cyan][/green]")
    elif proxy_str:
        p = pool.add(proxy_str)
        console.print(f"[green]Successfully added proxy [cyan]{p.id}[/cyan]: {p.to_url()}[/green]")
    else:
        console.print("[yellow]Please specify either --proxy or --file[/yellow]")


@proxy.command(name="test")
@click.option("--storage", default="proxies.json", help="Path to proxy storage JSON")
@click.option("--timeout", default=6.0, help="Test timeout in seconds")
def proxy_test(storage: str, timeout: float):
    """Test health, latency, and egress IP for all proxies in the pool."""
    from sammonny.proxy.pool import ProxyPool
    pool = ProxyPool(storage)
    console.print(f"[blue]Testing {pool.size()} proxies concurrently...[/blue]")
    results = pool.test_all(timeout_sec=timeout)

    alive_count = sum(1 for r in results.values() if r.is_alive)
    console.print(f"[green]Testing completed: [bold]{alive_count}/{len(results)}[/bold] proxies are ALIVE.[/green]")


@proxy.command(name="rotate")
@click.option("--profile", "profile_id", required=True, help="Profile ID to rotate proxy for")
@click.option("--storage", default="proxies.json", help="Path to proxy storage JSON")
def proxy_rotate(profile_id: str, storage: str):
    """Rotate proxy or trigger mobile IP renewal for a profile."""
    from sammonny.proxy.pool import ProxyPool
    pool = ProxyPool(storage)
    new_proxy = pool.rotate(profile_id)
    if new_proxy:
        console.print(f"[green]Successfully rotated profile [cyan]{profile_id}[/cyan] to proxy [magenta]{new_proxy.to_url()}[/magenta][/green]")
    else:
        console.print("[red]No available proxies in pool to rotate.[/red]")



# =============================================================================
# COOKIE COMMANDS
# =============================================================================

@cli.group()
def cookie():
    """Extract, import, and warm up profile cookies."""
    pass


@cookie.command(name="export")
@click.option("--id", "profile_id", required=True, help="Profile ID")
@click.option("--out", "out_file", default=None, help="Output file path")
@click.option("--format", "fmt", type=click.Choice(["json", "netscape"]), default="json")
@click.option("--profile-dir", default=None, help="Custom profile storage directory")
def cookie_export(profile_id: str, out_file: Optional[str], fmt: str, profile_dir: Optional[str]):
    """Export cookies offline from Chromium SQLite database."""
    default_root = Path(os.environ.get("SAMMONNY_PROFILES_DIR", "profiles"))
    base_dir = Path(profile_dir) if profile_dir else default_root / profile_id

    mgr = CookieSqliteManager(base_dir)
    try:
        if fmt == "netscape":
            data = mgr.export_netscape()
        else:
            cookies = mgr.export_cookies()
            data = json.dumps([c.to_dict() for c in cookies], indent=2)

        if out_file:
            with open(out_file, "w", encoding="utf-8") as f:
                f.write(data)
            console.print(f"[green]Successfully exported cookies to [cyan]{out_file}[/cyan][/green]")
        else:
            console.print(data)
    except Exception as e:
        console.print(f"[red]Error exporting cookies:[/red] {e}")


@cookie.command(name="import")
@click.option("--id", "profile_id", required=True, help="Profile ID")
@click.option("--file", "in_file", required=True, help="Input JSON file path")
@click.option("--profile-dir", default=None, help="Custom profile storage directory")
def cookie_import(profile_id: str, in_file: str, profile_dir: Optional[str]):
    """Import cookies directly into Chromium SQLite database."""
    default_root = Path(os.environ.get("SAMMONNY_PROFILES_DIR", "profiles"))
    base_dir = Path(profile_dir) if profile_dir else default_root / profile_id

    mgr = CookieSqliteManager(base_dir)
    try:
        with open(in_file, "r", encoding="utf-8") as f:
            raw = json.load(f)
        cookies = [CookieItem.from_dict(c) for c in raw]
        count = mgr.import_cookies(cookies)
        console.print(f"[green]Successfully imported [bold]{count}[/bold] cookies into SQLite database.[/green]")
    except Exception as e:
        console.print(f"[red]Error importing cookies:[/red] {e}")


@cookie.command(name="bot")
@click.option("--id", "profile_id", required=True, help="Profile ID")
@click.option("--urls", required=True, help="Comma-separated URLs to visit")
@click.pass_context
def cookie_bot(ctx, profile_id: str, urls: str):
    """Run automated Cookie Bot warm-up on target websites."""
    client: SamMonnyDaemonClient = ctx.obj["client"]
    ws_url = client.start_profile(profile_id)
    console.print(f"[cyan]Connecting CookieBot over CDP: {ws_url}[/cyan]")

    with SyncCdpClient(ws_url) as cdp:
        from sammonny.cookies.cookie_bot import CookieBot
        bot = CookieBot(cdp, log_callback=lambda m: console.print(f"[blue]{m}[/blue]"))
        url_list = [u.strip() for u in urls.split(",") if u.strip()]
        total = bot.warm_up(url_list)
        console.print(f"[green]CookieBot completed! Collected {total} cookies.[/green]")


# =============================================================================
# VISION COMMANDS
# =============================================================================

@cli.group()
def vision():
    """Visual template matching & Skia surface capture."""
    pass


@vision.command(name="screenshot")
@click.option("--id", "profile_id", required=True, help="Profile ID")
@click.option("--out", "out_file", required=True, help="Output PNG path")
@click.pass_context
def vision_screenshot(ctx, profile_id: str, out_file: str):
    """Capture Skia GPU surface screenshot even if minimized."""
    client: SamMonnyDaemonClient = ctx.obj["client"]
    ws_url = client.start_profile(profile_id)
    with SyncCdpClient(ws_url) as cdp:
        locator = ImageLocator(cdp)
        locator.screenshot(save_path=out_file)
        console.print(f"[green]Screenshot saved to [cyan]{out_file}[/cyan][/green]")


@vision.command(name="click")
@click.option("--id", "profile_id", required=True, help="Profile ID")
@click.option("--template", required=True, help="Path to button/card template PNG")
@click.option("--confidence", default=0.8, help="Minimum matching confidence (0.0 to 1.0)")
@click.option("--style", default="minimum_jerk", type=click.Choice(["minimum_jerk", "windmouse"]))
@click.pass_context
def vision_click(ctx, profile_id: str, template: str, confidence: float, style: str):
    """Locate visual template on screen and click with human kinematics."""
    client: SamMonnyDaemonClient = ctx.obj["client"]
    ws_url = client.start_profile(profile_id)
    with SyncCdpClient(ws_url) as cdp:
        locator = ImageLocator(cdp)
        console.print(f"[blue]Searching for template '{template}'...[/blue]")
        pt = locator.click_image(template, min_confidence=confidence, style=style)
        console.print(f"[green]Successfully clicked visual target at ({pt.x:.1f}, {pt.y:.1f})[/green]")


# =============================================================================
# DOM COMMANDS
# =============================================================================

@cli.group()
def dom():
    """Interact with DOM elements using human mouse kinematics."""
    pass


@dom.command(name="click")
@click.option("--id", "profile_id", required=True, help="Profile ID")
@click.option("--selector", required=True, help="CSS selector of element")
@click.option("--style", default="minimum_jerk", type=click.Choice(["minimum_jerk", "windmouse"]))
@click.pass_context
def dom_click(ctx, profile_id: str, selector: str, style: str):
    """Locate DOM element and click naturally with Gaussian dispersion."""
    client: SamMonnyDaemonClient = ctx.obj["client"]
    ws_url = client.start_profile(profile_id)
    with SyncCdpClient(ws_url) as cdp:
        controller = DOMController(cdp)
        console.print(f"[blue]Locating DOM selector '{selector}'...[/blue]")
        pt = controller.click(selector, style=style)
        console.print(f"[green]Clicked element at natural coordinate ({pt.x:.1f}, {pt.y:.1f})[/green]")


@dom.command(name="type")
@click.option("--id", "profile_id", required=True, help="Profile ID")
@click.option("--selector", required=True, help="CSS selector of input element")
@click.option("--text", required=True, help="Text to type")
@click.option("--wpm", default=85.0, help="Typing speed in Words Per Minute")
@click.pass_context
def dom_type(ctx, profile_id: str, selector: str, text: str, wpm: float):
    """Type text into DOM element with human typing cadence."""
    client: SamMonnyDaemonClient = ctx.obj["client"]
    ws_url = client.start_profile(profile_id)
    with SyncCdpClient(ws_url) as cdp:
        controller = DOMController(cdp)
        controller.type_text(selector, text, wpm=wpm)
        console.print(f"[green]Successfully typed '{text}' into '{selector}'[/green]")


# =============================================================================
# REUSABLE ENGINE SESSION COMMANDS
# =============================================================================

@cli.group()
def session():
    """Run reusable automation workflows through the unified Antidetect Engine."""
    pass


@session.command(name="run")
@click.option("--id", "profile_id", required=True, help="Profile ID")
@click.option("--url", required=True, help="Target URL to open and automate")
@click.option("--screenshot", "screenshot_path", default=None, help="Save screenshot to file")
@click.option("--headless", is_flag=True, help="Run headless")
@click.option("--auto-proxy", is_flag=True, help="Allocate proxy automatically from pool")
def session_run(profile_id: str, url: str, screenshot_path: Optional[str], headless: bool, auto_proxy: bool):
    """Launch a profile, navigate to URL, and capture state using AntidetectEngine."""
    from sammonny.engine.core import AntidetectEngine
    engine = AntidetectEngine()
    console.print(f"[blue]Starting engine session for profile [cyan]{profile_id}[/cyan] (Auto-Proxy: {auto_proxy})...[/blue]")

    with engine.session(profile_id, headless=headless, auto_proxy=auto_proxy) as sess:
        sess.goto(url)
        console.print(f"[green]Successfully navigated to [cyan]{url}[/cyan][/green]")
        if screenshot_path:
            sess.screenshot(screenshot_path)
            console.print(f"[green]Saved screenshot to [cyan]{screenshot_path}[/cyan][/green]")


# =============================================================================
# SOLVER COMMANDS
# =============================================================================

@cli.group()
def solver():
    """Automated CAPTCHA solvers (Color Text, Puzzle Slider, Checkbox)."""
    pass


@solver.command(name="captcha")
@click.option("--image", "image_path", required=True, help="Path to CAPTCHA image file")
@click.option("--prompt", required=True, help="Challenge prompt (e.g. 'màu đỏ', 'black')")
def solver_captcha(image_path: str, prompt: str):
    """Solve color-filtered text challenge CAPTCHA."""
    from sammonny.solver.color_captcha import ColorCaptchaSolver
    solver = ColorCaptchaSolver()
    result = solver.solve(image_path, prompt)
    console.print(f"[bold green]CAPTCHA Result:[/bold green] [cyan]{result}[/cyan]")


@solver.command(name="slider")
@click.option("--bg", "bg_path", required=True, help="Background image file path")
@click.option("--piece", "piece_path", default=None, help="Optional slider piece image path")
def solver_slider(bg_path: str, piece_path: Optional[str]):
    """Calculate horizontal offset X of puzzle gap."""
    from sammonny.solver.slider import SliderCaptchaSolver
    offset_x = SliderCaptchaSolver.find_gap_x_offset(bg_path, slider_piece=piece_path)
    console.print(f"[bold green]Slider Gap Detected at X Offset:[/bold green] [cyan]{offset_x}px[/cyan]")


# =============================================================================
# FINGERPRINT COMMANDS
# =============================================================================

@cli.group()
def fingerprint():
    """Generate and inspect Bayesian hardware fingerprints."""
    pass


@fingerprint.command(name="generate")
@click.option("--os", "os_name", default="win", type=click.Choice(["win", "mac", "lin"]))
@click.option("--country", default="VN", help="Country code for language/timezone (VN, US, GB, etc.)")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON format")
def fingerprint_generate(os_name: str, country: str, as_json: bool):
    """Generate an authentic, consistent antidetect browser fingerprint."""
    from sammonny.fingerprint.generator import FingerprintGenerator
    fp = FingerprintGenerator.generate(target_os=os_name, country_code=country)

    if as_json:
        import json
        console.print(json.dumps(fp.to_gologin_preferences("sample_id", "SampleProfile"), indent=2))
        return

    table = Table(title=f"Generated {os_name.upper()} Fingerprint")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="bold white")

    table.add_row("User-Agent", fp.user_agent[:60] + "...")
    table.add_row("Resolution", f"{fp.screen_width}x{fp.screen_height} (DPR: {fp.device_pixel_ratio})")
    table.add_row("Hardware", f"{fp.hardware_concurrency} Cores, {fp.device_memory} GB RAM")
    table.add_row("WebGL Renderer", fp.webgl_renderer[:50] + "...")
    table.add_row("Canvas Noise", f"{fp.canvas_noise}")
    table.add_row("Timezone / Lang", f"{fp.timezone} ({fp.language[:10]}...)")

    console.print(table)


# =============================================================================
# SYSTEM & RESOURCE SUPERVISION COMMANDS
# =============================================================================

@cli.group()
def system():
    """System memory trimming, orphan process sweep, and profile lock cleaner."""
    pass


@system.command(name="status")
def system_status():
    """Display host physical RAM usage and memory pressure status."""
    from sammonny.system.memory import MemoryManager
    mem = MemoryManager.get_host_memory()

    table = Table(title="Host Memory Status")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="bold white")

    table.add_row("Total RAM", f"{mem.total_mb:.1f} MB")
    table.add_row("Available RAM", f"{mem.available_mb:.1f} MB")
    table.add_row("Used RAM", f"{mem.used_mb:.1f} MB ({mem.percent}%)")
    status_str = "[red]HIGH PRESSURE[/red]" if mem.is_under_pressure else "[green]NORMAL[/green]"
    table.add_row("Memory Health", status_str)

    console.print(table)


@system.command(name="sweep")
@click.option("--dry-run", is_flag=True, help="Scan without terminating processes")
def system_sweep(dry_run: bool):
    """Scan and terminate abandoned/orphaned browser processes."""
    from sammonny.system.orphan_sweeper import OrphanSweeper
    swept = OrphanSweeper.sweep_orphaned_browsers(force_terminate=not dry_run)

    if not swept:
        console.print("[green]No orphaned browser processes found. System is clean![/green]")
        return

    table = Table(title=f"Swept Orphan Processes ({len(swept)})")
    table.add_column("PID", style="cyan")
    table.add_column("Process", style="white")
    table.add_column("Parent PID", style="yellow")
    table.add_column("RAM (MB)", style="magenta")
    table.add_column("Action", style="bold")

    for s in swept:
        table.add_row(
            str(s["pid"]),
            s["name"],
            str(s["ppid"]),
            f"{s['rss_mb']:.1f}",
            s["status"].upper(),
        )

    console.print(table)


@system.command(name="clean-locks")
@click.option("--dir", "profile_dir", required=True, help="Profile directory to clean")
def system_clean_locks(profile_dir: str):
    """Remove stale Singleton locks and LevelDB locks from profile."""
    from sammonny.system.orphan_sweeper import OrphanSweeper
    cleaned = OrphanSweeper.clean_stale_locks(Path(profile_dir))
    console.print(f"[green]Successfully cleaned [bold]{cleaned}[/bold] stale lock files in [cyan]{profile_dir}[/cyan][/green]")


@system.command(name="prune")
@click.option("--dir", "profile_dir", required=True, help="Profile directory to prune")
def system_prune(profile_dir: str):
    """Prune temporary Crashpad crash dumps and shader caches to save disk space."""
    from sammonny.system.orphan_sweeper import OrphanSweeper
    count, freed_mb = OrphanSweeper.prune_profile_garbage(Path(profile_dir))
    console.print(f"[green]Pruned [bold]{count}[/bold] cache files, freed [bold]{freed_mb} MB[/bold] disk space in [cyan]{profile_dir}[/cyan][/green]")


@system.command(name="trim-memory")
@click.option("--pid", required=True, type=int, help="Root PID of browser process")
def system_trim_memory(pid: int):
    """Trim working set memory for browser process tree via EmptyWorkingSet."""
    from sammonny.system.memory import MemoryManager
    res = MemoryManager.trim_process_tree_memory(pid)
    console.print(
        f"[green]Trimmed {res.processes_trimmed} processes. "
        f"RAM reduced from {res.rss_before_mb:.1f} MB -> {res.rss_after_mb:.1f} MB "
        f"(Freed: [bold]{res.freed_mb:.1f} MB[/bold], -{res.reduction_percent}%).[/green]"
    )


# =============================================================================
# VPN & LAYERED TUNNELING COMMANDS
# =============================================================================

@cli.group()
def vpn():
    """Manage WireGuard tunnels, Layered Tunneling, and Preflight Leak Audits."""
    pass


@vpn.command(name="conf-info")
@click.option("--file", "conf_path", required=True, help="Path to WireGuard .conf file")
def vpn_conf_info(conf_path: str):
    """Inspect WireGuard configuration parameters."""
    from sammonny.vpn.wireguard import WireGuardConfig
    cfg = WireGuardConfig.from_conf(conf_path)

    table = Table(title=f"WireGuard Config: {cfg.name or 'Tunnel'}")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="bold white")

    table.add_row("Client Address", cfg.address)
    table.add_row("Peer Endpoint", cfg.endpoint)
    table.add_row("Peer Public Key", cfg.peer_public_key[:24] + "...")
    table.add_row("DNS Server", cfg.dns or "None")
    table.add_row("Allowed IPs", cfg.allowed_ips)

    console.print(table)


@vpn.command(name="audit")
@click.option("--id", "profile_id", required=True, help="Profile ID to audit")
@click.pass_context
def vpn_audit(ctx, profile_id: str):
    """Run full preflight network leak audit (WebRTC, DNS, IPv6)."""
    client: SamMonnyDaemonClient = ctx.obj["client"]
    ws_url = client.start_profile(profile_id)
    with SyncCdpClient(ws_url) as cdp:
        from sammonny.vpn.audit import NetworkLeakAuditor
        auditor = NetworkLeakAuditor(cdp)
        console.print("[blue]Auditing network leaks on active profile session...[/blue]")
        report = auditor.audit_full()

        status_str = "[bold green]SECURE (NO LEAKS)[/bold green]" if report.is_safe else "[bold red]LEAK DETECTED[/bold red]"
        console.print(Panel(f"Overall Status: {status_str}\nEgress IP: {report.detected_egress_ip or 'Unknown'}", title="Leak Audit Report"))

        for d in report.details:
            color = "green" if "PASS" in d else ("yellow" if "Detected" in d else "red")
            console.print(f"[{color}]{d}[/{color}]")


# =============================================================================
# Extension Subcommand Group
# =============================================================================

@cli.group(name="extension")
def extension():
    """Manage browser extensions (.crx, .zip, Chrome Web Store ID, bindings)."""
    pass


@extension.command(name="list")
def ext_list():
    """List all installed extensions."""
    from sammonny.extensions.manager import ExtensionManager
    mgr = ExtensionManager()
    exts = mgr.list_installed()

    if not exts:
        console.print("[yellow]No extensions currently installed.[/yellow]")
        return

    table = Table(title="Installed Browser Extensions")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Version", style="magenta")
    table.add_column("Manifest", justify="center")
    table.add_column("Path", style="dim")

    for e in exts:
        table.add_row(e.id, e.name, e.version, f"MV{e.manifest_version}", str(e.path))

    console.print(table)


@extension.command(name="install")
@click.option("--id", "ext_id", default=None, help="Chrome Web Store 32-character extension ID")
@click.option("--file", "file_path", default=None, help="Path to local .crx or .zip file")
def ext_install(ext_id: Optional[str], file_path: Optional[str]):
    """Install an extension from Chrome Web Store or local .crx/.zip."""
    from sammonny.extensions.manager import ExtensionManager
    mgr = ExtensionManager()

    try:
        if ext_id:
            console.print(f"[blue]Downloading extension {ext_id} from Chrome Web Store...[/blue]")
            ext = mgr.install_from_webstore(ext_id)
            console.print(f"[green]Successfully installed:[/green] [bold]{ext.name}[/bold] (v{ext.version}) -> [cyan]{ext.id}[/cyan]")
        elif file_path:
            console.print(f"[blue]Unpacking extension from {file_path}...[/blue]")
            ext = mgr.install_from_file(file_path)
            console.print(f"[green]Successfully unpacked:[/green] [bold]{ext.name}[/bold] (v{ext.version}) -> [cyan]{ext.id}[/cyan]")
        else:
            console.print("[red]Error: You must provide either --id or --file[/red]")
    except Exception as e:
        console.print(f"[red]Failed to install extension:[/red] {e}")


@extension.command(name="delete")
@click.option("--id", "ext_id", required=True, help="Extension ID to delete")
def ext_delete(ext_id: str):
    """Delete an installed extension."""
    from sammonny.extensions.manager import ExtensionManager
    mgr = ExtensionManager()
    if mgr.delete_extension(ext_id):
        console.print(f"[green]Extension [bold]{ext_id}[/bold] deleted successfully.[/green]")
    else:
        console.print(f"[yellow]Extension {ext_id} not found.[/yellow]")


@extension.command(name="bind")
@click.option("--profile-id", required=True, help="Target Profile ID")
@click.option("--ext-id", required=True, help="Installed Extension ID")
def ext_bind(profile_id: str, ext_id: str):
    """Bind an extension to launch automatically with a profile."""
    from sammonny.extensions.manager import ExtensionManager
    mgr = ExtensionManager()
    try:
        mgr.bind_to_profile(profile_id, ext_id)
        console.print(f"[green]Successfully bound extension [bold]{ext_id}[/bold] to profile [bold]{profile_id}[/bold][/green]")
    except Exception as e:
        console.print(f"[red]Error binding extension:[/red] {e}")


@extension.command(name="unbind")
@click.option("--profile-id", required=True, help="Target Profile ID")
@click.option("--ext-id", required=True, help="Extension ID to unbind")
def ext_unbind(profile_id: str, ext_id: str):
    """Unbind an extension from a profile."""
    from sammonny.extensions.manager import ExtensionManager
    mgr = ExtensionManager()
    mgr.unbind_from_profile(profile_id, ext_id)
    console.print(f"[green]Unbound extension [bold]{ext_id}[/bold] from profile [bold]{profile_id}[/bold][/green]")


@extension.command(name="profile-list")
@click.option("--profile-id", required=True, help="Target Profile ID")
def ext_profile_list(profile_id: str):
    """List extensions bound to a specific profile."""
    from sammonny.extensions.manager import ExtensionManager
    mgr = ExtensionManager()
    exts = mgr.list_profile_extensions(profile_id)

    if not exts:
        console.print(f"[yellow]No extensions bound to profile {profile_id}.[/yellow]")
        return

    table = Table(title=f"Extensions for Profile {profile_id}")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Version", style="magenta")

    for e in exts:
        table.add_row(e.id, e.name, e.version)

    console.print(table)


# =============================================================================
# NETWORK MONITORING & ANTI-BOT TELEMETRY COMMANDS
# =============================================================================

@cli.group()
def network():
    """Real-time network inspection, WebSocket sniffing, and Anti-Bot telemetry decoding."""
    pass


@network.command(name="sniff")
@click.option("--id", "profile_id", required=True, help="Profile ID to launch and monitor")
@click.option("--url", required=True, help="Target URL to inspect")
@click.option("--duration", default=6.0, help="Monitoring duration in seconds")
@click.pass_context
def network_sniff(ctx, profile_id: str, url: str, duration: float):
    """Sniff real-time HTTP requests, responses, and WebSocket frames via CDP."""
    from sammonny.engine.core import AntidetectEngine
    engine = AntidetectEngine()

    console.print(f"[blue]Starting session for profile [cyan]{profile_id}[/cyan] to sniff network...[/blue]")
    with engine.session(profile_id, headless=False) as sess:
        console.print(f"[green]Navigating to [cyan]{url}[/cyan]...[/green]")
        sess.goto(url)
        time.sleep(duration)

        requests = sess.network.get_requests()
        responses = sess.network.get_responses()
        ws_frames = sess.network.get_websocket_frames()

        table = Table(title=f"Captured Network Traffic ({len(requests)} reqs, {len(responses)} resps, {len(ws_frames)} ws frames)")
        table.add_column("Type", style="magenta")
        table.add_column("Status / Method", style="cyan")
        table.add_column("URL / Payload", style="white")

        for r in requests[:15]:
            table.add_row("REQUEST", r.method, r.url[:75] + ("..." if len(r.url) > 75 else ""))

        for resp in responses[:15]:
            status_color = "green" if resp.status < 400 else "red"
            table.add_row("RESPONSE", f"[{status_color}]{resp.status}[/{status_color}]", resp.url[:75] + ("..." if len(resp.url) > 75 else ""))

        for f in ws_frames[:10]:
            table.add_row(f"WS {f.direction.upper()}", f"Opcode {f.opcode}", f.text()[:75] + ("..." if len(f.text()) > 75 else ""))

        console.print(table)


@network.command(name="telemetry")
@click.option("--id", "profile_id", required=True, help="Profile ID to launch and audit")
@click.option("--url", required=True, help="Target URL containing Anti-Bot or tracking script")
@click.option("--duration", default=8.0, help="Audit duration in seconds")
@click.pass_context
def network_telemetry(ctx, profile_id: str, url: str, duration: float):
    """Intercept, decode, and report anti-bot surveillance & telemetry beacons."""
    from sammonny.engine.core import AntidetectEngine
    engine = AntidetectEngine()

    console.print(f"[blue]Starting Anti-Bot Telemetry Audit for profile [cyan]{profile_id}[/cyan]...[/blue]")
    with engine.session(profile_id, headless=False) as sess:
        console.print(f"[green]Navigating to [cyan]{url}[/cyan]...[/green]")
        sess.goto(url)
        time.sleep(duration)

        telemetry_reports = sess.network.get_telemetry_reports()

        if not telemetry_reports:
            console.print("[yellow]No anti-bot or surveillance beacons detected on this page.[/yellow]")
            return

        table = Table(title=f"Intercepted Anti-Bot Surveillance Packets ({len(telemetry_reports)})")
        table.add_column("Platform", style="bold red")
        table.add_column("Probed Vectors", style="yellow")
        table.add_column("Orbita C++ Defense Applied", style="green")

        for rep in telemetry_reports:
            vectors = "\n".join(f"• {v}" for v in rep.probed_vectors)
            defenses = "\n".join(f"✔ {d[:60]}..." for d in rep.orbita_defense_applied)
            table.add_row(rep.target_platform.upper(), vectors, defenses)

        console.print(table)


@network.command(name="request")
@click.option("--id", "profile_id", required=True, help="Profile ID whose browser kernel will send the request")
@click.option("--url", required=True, help="Destination URL")
@click.option("--method", default="GET", help="HTTP method (GET, POST, PUT, DELETE)")
@click.option("--json", "json_str", default=None, help="JSON body string")
@click.option("--data", default=None, help="Raw body string")
@click.option("--headless/--headful", default=True, help="Run browser in background or with UI visible")
@click.option("--sign-bytedance", is_flag=True, help="Automatically inject ByteDance signatures (X-Bogus, a_bogus)")
def network_kernel_request(profile_id: str, url: str, method: str, json_str: Optional[str], data: Optional[str], headless: bool, sign_bytedance: bool):
    """Send outgoing HTTP request directly through the profile's Chromium browser kernel."""
    from sammonny.engine.core import AntidetectEngine
    import json as py_json
    engine = AntidetectEngine()

    parsed_json = None
    if json_str:
        try:
            parsed_json = py_json.loads(json_str)
        except Exception:
            parsed_json = json_str

    mode_label = "Headless Background" if headless else "Headful UI Visible"
    console.print(f"[blue]Dispatching [{method}] through Chromium Kernel ({mode_label}) for profile [cyan]{profile_id}[/cyan]...[/blue]")

    res = engine.http_request(
        profile_id=profile_id,
        method=method,
        url=url,
        json=parsed_json,
        data=data,
        headless=headless,
        sign_bytedance=sign_bytedance,
    )

    color = "green" if res.ok else "red"
    console.print(Panel(
        f"Status: [{color}]{res.status_code}[/{color}]\n"
        f"Engine: [cyan]{res.engine}[/cyan]\n"
        f"Elapsed: [yellow]{res.elapsed_ms:.2f} ms[/yellow]\n"
        f"Final URL: {res.url}\n\n"
        f"[bold]Response Body Preview:[/bold]\n{res.text[:300]}" + ("..." if len(res.text) > 300 else ""),
        title="Chromium Kernel Response"
    ))


# =============================================================================
# SIGNATURE COMMANDS (Browser Kernel & Hardware-Bound Signatures)
# =============================================================================

@cli.group()
def signature():
    """In-kernel & hardware-bound cryptographic signature generation."""
    pass


@signature.command(name="device-context")
@click.argument("profile_id")
@click.option("--region", default="US", help="ISO 2-letter country code (US, SG, VN, DE, etc.)")
def signature_device_context(profile_id: str, region: str):
    """Generate deterministic, persistent hardware & device tokens for a profile."""
    from sammonny.signatures.device_context import get_profile_device_context
    ctx = get_profile_device_context(profile_id, region=region)

    table = Table(title=f"Device Context Tokens for Profile [{profile_id}] (Region: {ctx.region})")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="bold green")

    table.add_row("Device ID", ctx.device_id)
    table.add_row("Install ID", ctx.install_id)
    table.add_row("Web ID", ctx.webid)
    table.add_row("OpenUDID", ctx.openudid)
    table.add_row("Verify FP", ctx.verify_fp)
    table.add_row("msToken", ctx.ms_token[:32] + "...")
    table.add_row("IDC Affinity", f"{ctx.idc} ({ctx.base_endpoint})")

    console.print(table)


@signature.command(name="sign-url")
@click.argument("url")
@click.option("--id", "profile_id", default="default", help="Profile ID to bind hardware seeds")
@click.option("--region", default="US", help="Country region (US, SG, DE, etc.)")
@click.option("--live", is_flag=True, help="Evaluate in live browser kernel via CDP")
def signature_sign_url(url: str, profile_id: str, region: str, live: bool):
    """Sign target URL with X-Bogus, a_bogus, and msToken."""
    from sammonny.signatures.harvester import KernelSignatureHarvester

    if live:
        from sammonny.engine.core import AntidetectEngine
        engine = AntidetectEngine()
        console.print(f"[blue]Connecting to live browser kernel for profile [cyan]{profile_id}[/cyan]...[/blue]")
        with engine.session(profile_id, headless=False) as sess:
            res = sess.signatures.sign_url(url, mode="live")
            console.print(Panel(
                f"[bold green]URL Signed via Browser Kernel V8 Runtime:[/bold green]\n{res['url']}\n\n"
                f"Signature: [cyan]{res.get('signature')}[/cyan]\n"
                f"a_bogus: [magenta]{res.get('aBogus')}[/magenta]\n"
                f"msToken: [yellow]{res.get('msToken')}[/yellow]",
                title="Live Kernel Signature"
            ))
    else:
        harvester = KernelSignatureHarvester(profile_id=profile_id, region=region)
        res = harvester.sign_url(url, mode="synthetic")
        console.print(Panel(
            f"[bold green]Signed URL:[/bold green]\n{res['url']}\n\n"
            f"X-Bogus (28-char): [cyan]{res['x_bogus']}[/cyan]\n"
            f"a_bogus (36-char): [magenta]{res['a_bogus']}[/magenta]\n"
            f"msToken: [yellow]{res['msToken'][:32]}...[/yellow]",
            title="Profile-Bound Signature"
        ))


@signature.command(name="request")
@click.argument("endpoint")
@click.option("--id", "profile_id", default="default", help="Profile ID to bind hardware seeds")
@click.option("--region", default="US", help="Country region (US, SG, DE, etc.)")
@click.option("--method", default="POST", help="HTTP Method")
@click.option("--body", default=None, help="JSON body string")
def signature_request(endpoint: str, profile_id: str, region: str, method: str, body: Optional[str]):
    """Generate complete ByteDance request envelope with X-Gorgon, X-Bogus, and X-ABogus."""
    from sammonny.signatures.harvester import KernelSignatureHarvester
    harvester = KernelSignatureHarvester(profile_id=profile_id, region=region)
    envelope = harvester.sign_request(endpoint=endpoint, method=method, body=body)

    table = Table(title="Generated Cryptographic Request Envelope")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Method", envelope["method"])
    table.add_row("IDC Regional Cluster", f"{envelope['idc']} ({envelope['region']})")
    table.add_row("X-Gorgon (S-box)", envelope["headers"]["X-Gorgon"])
    table.add_row("X-Bogus (Base64)", envelope["headers"]["X-Bogus"])
    table.add_row("X-ABogus (acrawler v3)", envelope["headers"]["X-ABogus"])
    table.add_row("X-Khronos", envelope["headers"]["X-Khronos"])
    table.add_row("X-SS-REQ-TICKET", envelope["headers"]["X-SS-REQ-TICKET"])
    table.add_row("Cookie", envelope["headers"]["Cookie"])

    console.print(table)
    console.print(f"\n[bold]Signed URL:[/bold]\n{envelope['url']}")


# =============================================================================
# GUI Launch Command
# =============================================================================

@cli.command(name="gui")
def launch_gui():
    """Launch the SamMonny Desktop Control Center GUI."""
    try:
        from sammonny.gui.app import run_gui
        run_gui()
    except Exception as e:
        console.print(f"[red]Failed to launch Desktop GUI:[/red] {e}")


if __name__ == "__main__":
    cli()





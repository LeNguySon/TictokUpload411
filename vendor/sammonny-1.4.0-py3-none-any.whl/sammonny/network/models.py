"""
Network Monitoring and Traffic Extraction Data Models.
Structured representations for HTTP Requests, HTTP Responses, and WebSocket Frames.
"""

from __future__ import annotations
import json
import time
from typing import Dict, Any, Optional, Union, List
from dataclasses import dataclass, field


@dataclass
class NetworkRequest:
    request_id: str
    url: str
    method: str
    headers: Dict[str, str] = field(default_factory=dict)
    post_data: Optional[str] = None
    resource_type: str = "other"
    timestamp: float = field(default_factory=time.time)

    def json_body(self) -> Optional[Any]:
        """Parse request post_data as JSON if possible."""
        if not self.post_data:
            return None
        try:
            return json.loads(self.post_data)
        except Exception:
            return None


@dataclass
class NetworkResponse:
    request_id: str
    url: str
    status: int
    status_text: str = ""
    headers: Dict[str, str] = field(default_factory=dict)
    mime_type: str = ""
    body: Optional[Union[str, bytes]] = None
    is_base64: bool = False
    from_disk_cache: bool = False
    timestamp: float = field(default_factory=time.time)

    def text(self) -> str:
        """Returns body as decoded string."""
        if self.body is None:
            return ""
        if isinstance(self.body, bytes):
            return self.body.decode("utf-8", errors="replace")
        return self.body

    def json(self) -> Optional[Any]:
        """Parses response body as JSON."""
        txt = self.text()
        if not txt:
            return None
        try:
            return json.loads(txt)
        except Exception:
            return None


@dataclass
class WebSocketFrame:
    request_id: str
    url: str
    payload: Union[str, bytes]
    opcode: int  # 1 = Text, 2 = Binary, 8 = Close, 9 = Ping, 10 = Pong
    direction: str  # "sent" or "received"
    timestamp: float = field(default_factory=time.time)

    @property
    def is_binary(self) -> bool:
        return self.opcode == 2 or isinstance(self.payload, bytes)

    def text(self) -> str:
        if isinstance(self.payload, bytes):
            return self.payload.decode("utf-8", errors="replace")
        return str(self.payload)

    def json(self) -> Optional[Any]:
        txt = self.text()
        try:
            return json.loads(txt)
        except Exception:
            return None


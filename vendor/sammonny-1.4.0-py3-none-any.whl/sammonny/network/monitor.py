"""
Real-time Network Traffic Monitor & WebSocket Frame Sniffer.
Enables high-speed CDP interception of HTTP(S) requests, responses, and raw WebSocket streams
without requiring an intermediate proxy or altering client TLS fingerprints.
"""

from __future__ import annotations
import base64
import fnmatch
import re
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Union

from sammonny.core.cdp import SyncCdpClient
from sammonny.network.models import NetworkRequest, NetworkResponse, WebSocketFrame
from sammonny.network.telemetry_decoder import AntiBotTelemetryDecoder, TelemetryReport


class NetworkMonitor:
    """
    CDP-Native Real-time Network Inspector and Traffic Harvester.
    """

    def __init__(self, cdp_client: SyncCdpClient, max_history: int = 1000):
        self.cdp = cdp_client
        self.max_history = max_history
        self._lock = threading.RLock()
        self.is_enabled = False

        self._requests: Dict[str, NetworkRequest] = {}
        self._responses: Dict[str, NetworkResponse] = {}
        self._ws_urls: Dict[str, str] = {}  # requestId -> websocket url
        self._ws_frames: List[WebSocketFrame] = []
        self._telemetry_reports: List[TelemetryReport] = []

        # Callbacks: List of (filter_pattern, callable)
        self._request_callbacks: List[Tuple[Optional[str], Callable[[NetworkRequest], None]]] = []
        self._response_callbacks: List[Tuple[Optional[str], Callable[[NetworkResponse], None], bool]] = []
        self._ws_callbacks: List[Tuple[Optional[str], Callable[[WebSocketFrame], None]]] = []
        self._telemetry_callbacks: List[Callable[[TelemetryReport], None]] = []

        self._last_activity_time = time.time()

    def enable(self, max_post_data_size: int = 67108864) -> None:
        """Enables Network domain tracking in the browser via CDP."""
        with self._lock:
            if self.is_enabled:
                return

            # Register CDP event listeners
            self.cdp.on("Network.requestWillBeSent", self._on_request_will_be_sent)
            self.cdp.on("Network.responseReceived", self._on_response_received)
            self.cdp.on("Network.loadingFinished", self._on_loading_finished)
            self.cdp.on("Network.webSocketCreated", self._on_ws_created)
            self.cdp.on("Network.webSocketFrameReceived", self._on_ws_frame_received)
            self.cdp.on("Network.webSocketFrameSent", self._on_ws_frame_sent)

            try:
                self.cdp.send(
                    "Network.enable",
                    {
                        "maxPostDataSize": max_post_data_size,
                        "maxResourceBufferSize": max_post_data_size,
                        "maxTotalBufferSize": max_post_data_size * 2,
                    },
                )
            except Exception:
                pass

            self.is_enabled = True

    def disable(self) -> None:
        """Disables Network domain tracking."""
        with self._lock:
            if not self.is_enabled:
                return

            self.cdp.off("Network.requestWillBeSent", self._on_request_will_be_sent)
            self.cdp.off("Network.responseReceived", self._on_response_received)
            self.cdp.off("Network.loadingFinished", self._on_loading_finished)
            self.cdp.off("Network.webSocketCreated", self._on_ws_created)
            self.cdp.off("Network.webSocketFrameReceived", self._on_ws_frame_received)
            self.cdp.off("Network.webSocketFrameSent", self._on_ws_frame_sent)

            try:
                self.cdp.send("Network.disable", {})
            except Exception:
                pass

            self.is_enabled = False

    def clear(self) -> None:
        """Clears captured traffic histories."""
        with self._lock:
            self._requests.clear()
            self._responses.clear()
            self._ws_urls.clear()
            self._ws_frames.clear()

    # =========================================================================
    # Internal Event Handlers
    # =========================================================================

    def _matches_filter(self, url: str, pattern: Optional[str]) -> bool:
        if not pattern:
            return True
        if pattern in url:
            return True
        return fnmatch.fnmatch(url, pattern)

    def _on_request_will_be_sent(self, params: Dict[str, Any]) -> None:
        self._last_activity_time = time.time()
        req_id = params.get("requestId", "")
        req_data = params.get("request", {})

        req = NetworkRequest(
            request_id=req_id,
            url=req_data.get("url", ""),
            method=req_data.get("method", "GET"),
            headers=req_data.get("headers", {}),
            post_data=req_data.get("postData"),
            resource_type=params.get("type", "other").lower(),
            timestamp=params.get("wallTime", time.time()),
        )

        with self._lock:
            self._requests[req_id] = req
            if len(self._requests) > self.max_history:
                # Evict oldest entry
                oldest_key = next(iter(self._requests))
                del self._requests[oldest_key]

        # Trigger callbacks
        for pattern, cb in list(self._request_callbacks):
            if self._matches_filter(req.url, pattern):
                try:
                    cb(req)
                except Exception:
                    pass

        # Check for Anti-Bot Telemetry Surveillance Beacon
        telemetry_report = AntiBotTelemetryDecoder.decode_request(req)
        if telemetry_report:
            with self._lock:
                self._telemetry_reports.append(telemetry_report)
                if len(self._telemetry_reports) > self.max_history:
                    self._telemetry_reports.pop(0)

            for cb in list(self._telemetry_callbacks):
                try:
                    cb(telemetry_report)
                except Exception:
                    pass

    def _on_response_received(self, params: Dict[str, Any]) -> None:
        self._last_activity_time = time.time()
        req_id = params.get("requestId", "")
        resp_data = params.get("response", {})

        resp = NetworkResponse(
            request_id=req_id,
            url=resp_data.get("url", ""),
            status=resp_data.get("status", 0),
            status_text=resp_data.get("statusText", ""),
            headers=resp_data.get("headers", {}),
            mime_type=resp_data.get("mimeType", ""),
            from_disk_cache=resp_data.get("fromDiskCache", False),
            timestamp=resp_data.get("responseTime", time.time()),
        )

        with self._lock:
            self._responses[req_id] = resp
            if len(self._responses) > self.max_history:
                oldest_key = next(iter(self._responses))
                del self._responses[oldest_key]

    def _on_loading_finished(self, params: Dict[str, Any]) -> None:
        self._last_activity_time = time.time()
        req_id = params.get("requestId", "")

        with self._lock:
            resp = self._responses.get(req_id)

        if not resp:
            return

        # Trigger callbacks that want immediate response notification
        for pattern, cb, load_body in list(self._response_callbacks):
            if self._matches_filter(resp.url, pattern):
                if load_body and resp.body is None:
                    try:
                        self.fetch_response_body(resp)
                    except Exception:
                        pass
                try:
                    cb(resp)
                except Exception:
                    pass

    def _on_ws_created(self, params: Dict[str, Any]) -> None:
        req_id = params.get("requestId", "")
        url = params.get("url", "")
        with self._lock:
            self._ws_urls[req_id] = url

    def _on_ws_frame_received(self, params: Dict[str, Any]) -> None:
        self._last_activity_time = time.time()
        req_id = params.get("requestId", "")
        resp_data = params.get("response", {})
        payload_data = resp_data.get("payloadData", "")
        opcode = int(resp_data.get("opcode", 1))

        url = self._ws_urls.get(req_id, "")
        payload: Union[str, bytes] = payload_data
        if opcode == 2:  # Binary frame (Base64 encoded by CDP)
            try:
                payload = base64.b64decode(payload_data)
            except Exception:
                pass

        frame = WebSocketFrame(
            request_id=req_id,
            url=url,
            payload=payload,
            opcode=opcode,
            direction="received",
            timestamp=params.get("timestamp", time.time()),
        )

        with self._lock:
            self._ws_frames.append(frame)
            if len(self._ws_frames) > self.max_history:
                self._ws_frames.pop(0)

        for pattern, cb in list(self._ws_callbacks):
            if self._matches_filter(url, pattern):
                try:
                    cb(frame)
                except Exception:
                    pass

    def _on_ws_frame_sent(self, params: Dict[str, Any]) -> None:
        self._last_activity_time = time.time()
        req_id = params.get("requestId", "")
        resp_data = params.get("response", {})
        payload_data = resp_data.get("payloadData", "")
        opcode = int(resp_data.get("opcode", 1))

        url = self._ws_urls.get(req_id, "")
        payload: Union[str, bytes] = payload_data
        if opcode == 2:
            try:
                payload = base64.b64decode(payload_data)
            except Exception:
                pass

        frame = WebSocketFrame(
            request_id=req_id,
            url=url,
            payload=payload,
            opcode=opcode,
            direction="sent",
            timestamp=params.get("timestamp", time.time()),
        )

        with self._lock:
            self._ws_frames.append(frame)
            if len(self._ws_frames) > self.max_history:
                self._ws_frames.pop(0)

        for pattern, cb in list(self._ws_callbacks):
            if self._matches_filter(url, pattern):
                try:
                    cb(frame)
                except Exception:
                    pass

    # =========================================================================
    # Public Query & Synchronous Waiting APIs
    # =========================================================================

    def fetch_response_body(self, response: NetworkResponse) -> Optional[Union[str, bytes]]:
        """Queries CDP Network.getResponseBody to fetch full payload for a response."""
        try:
            res = self.cdp.send("Network.getResponseBody", {"requestId": response.request_id})
            body_str = res.get("body", "")
            base64_encoded = res.get("base64Encoded", False)

            if base64_encoded:
                raw_bytes = base64.b64decode(body_str)
                response.body = raw_bytes
                response.is_base64 = True
                return raw_bytes
            else:
                response.body = body_str
                response.is_base64 = False
                return body_str
        except Exception:
            return None

    def on_request(
        self,
        callback: Callable[[NetworkRequest], None],
        filter_url: Optional[str] = None,
    ) -> None:
        """Register a callback for outgoing requests."""
        self._request_callbacks.append((filter_url, callback))

    def on_response(
        self,
        callback: Callable[[NetworkResponse], None],
        filter_url: Optional[str] = None,
        load_body: bool = True,
    ) -> None:
        """Register a callback for incoming HTTP responses."""
        self._response_callbacks.append((filter_url, callback, load_body))

    def on_websocket_frame(
        self,
        callback: Callable[[WebSocketFrame], None],
        filter_url: Optional[str] = None,
    ) -> None:
        """Register a callback for real-time WebSocket frames."""
        self._ws_callbacks.append((filter_url, callback))

    def on_telemetry_probe(
        self,
        callback: Callable[[TelemetryReport], None],
    ) -> None:
        """Register a callback when an anti-bot tracking or telemetry beacon is detected."""
        self._telemetry_callbacks.append(callback)

    def get_telemetry_reports(self, platform: Optional[str] = None) -> List[TelemetryReport]:
        """Returns captured anti-bot telemetry reports with probed vectors & Orbita C++ defenses."""
        with self._lock:
            reps = list(self._telemetry_reports)
        if platform:
            reps = [r for r in reps if r.target_platform.lower() == platform.lower()]
        return reps

    def get_requests(self, filter_url: Optional[str] = None) -> List[NetworkRequest]:
        """Returns list of all captured requests matching filter."""
        with self._lock:
            reqs = list(self._requests.values())
        if not filter_url:
            return reqs
        return [r for r in reqs if self._matches_filter(r.url, filter_url)]

    def get_responses(self, filter_url: Optional[str] = None) -> List[NetworkResponse]:
        """Returns list of all captured responses matching filter."""
        with self._lock:
            resps = list(self._responses.values())
        if not filter_url:
            return resps
        return [r for r in resps if self._matches_filter(r.url, filter_url)]

    def get_websocket_frames(
        self,
        filter_url: Optional[str] = None,
        direction: Optional[str] = None,
    ) -> List[WebSocketFrame]:
        """Returns captured WebSocket frames."""
        with self._lock:
            frames = list(self._ws_frames)
        filtered = frames
        if filter_url:
            filtered = [f for f in filtered if self._matches_filter(f.url, filter_url)]
        if direction:
            filtered = [f for f in filtered if f.direction == direction]
        return filtered

    def wait_for_response(
        self,
        url_pattern: str,
        timeout: float = 10.0,
        load_body: bool = True,
        poll_interval: float = 0.1,
    ) -> NetworkResponse:
        """Blocks until a response matching url_pattern arrives or timeout expires."""
        start = time.time()
        while time.time() - start < timeout:
            for resp in self.get_responses(url_pattern):
                if resp.status > 0:
                    if load_body and resp.body is None:
                        self.fetch_response_body(resp)
                    return resp
            time.sleep(poll_interval)
        raise TimeoutError(f"Network response matching '{url_pattern}' timed out after {timeout}s")

    def wait_for_websocket_frame(
        self,
        predicate: Optional[Callable[[WebSocketFrame], bool]] = None,
        filter_url: Optional[str] = None,
        timeout: float = 10.0,
        poll_interval: float = 0.1,
    ) -> WebSocketFrame:
        """Blocks until a WebSocket frame satisfying predicate arrives or timeout expires."""
        start = time.time()
        while time.time() - start < timeout:
            for frame in self.get_websocket_frames(filter_url):
                if predicate is None or predicate(frame):
                    return frame
            time.sleep(poll_interval)
        raise TimeoutError(f"WebSocket frame satisfying predicate timed out after {timeout}s")

    def wait_for_idle(self, idle_time_sec: float = 0.6, timeout: float = 10.0) -> bool:
        """Waits until no network requests/responses have occurred for idle_time_sec."""
        start = time.time()
        while time.time() - start < timeout:
            if time.time() - self._last_activity_time >= idle_time_sec:
                return True
            time.sleep(0.1)
        return False


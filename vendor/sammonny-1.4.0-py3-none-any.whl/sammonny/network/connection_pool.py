"""
sammonny.network.connection_pool
================================
Chromium In-Kernel Socket Pool & Connection Cache Supervisor.
Enables pre-warming of TCP/TLS connections (0-RTT Session Resumption),
browser cache clearing, and socket pool flushing to support high-performance
long-term automation sessions.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional
from urllib.parse import urlparse

from sammonny.core.cdp import SyncCdpClient

logger = logging.getLogger("sammonny.network.connection_pool")


class KernelConnectionPool:
    """
    Supervises Chromium socket pools, pre-connect warmup, and TLS session tickets.
    """

    def __init__(self, cdp_client: SyncCdpClient) -> None:
        self.cdp = cdp_client

    def preconnect(self, url: str) -> bool:
        """
        Pre-warms the TCP/TLS socket to the target domain in Chromium's socket pool.
        Subsequent requests to this domain execute with instantaneous 0-RTT latency.
        """
        parsed = urlparse(url)
        origin = f"{parsed.scheme}://{parsed.netloc}"
        js_code = f"""
        (() => {{
            try {{
                const link = document.createElement('link');
                link.rel = 'preconnect';
                link.href = {repr(origin)};
                link.crossOrigin = 'anonymous';
                document.head.appendChild(link);
                return true;
            }} catch (e) {{
                return false;
            }}
        }})()
        """
        try:
            res = self.cdp.evaluate(js_code)
            return bool(res)
        except Exception as e:
            logger.debug("preconnect error: %s", e)
            return False

    def clear_cache(self) -> bool:
        """Flushes Chromium's internal disk and memory HTTP cache."""
        try:
            self.cdp.send("Network.clearBrowserCache")
            return True
        except Exception as e:
            logger.debug("clear_cache error: %s", e)
            return False

    def clear_cookies(self) -> bool:
        """Flushes Chromium's in-memory and disk cookies."""
        try:
            self.cdp.send("Network.clearBrowserCookies")
            return True
        except Exception as e:
            logger.debug("clear_cookies error: %s", e)
            return False


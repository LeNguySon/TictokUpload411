"""
sammonny.network.kernel_http
============================
Browser-Kernel Network Client (In-Kernel Egress Dispatcher).
Dispatches outgoing HTTP/HTTPS requests directly through the running Chromium
network stack (net::URLRequest, BoringSSL TLS 1.3, Chromium HTTP/2 socket pool,
native proxy routing, and native profile cookie jar).

Guarantees 100% genuine Layer 4 - Layer 7 fingerprints (JA3/JA4, ALPN, Priority,
Client Hints) matching a real browser profile, both with UI open (headless=False)
and in background (headless=True).
"""

from __future__ import annotations

import base64
import json
import logging
import time
from typing import Any, Dict, List, Optional, Union
from urllib.parse import urlencode, urlparse, parse_qsl, urlunparse

from sammonny.core.cdp import SyncCdpClient

logger = logging.getLogger("sammonny.network.kernel_http")


class KernelResponse:
    """
    HTTP Response returned from the Chromium browser kernel.
    Mirrors standard HTTP response objects with status_code, headers, text, and json().
    """

    def __init__(
        self,
        status_code: int,
        headers: Dict[str, str],
        text: str,
        content: bytes,
        url: str,
        ok: bool,
        elapsed_ms: float = 0.0,
        engine: str = "orbita_kernel_v8",
        error: Optional[str] = None,
    ) -> None:
        self.status_code = status_code
        self.headers = headers
        self.text = text
        self.content = content
        self.url = url
        self.ok = ok
        self.elapsed_ms = elapsed_ms
        self.engine = engine
        self.error = error

    def json(self) -> Any:
        """Parses the response text as JSON."""
        return json.loads(self.text)

    def __repr__(self) -> str:
        status_str = f"status={self.status_code}" if self.status_code else f"error={self.error}"
        return f"<KernelResponse [{status_str}] url='{self.url}' engine='{self.engine}'>"


class KernelHttpClient:
    """
    High-level HTTP Client executing outgoing requests via the Chromium browser kernel.
    Operates through active CDP connection to running Orbita V8 runtime.
    """

    def __init__(self, cdp_client: SyncCdpClient, session: Optional[Any] = None) -> None:
        self.cdp = cdp_client
        self.session = session

    def request(
        self,
        method: str,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Union[bytes, str, Dict[str, Any]]] = None,
        json: Optional[Any] = None,
        headers: Optional[Dict[str, str]] = None,
        cookies: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
        sign_bytedance: bool = False,
        auto_navigate: bool = False,
    ) -> KernelResponse:
        """
        Dispatches an HTTP request through Chromium's native network stack.

        Args:
            method: HTTP verb ('GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD').
            url: Target URL.
            params: Query parameters to append to URL.
            data: Raw string, bytes, or form-encoded dict.
            json: JSON-serializable object for request body.
            headers: Custom request headers.
            cookies: Additional cookies to attach.
            timeout: Maximum execution timeout in seconds.
            sign_bytedance: Automatically inject ByteDance signatures (X-Bogus, a_bogus, msToken).
            auto_navigate: Navigate current page to target domain before sending to inherit same-origin credentials.
        """
        method_upper = method.upper()

        # 1. Merge Query Parameters into URL
        target_url = url
        if params:
            parsed = urlparse(target_url)
            existing_params = dict(parse_qsl(parsed.query))
            for k, v in params.items():
                existing_params[str(k)] = str(v)
            new_query = urlencode(existing_params)
            target_url = urlunparse((
                parsed.scheme,
                parsed.netloc,
                parsed.path,
                parsed.params,
                new_query,
                parsed.fragment,
            ))

        req_headers = dict(headers or {})

        # 2. Format Body
        body_str: Optional[str] = None
        is_base64_binary = False

        if json is not None:
            import json as py_json
            body_str = py_json.dumps(json)
            req_headers.setdefault("Content-Type", "application/json")
        elif data is not None:
            if isinstance(data, bytes):
                body_str = base64.b64encode(data).decode("ascii")
                is_base64_binary = True
            elif isinstance(data, dict):
                body_str = urlencode(data)
                req_headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
            else:
                body_str = str(data)

        # 3. Optional ByteDance Signature Injection
        if sign_bytedance:
            target_url, req_headers = self._apply_bytedance_signatures(
                url=target_url,
                headers=req_headers,
                body=body_str,
                cookies=cookies,
            )

        # 4. Optional Auto-Navigation for Same-Origin
        if auto_navigate and self.session:
            parsed = urlparse(target_url)
            base_origin = f"{parsed.scheme}://{parsed.netloc}"
            try:
                curr_url = getattr(self.session.cdp, "_current_url", "")
                if base_origin not in curr_url:
                    self.session.goto(base_origin)
            except Exception:
                pass

        # 5. Dispatch via V8 Runtime Fetch
        start_time = time.perf_counter()
        v8_result = self._dispatch_v8_fetch(
            method=method_upper,
            url=target_url,
            headers=req_headers,
            body_str=body_str,
            is_base64_binary=is_base64_binary,
            cookies=cookies,
            timeout_ms=int(timeout * 1000),
        )
        elapsed_ms = (time.perf_counter() - start_time) * 1000.0

        if v8_result.get("ok_dispatch"):
            status_code = v8_result.get("status", 0)
            ok = v8_result.get("ok", status_code < 400)
            res_headers = v8_result.get("headers", {})
            text = v8_result.get("text", "")
            base64_data = v8_result.get("base64_data")
            content = base64.b64decode(base64_data) if base64_data else text.encode("utf-8")
            final_url = v8_result.get("url", target_url)

            return KernelResponse(
                status_code=status_code,
                headers=res_headers,
                text=text,
                content=content,
                url=final_url,
                ok=ok,
                elapsed_ms=elapsed_ms,
                engine="orbita_kernel_v8",
            )

        # 6. Fallback: CDP Network.loadNetworkResource for cross-origin GET
        err_msg = v8_result.get("error", "Unknown V8 dispatch error")
        if method_upper == "GET" and "failed to fetch" in err_msg.lower():
            logger.debug("V8 fetch encountered CORS restriction. Falling back to CDP Network.loadNetworkResource.")
            cdp_res = self._dispatch_cdp_network_load(target_url, req_headers)
            if cdp_res is not None:
                cdp_res.elapsed_ms = elapsed_ms
                return cdp_res

        return KernelResponse(
            status_code=0,
            headers={},
            text="",
            content=b"",
            url=target_url,
            ok=False,
            elapsed_ms=elapsed_ms,
            engine="orbita_kernel_v8",
            error=err_msg,
        )

    # =========================================================================
    # V8 In-Browser Fetch Implementation
    # =========================================================================

    def _dispatch_v8_fetch(
        self,
        method: str,
        url: str,
        headers: Dict[str, str],
        body_str: Optional[str],
        is_base64_binary: bool,
        cookies: Optional[Dict[str, str]],
        timeout_ms: int,
    ) -> Dict[str, Any]:
        """Executes window.fetch() inside active Chromium tab via CDP Runtime.evaluate."""
        import json as py_json
        headers_json = py_json.dumps(headers)
        body_json = py_json.dumps(body_str) if body_str is not None else "null"

        js_script = f"""
        (async () => {{
            const targetUrl = {py_json.dumps(url)};
            const method = {py_json.dumps(method)};
            const rawHeaders = {headers_json};
            const rawBody = {body_json};
            const isBase64Binary = {py_json.dumps(is_base64_binary)};
            const timeoutMs = {timeout_ms};

            let controller = null;
            let timeoutId = null;
            if (typeof AbortController !== 'undefined') {{
                controller = new AbortController();
                timeoutId = setTimeout(() => controller.abort(), timeoutMs);
            }}

            try {{
                const fetchOpts = {{
                    method: method,
                    headers: {{ ...rawHeaders }},
                    credentials: "include",
                    mode: "cors"
                }};
                if (controller) {{
                    fetchOpts.signal = controller.signal;
                }}

                if (rawBody !== null && method !== "GET" && method !== "HEAD") {{
                    if (isBase64Binary) {{
                        const binStr = atob(rawBody);
                        const len = binStr.length;
                        const bytes = new Uint8Array(len);
                        for (let i = 0; i < len; i++) {{
                            bytes[i] = binStr.charCodeAt(i);
                        }}
                        fetchOpts.body = bytes;
                    }} else {{
                        fetchOpts.body = rawBody;
                    }}
                }}

                const resp = await window.fetch(targetUrl, fetchOpts);
                if (timeoutId) clearTimeout(timeoutId);

                const resHeaders = {{}};
                if (resp.headers && typeof resp.headers.entries === 'function') {{
                    for (const [k, v] of resp.headers.entries()) {{
                        resHeaders[k] = v;
                    }}
                }}

                // Check content type for binary vs text
                const cType = (resHeaders['content-type'] || '').toLowerCase();
                const isBinary = cType.includes('octet-stream') || cType.includes('image/') || cType.includes('audio/') || cType.includes('video/');

                let text = "";
                let base64Data = null;

                if (isBinary) {{
                    const ab = await resp.arrayBuffer();
                    const u8 = new Uint8Array(ab);
                    let binary = '';
                    for (let i = 0; i < u8.byteLength; i++) {{
                        binary += String.fromCharCode(u8[i]);
                    }}
                    base64Data = btoa(binary);
                }} else {{
                    text = await resp.text();
                }}

                return {{
                    ok_dispatch: true,
                    status: resp.status,
                    ok: resp.ok,
                    url: resp.url || targetUrl,
                    headers: resHeaders,
                    text: text,
                    base64_data: base64Data
                }};
            }} catch (err) {{
                if (timeoutId) clearTimeout(timeoutId);
                return {{
                    ok_dispatch: false,
                    error: err.toString()
                }};
            }}
        }})()
        """
        try:
            res = self.cdp.evaluate(js_script)
            if isinstance(res, dict):
                return res
        except Exception as exc:
            return {"ok_dispatch": False, "error": str(exc)}

        return {"ok_dispatch": False, "error": "CDP evaluation returned non-dict result"}

    # =========================================================================
    # CDP Network Load Resource Fallback
    # =========================================================================

    def _dispatch_cdp_network_load(
        self,
        url: str,
        headers: Dict[str, str],
    ) -> Optional[KernelResponse]:
        """Fallback for cross-origin GET requests using CDP Network.loadNetworkResource."""
        try:
            tree = self.cdp.send("Page.getFrameTree")
            frame_id = tree.get("frameTree", {}).get("frame", {}).get("id")
            if not frame_id:
                return None

            load_res = self.cdp.send("Network.loadNetworkResource", {
                "frameId": frame_id,
                "url": url,
                "options": {
                    "disableCache": True,
                    "includeCredentials": True,
                },
            })

            resource = load_res.get("resource", {})
            if not resource.get("success"):
                return None

            status_code = resource.get("httpStatusCode", 200)
            res_headers = resource.get("headers", {})
            stream = resource.get("stream")
            text = ""

            if stream:
                try:
                    read_res = self.cdp.send("IO.read", {"handle": stream})
                    text = read_res.get("data", "")
                finally:
                    self.cdp.send("IO.close", {"handle": stream})

            return KernelResponse(
                status_code=status_code,
                headers=res_headers,
                text=text,
                content=text.encode("utf-8"),
                url=url,
                ok=status_code < 400,
                engine="orbita_kernel_cdp_resource",
            )
        except Exception as exc:
            logger.debug("CDP loadNetworkResource error: %s", exc)
            return None

    # =========================================================================
    # ByteDance Signature Wrapper
    # =========================================================================

    def _apply_bytedance_signatures(
        self,
        url: str,
        headers: Dict[str, str],
        body: Optional[str],
        cookies: Optional[Dict[str, str]],
    ) -> tuple[str, Dict[str, str]]:
        """Applies ByteDance signatures (X-Gorgon, X-Bogus, a_bogus, msToken) to request."""
        if not self.session:
            return url, headers

        try:
            envelope = self.session.signatures.sign_request(
                endpoint=url,
                body=body,
                cookies=cookies,
                custom_headers=headers,
            )
            return envelope["url"], envelope["headers"]
        except Exception as e:
            logger.debug("ByteDance signature automatic injection skipped: %s", e)
            return url, headers

    # =========================================================================
    # Fluent HTTP Verb Shortcuts
    # =========================================================================

    def get(self, url: str, **kwargs) -> KernelResponse:
        """Sends a GET request through the browser kernel."""
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs) -> KernelResponse:
        """Sends a POST request through the browser kernel."""
        return self.request("POST", url, **kwargs)

    def put(self, url: str, **kwargs) -> KernelResponse:
        """Sends a PUT request through the browser kernel."""
        return self.request("PUT", url, **kwargs)

    def delete(self, url: str, **kwargs) -> KernelResponse:
        """Sends a DELETE request through the browser kernel."""
        return self.request("DELETE", url, **kwargs)

    def patch(self, url: str, **kwargs) -> KernelResponse:
        """Sends a PATCH request through the browser kernel."""
        return self.request("PATCH", url, **kwargs)

    def head(self, url: str, **kwargs) -> KernelResponse:
        """Sends a HEAD request through the browser kernel."""
        return self.request("HEAD", url, **kwargs)


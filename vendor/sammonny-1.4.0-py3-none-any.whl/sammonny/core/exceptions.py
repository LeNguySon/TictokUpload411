"""
Exceptions for SamMonny Antidetect Python SDK.
"""

class SamMonnyError(Exception):
    """Base exception for all SamMonny SDK operations."""
    pass


class DaemonConnectionError(SamMonnyError):
    """Raised when failing to communicate with local daemon on 7654 or 36912."""
    pass


class ProfileError(SamMonnyError):
    """Raised when a profile operation fails (not found, start failure, invalid json)."""
    pass


class CdpError(SamMonnyError):
    """Raised when a Chrome DevTools Protocol command or connection fails."""
    pass


class VisionError(SamMonnyError):
    """Raised when visual template extraction or matching fails."""
    pass


class DOMError(SamMonnyError):
    """Raised when an element cannot be found in the DOM or bounding box is invalid."""
    pass


class CookieError(SamMonnyError):
    """Raised when SQLite cookie extraction or import fails."""
    pass

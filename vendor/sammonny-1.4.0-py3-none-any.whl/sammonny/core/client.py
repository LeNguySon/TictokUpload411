"""
High-Performance HTTP Daemon Client for SamMonny & GoLogin Local Servers.
Connects with both Port 7654 (Internal Daemon) and Port 36912 (Official SDK Daemon).
"""

from __future__ import annotations
import json
import base64
import urllib.request
import urllib.error
import urllib.parse
from typing import Any, Dict, List, Optional, Union
from pathlib import Path

from sammonny.core.exceptions import DaemonConnectionError, ProfileError
from sammonny.core.models import ProfileInfo, CookieItem


class SamMonnyDaemonClient:
    def __init__(
        self,
        base_url: str = "http://127.0.0.1:7654",
        sdk_url: str = "http://127.0.0.1:36912",
        timeout: float = 30.0,
    ):
        self.base_url = base_url.rstrip("/")
        self.sdk_url = sdk_url.rstrip("/")
        self.timeout = timeout

    def _request(
        self,
        method: str,
        path: str,
        payload: Optional[Dict[str, Any]] = None,
        use_sdk_port: bool = False,
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        host = self.sdk_url if use_sdk_port else self.base_url
        url = f"{host}{path}"
        req_headers = {
            "Accept": "application/json",
            "User-Agent": "SamMonny-Python-SDK/1.0",
        }
        if headers:
            req_headers.update(headers)

        data = None
        if payload is not None:
            data = json.dumps(payload).encode("utf-8")
            req_headers["Content-Type"] = "application/json"

        req = urllib.request.Request(url, data=data, headers=req_headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                status_code = resp.getcode()
                body = resp.read().decode("utf-8")
                if not body:
                    return {"status": "ok", "status_code": status_code}
                try:
                    return json.loads(body)
                except json.JSONDecodeError:
                    return body
        except urllib.error.HTTPError as e:
            err_body = e.read().decode("utf-8", errors="replace")
            raise ProfileError(f"HTTP {e.code} Error on {method} {url}: {err_body}") from e
        except urllib.error.URLError as e:
            raise DaemonConnectionError(
                f"Failed to connect to SamMonny daemon at {url}: {e.reason}"
            ) from e

    # =========================================================================
    # Health & Diagnostics
    # =========================================================================

    def check_health(self) -> Dict[str, Any]:
        """Check status of daemon on 7654 and official SDK on 36912."""
        status = {"daemon_7654": False, "sdk_36912": False}
        try:
            res_7654 = self._request("GET", "/health", use_sdk_port=False)
            status["daemon_7654"] = True
            status["info_7654"] = res_7654
        except Exception:
            pass

        try:
            res_36912 = self._request("GET", "/service/check-server", use_sdk_port=True)
            status["sdk_36912"] = True
            status["info_36912"] = res_36912
        except Exception:
            pass

        return status

    # =========================================================================
    # Profile Lifecycle Management
    # =========================================================================

    def list_profiles(self) -> List[ProfileInfo]:
        """Fetch all profiles registered in the local daemon storage."""
        data = self._request("GET", "/api/v1/profiles")
        profiles_list = data if isinstance(data, list) else data.get("profiles", [])
        results = []
        for p in profiles_list:
            results.append(
                ProfileInfo(
                    id=p.get("id", ""),
                    name=p.get("name", ""),
                    os=p.get("os", "win"),
                    proxy=p.get("proxy"),
                    status=p.get("status", "stopped"),
                    port=p.get("port"),
                    ws_url=p.get("wsUrl") or p.get("ws_url"),
                    raw_data=p,
                )
            )
        return results

    def get_profile(self, profile_id: str) -> Optional[ProfileInfo]:
        """Retrieve a specific profile by ID."""
        try:
            p = self._request("GET", f"/api/v1/profiles/{profile_id}")
            return ProfileInfo(
                id=p.get("id", profile_id),
                name=p.get("name", ""),
                os=p.get("os", "win"),
                proxy=p.get("proxy"),
                status=p.get("status", "stopped"),
                port=p.get("port"),
                ws_url=p.get("wsUrl") or p.get("ws_url"),
                raw_data=p,
            )
        except Exception:
            return None

    def create_profile(
        self,
        name: str,
        os_name: str = "win",
        proxy: Optional[str] = None,
        group: Optional[str] = None,
        notes: Optional[str] = None,
    ) -> ProfileInfo:
        """Create a new profile with offline Bayesian fingerprint."""
        payload: Dict[str, Any] = {
            "name": name,
            "os": os_name,
        }
        if proxy:
            payload["proxy"] = proxy
        if group:
            payload["group"] = group
        if notes:
            payload["notes"] = notes

        res = self._request("POST", "/api/v1/profiles", payload)
        pid = res.get("id") or res.get("profile_id", "")
        return ProfileInfo(
            id=pid,
            name=name,
            os=os_name,
            proxy=proxy,
            status="stopped",
            raw_data=res,
        )

    def delete_profile(self, profile_id: str) -> bool:
        """Delete profile directory and metadata."""
        try:
            self._request("DELETE", f"/api/v1/profiles/{profile_id}")
            return True
        except Exception:
            return False

    def start_profile(
        self,
        profile_id: str,
        sync: bool = False,
        headless: bool = False,
        prefer_sdk_port: bool = False,
    ) -> str:
        """
        Start browser profile. Returns the CDP WebSocket URL (ws://127.0.0.1:port/devtools/browser/...).
        Supports both 7654 (/api/v1/profiles/{id}/start) and 36912 (/browser/start-profile).
        """
        if prefer_sdk_port:
            res = self._request(
                "POST",
                "/browser/start-profile",
                {"profileId": profile_id, "sync": sync},
                use_sdk_port=True,
            )
        else:
            res = self._request(
                "POST",
                f"/api/v1/profiles/{profile_id}/start",
                {"sync": sync, "headless": headless},
                use_sdk_port=False,
            )

        ws_url = res.get("wsUrl") or res.get("ws_url") or ""
        return ws_url

    def stop_profile(self, profile_id: str, prefer_sdk_port: bool = False) -> bool:
        """Stop a running profile."""
        if prefer_sdk_port:
            try:
                self._request(
                    "POST",
                    "/browser/stop-profile",
                    {"profileId": profile_id},
                    use_sdk_port=True,
                )
                return True
            except Exception:
                return False
        else:
            try:
                res = self._request("POST", f"/api/v1/profiles/{profile_id}/stop")
                return res.get("status") in ("success", "stopped", "ok")
            except Exception:
                return False

    # =========================================================================
    # Cookie Endpoints
    # =========================================================================

    def get_cookies(self, profile_id: str) -> List[CookieItem]:
        """Fetch cookies stored in profile's SQLite database via server."""
        data = self._request("GET", f"/cookies/{profile_id}")
        if isinstance(data, list):
            return [CookieItem.from_dict(c) for c in data]
        return []

    def set_cookies(self, profile_id: str, cookies: List[CookieItem]) -> bool:
        """Set cookies into profile's SQLite database via server."""
        payload = [c.to_dict() for c in cookies]
        res = self._request("POST", f"/cookies/{profile_id}", payload)
        return bool(res)

    # =========================================================================
    # Visual & Stealth Endpoints
    # =========================================================================

    def navigate(self, profile_id: str, url: str) -> Dict[str, Any]:
        return self._request(
            "POST", f"/api/v1/profiles/{profile_id}/stealth/navigate", {"url": url}
        )

    def screenshot_surface(self, profile_id: str) -> bytes:
        """Capture Skia GPU screenshot even if window is minimized or occluded."""
        res = self._request("POST", f"/api/v1/profiles/{profile_id}/stealth/screenshot")
        b64_data = res.get("data", "")
        return base64.b64decode(b64_data)

    def click_visual(
        self,
        profile_id: str,
        template_path: Optional[str] = None,
        template: Optional[Dict[str, Any]] = None,
        scales: Optional[List[float]] = None,
        max_score: float = 6.0,
        style: str = "minimum_jerk",
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "scales": scales or [0.9, 1.0, 1.1],
            "max_score": max_score,
            "style": style,
        }
        if template_path:
            payload["template_path"] = template_path
        elif template:
            payload["template"] = template
        return self._request(
            "POST", f"/api/v1/profiles/{profile_id}/stealth/click-visual", payload
        )

    def move_human(
        self, profile_id: str, x: float, y: float, style: str = "minimum_jerk"
    ) -> Dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/profiles/{profile_id}/stealth/move-human",
            {"x": x, "y": y, "style": style},
        )

    def click_human(
        self, profile_id: str, x: float, y: float, style: str = "minimum_jerk"
    ) -> Dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/profiles/{profile_id}/stealth/click-human",
            {"x": x, "y": y, "style": style},
        )

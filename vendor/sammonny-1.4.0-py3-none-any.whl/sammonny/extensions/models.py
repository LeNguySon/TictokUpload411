"""
Browser Extension Data Models for SamMonny Antidetect Suite.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Any, Optional, List


@dataclass
class ExtensionItem:
    id: str
    name: str
    version: str
    path: Path
    description: str = ""
    enabled: bool = True
    manifest_version: int = 3
    permissions: List[str] = field(default_factory=list)
    raw_manifest: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "version": self.version,
            "path": str(self.path),
            "description": self.description,
            "enabled": self.enabled,
            "manifest_version": self.manifest_version,
            "permissions": self.permissions,
        }

    @classmethod
    def from_manifest(cls, ext_id: str, ext_dir: Path) -> ExtensionItem:
        import json
        manifest_file = ext_dir / "manifest.json"
        if not manifest_file.exists():
            raise FileNotFoundError(f"manifest.json not found in {ext_dir}")

        with open(manifest_file, "r", encoding="utf-8") as f:
            data = json.load(f)

        name = data.get("name", ext_id)
        # Handle __MSG_appName__ localization references if present
        if name.startswith("__MSG_") and name.endswith("__"):
            name = ext_id

        return cls(
            id=ext_id,
            name=name,
            version=data.get("version", "1.0.0"),
            path=ext_dir,
            description=data.get("description", ""),
            manifest_version=data.get("manifest_version", 3),
            permissions=data.get("permissions", []),
            raw_manifest=data,
        )

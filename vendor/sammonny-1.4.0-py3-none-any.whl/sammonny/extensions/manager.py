"""
Unified Browser Extension Manager for SamMonny Antidetect Suite.
"""

from __future__ import annotations
import json
import shutil
import hashlib
from pathlib import Path
from typing import List, Dict, Optional, Union, Set

from sammonny.extensions.models import ExtensionItem
from sammonny.extensions.downloader import ExtensionDownloader


class ExtensionManager:
    """Manages installation, unpacking, profile binding, and launch flags for extensions."""

    def __init__(self, storage_dir: Optional[Union[str, Path]] = None):
        self.storage_dir = Path(storage_dir or "data/extensions")
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self.db_file = self.storage_dir / "extensions.json"
        self._bindings: Dict[str, List[str]] = {}  # profile_id -> [ext_id, ...]
        self._load()

    def _load(self):
        if self.db_file.exists():
            try:
                with open(self.db_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self._bindings = data.get("bindings", {})
            except Exception:
                self._bindings = {}

    def _save(self):
        data = {
            "bindings": self._bindings,
        }
        with open(self.db_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def list_installed(self) -> List[ExtensionItem]:
        """Scans the extensions directory and returns all valid unpacked extensions."""
        items: List[ExtensionItem] = []
        if not self.storage_dir.exists():
            return items

        for sub in self.storage_dir.iterdir():
            if sub.is_dir() and (sub / "manifest.json").exists():
                try:
                    ext = ExtensionItem.from_manifest(ext_id=sub.name, ext_dir=sub)
                    items.append(ext)
                except Exception:
                    pass
        return items

    def get_extension(self, ext_id: str) -> Optional[ExtensionItem]:
        target = self.storage_dir / ext_id
        if target.exists() and (target / "manifest.json").exists():
            try:
                return ExtensionItem.from_manifest(ext_id=ext_id, ext_dir=target)
            except Exception:
                return None
        return None

    def install_from_webstore(self, ext_id: str) -> ExtensionItem:
        """Downloads extension from Chrome Web Store by ID and unpacks it."""
        dest_dir = self.storage_dir / ext_id
        if dest_dir.exists():
            shutil.rmtree(dest_dir, ignore_errors=True)

        crx_bytes = ExtensionDownloader.download_crx_bytes(ext_id)
        ExtensionDownloader.unpack_crx_or_zip(crx_bytes, dest_dir)
        return ExtensionItem.from_manifest(ext_id=ext_id, ext_dir=dest_dir)

    def install_from_file(self, file_path: Union[str, Path], ext_id: Optional[str] = None) -> ExtensionItem:
        """Installs and unpacks a local .crx or .zip file."""
        p = Path(file_path)
        if not p.exists():
            raise FileNotFoundError(f"Extension file not found: {p}")

        if not ext_id:
            # Generate deterministic hash from file stem
            hasher = hashlib.sha256()
            hasher.update(p.name.encode("utf-8"))
            ext_id = hasher.hexdigest()[:16]

        dest_dir = self.storage_dir / ext_id
        if dest_dir.exists():
            shutil.rmtree(dest_dir, ignore_errors=True)

        ExtensionDownloader.unpack_crx_or_zip(p, dest_dir)
        return ExtensionItem.from_manifest(ext_id=ext_id, ext_dir=dest_dir)

    def delete_extension(self, ext_id: str) -> bool:
        dest_dir = self.storage_dir / ext_id
        if dest_dir.exists():
            shutil.rmtree(dest_dir, ignore_errors=True)
            # Remove bindings
            for prof, bound in list(self._bindings.items()):
                if ext_id in bound:
                    bound.remove(ext_id)
            self._save()
            return True
        return False

    # =========================================================================
    # Profile Bindings
    # =========================================================================

    def bind_to_profile(self, profile_id: str, ext_id: str) -> None:
        if not self.get_extension(ext_id):
            raise ValueError(f"Extension '{ext_id}' is not installed.")

        bound_list = self._bindings.setdefault(profile_id, [])
        if ext_id not in bound_list:
            bound_list.append(ext_id)
            self._save()

    def unbind_from_profile(self, profile_id: str, ext_id: str) -> None:
        if profile_id in self._bindings and ext_id in self._bindings[profile_id]:
            self._bindings[profile_id].remove(ext_id)
            self._save()

    def list_profile_extensions(self, profile_id: str) -> List[ExtensionItem]:
        ext_ids = self._bindings.get(profile_id, [])
        result: List[ExtensionItem] = []
        for eid in ext_ids:
            ext = self.get_extension(eid)
            if ext:
                result.append(ext)
        return result

    def get_profile_launch_flags(self, profile_id: str) -> List[str]:
        """
        Generates standard Chromium CLI flags to load extensions for a profile:
        --load-extension=path1,path2
        --disable-extensions-except=path1,path2
        """
        exts = self.list_profile_extensions(profile_id)
        if not exts:
            return []

        paths_str = ",".join(str(e.path.resolve().as_posix()) for e in exts)
        return [
            f"--load-extension={paths_str}",
            f"--disable-extensions-except={paths_str}",
        ]

"""
Chrome Web Store Extension Downloader & CRX/ZIP Unpacker.
"""

from __future__ import annotations
import io
import re
import shutil
import zipfile
import urllib.request
from pathlib import Path
from typing import Optional, Union

WEBSTORE_CRX_URL_TEMPLATE = (
    "https://clients2.google.com/service/update2/crx?"
    "response=redirect&prodversion=124.0.0.0&acceptformat=crx2,crx3&x=id%3D{ext_id}%26uc"
)

# Zip archive header signature
ZIP_MAGIC = b"PK\x03\x04"


class ExtensionDownloader:
    """Downloads extensions from Chrome Web Store or unpacks local .crx / .zip files."""

    @staticmethod
    def download_crx_bytes(ext_id: str, timeout: float = 30.0) -> bytes:
        """Downloads raw CRX package from Google Chrome Web Store update service."""
        clean_id = ext_id.strip()
        if not re.match(r"^[a-z0-9]{32}$", clean_id, re.IGNORECASE):
            raise ValueError(f"Invalid Chrome Web Store Extension ID format: {clean_id}")

        url = WEBSTORE_CRX_URL_TEMPLATE.format(ext_id=clean_id)
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            },
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read()

    @staticmethod
    def unpack_crx_or_zip(file_or_bytes: Union[str, Path, bytes], dest_dir: Path) -> Path:
        """
        Extracts a .crx or .zip file into an unpacked directory.
        Strips CRX binary headers (CRX2/CRX3) to reveal the underlying standard PKZIP stream.
        """
        dest_dir.mkdir(parents=True, exist_ok=True)

        if isinstance(file_or_bytes, (str, Path)):
            with open(file_or_bytes, "rb") as f:
                raw_bytes = f.read()
        else:
            raw_bytes = file_or_bytes

        # Find the first PK\x03\x04 zip header
        zip_offset = raw_bytes.find(ZIP_MAGIC)
        if zip_offset == -1:
            raise ValueError("Corrupted extension file: Could not find standard ZIP header.")

        zip_stream = io.BytesIO(raw_bytes[zip_offset:])
        with zipfile.ZipFile(zip_stream) as z:
            z.extractall(dest_dir)

        return dest_dir

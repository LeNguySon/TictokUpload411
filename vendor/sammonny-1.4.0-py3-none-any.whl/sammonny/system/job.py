"""
Windows Job Object Supervision.
Uses Win32 Job Objects with JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE to guarantee
that child browser processes are automatically terminated by the Windows OS kernel
whenever the Python parent process exits or crashes.
"""

from __future__ import annotations
import sys
import ctypes
from typing import Optional


class WindowsJobSupervisor:
    """Assigns child processes to a kernel Job Object with kill-on-close policy."""

    def __init__(self):
        self.job_handle = None
        if sys.platform == "win32":
            self._create_job_object()

    def _create_job_object(self) -> None:
        kernel32 = ctypes.windll.kernel32

        # Create anonymous Job Object
        h_job = kernel32.CreateJobObjectW(None, None)
        if not h_job:
            return

        # JOBOBJECT_EXTENDED_LIMIT_INFORMATION structure definition
        class IO_COUNTERS(ctypes.Structure):
            _fields_ = [
                ("ReadOperationCount", ctypes.c_uint64),
                ("WriteOperationCount", ctypes.c_uint64),
                ("OtherOperationCount", ctypes.c_uint64),
                ("ReadTransferCount", ctypes.c_uint64),
                ("WriteTransferCount", ctypes.c_uint64),
                ("OtherTransferCount", ctypes.c_uint64),
            ]

        class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
            _fields_ = [
                ("PerProcessUserTimeLimit", ctypes.c_int64),
                ("PerJobUserTimeLimit", ctypes.c_int64),
                ("LimitFlags", ctypes.c_uint32),
                ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", ctypes.c_uint32),
                ("Affinity", ctypes.c_size_t),
                ("PriorityClass", ctypes.c_uint32),
                ("SchedulingClass", ctypes.c_uint32),
            ]

        class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
            _fields_ = [
                ("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
                ("IoInfo", IO_COUNTERS),
                ("ProcessMemoryLimit", ctypes.c_size_t),
                ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t),
                ("PeakJobMemoryUsed", ctypes.c_size_t),
            ]

        JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
        JobObjectExtendedLimitInformation = 9

        info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        info.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE

        success = kernel32.SetInformationJobObject(
            h_job,
            JobObjectExtendedLimitInformation,
            ctypes.byref(info),
            ctypes.sizeof(info),
        )

        if success:
            self.job_handle = h_job
        else:
            kernel32.CloseHandle(h_job)

    def assign_process(self, pid: int) -> bool:
        """Assigns target process to this supervised Job Object."""
        if not self.job_handle or sys.platform != "win32":
            return False

        PROCESS_SET_QUOTA = 0x0100
        PROCESS_TERMINATE = 0x0001
        kernel32 = ctypes.windll.kernel32

        h_process = kernel32.OpenProcess(
            PROCESS_SET_QUOTA | PROCESS_TERMINATE, False, pid
        )
        if not h_process:
            return False

        try:
            return bool(kernel32.AssignProcessToJobObject(self.job_handle, h_process))
        finally:
            kernel32.CloseHandle(h_process)

    def close(self) -> None:
        if self.job_handle and sys.platform == "win32":
            ctypes.windll.kernel32.CloseHandle(self.job_handle)
            self.job_handle = None

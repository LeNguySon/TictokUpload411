"""
Win32 In-Memory RAM Scanner for Chromium Processes.
Performs clean, non-intrusive memory scanning of renderer processes (chrome.exe / orbita.exe)
using Win32 ReadProcessMemory & VirtualQueryEx without touching the DOM or executing JavaScript.
"""

from __future__ import annotations
import sys
import os
import re
import json
import ctypes
from ctypes import wintypes
from typing import List, Dict, Any, Optional, Union, Generator, Tuple
from dataclasses import dataclass


# Win32 Memory Constants
MEM_COMMIT = 0x1000
MEM_RESERVE = 0x2000
MEM_FREE = 0x10000

PAGE_NOACCESS = 0x01
PAGE_READONLY = 0x02
PAGE_READWRITE = 0x04
PAGE_WRITECOPY = 0x08
PAGE_EXECUTE_READ = 0x20
PAGE_EXECUTE_READWRITE = 0x40
PAGE_GUARD = 0x100

PROCESS_VM_READ = 0x0010
PROCESS_QUERY_INFORMATION = 0x0400


class MEMORY_BASIC_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BaseAddress", ctypes.c_void_p),
        ("AllocationBase", ctypes.c_void_p),
        ("AllocationProtect", wintypes.DWORD),
        ("RegionSize", ctypes.c_size_t),
        ("State", wintypes.DWORD),
        ("Protect", wintypes.DWORD),
        ("Type", wintypes.DWORD),
    ]


@dataclass
class MemoryScanResult:
    pid: int
    address: int
    matched_text: str
    pattern: str
    context_snippet: str


class ProcessMemoryScanner:
    """
    Scans memory pages of running Chromium processes directly via Windows Kernel APIs.
    Zero-footprint: completely invisible to web page anti-bot scripts.
    """

    def __init__(self, pid: int):
        self.pid = pid
        self._is_win32 = sys.platform == "win32"
        self._kernel32 = ctypes.windll.kernel32 if self._is_win32 else None

    def is_available(self) -> bool:
        return self._is_win32 and self._kernel32 is not None

    def _open_process(self) -> Optional[int]:
        if not self.is_available():
            return None
        h_proc = self._kernel32.OpenProcess(
            PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, False, self.pid
        )
        return h_proc if h_proc else None

    def scan_memory_chunks(
        self,
        max_chunk_size: int = 4 * 1024 * 1024,  # 4 MB
    ) -> Generator[Tuple[int, bytes], None, None]:
        """
        Iterates over all committed, readable memory regions of the target process.
        Yields (base_address, raw_bytes).
        """
        h_proc = self._open_process()
        if not h_proc:
            return

        try:
            curr_addr = 0
            # 64-bit user-mode address limit (0x7FFFFFFF0000 on Windows x64)
            max_addr = 0x7FFFFFFF0000

            mbi = MEMORY_BASIC_INFORMATION()
            mbi_size = ctypes.sizeof(mbi)

            while curr_addr < max_addr:
                res = self._kernel32.VirtualQueryEx(
                    h_proc, ctypes.c_void_p(curr_addr), ctypes.byref(mbi), mbi_size
                )
                if res == 0:
                    break

                base = mbi.BaseAddress or 0
                region_size = mbi.RegionSize or 0

                # Only read committed, readable memory that is NOT a guard page
                is_committed = mbi.State == MEM_COMMIT
                is_readable = bool(
                    mbi.Protect & (PAGE_READONLY | PAGE_READWRITE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE)
                )
                is_guard = bool(mbi.Protect & PAGE_GUARD) or bool(mbi.Protect & PAGE_NOACCESS)

                if is_committed and is_readable and not is_guard and region_size > 0:
                    # Read region in manageable sub-chunks
                    offset = 0
                    while offset < region_size:
                        bytes_to_read = min(region_size - offset, max_chunk_size)
                        buf = (ctypes.c_char * bytes_to_read)()
                        bytes_read = ctypes.c_size_t(0)

                        success = self._kernel32.ReadProcessMemory(
                            h_proc,
                            ctypes.c_void_p(base + offset),
                            buf,
                            bytes_to_read,
                            ctypes.byref(bytes_read),
                        )

                        if success and bytes_read.value > 0:
                            yield (base + offset, buf.raw[: bytes_read.value])

                        offset += bytes_to_read

                curr_addr = base + region_size
        finally:
            self._kernel32.CloseHandle(h_proc)

    def search_regex(
        self,
        pattern: str,
        max_matches: int = 50,
        flags: int = re.IGNORECASE,
    ) -> List[MemoryScanResult]:
        """
        Scans entire process RAM for regex string occurrences (e.g. tokens, headers, JSON keys).
        """
        compiled = re.compile(pattern.encode("utf-8"), flags=flags)
        results: List[MemoryScanResult] = []

        for base_addr, raw_bytes in self.scan_memory_chunks():
            for match in compiled.finditer(raw_bytes):
                matched_bytes = match.group(0)
                start_idx = match.start()

                # Extract context snippet (+/- 40 bytes)
                c_start = max(0, start_idx - 40)
                c_end = min(len(raw_bytes), match.end() + 40)
                snippet = raw_bytes[c_start:c_end].decode("utf-8", errors="replace")

                results.append(
                    MemoryScanResult(
                        pid=self.pid,
                        address=base_addr + start_idx,
                        matched_text=matched_bytes.decode("utf-8", errors="replace"),
                        pattern=pattern,
                        context_snippet=snippet,
                    )
                )

                if len(results) >= max_matches:
                    return results

        return results

    def extract_json_structures(
        self,
        key_hints: Optional[List[str]] = None,
        min_length: int = 25,
        max_matches: int = 30,
    ) -> List[Dict[str, Any]]:
        """
        Searches committed heap memory for valid JSON objects matching optional key hints.
        Useful for extracting game room states, user credentials, or un-obfuscated responses.
        """
        hints = [h.encode("utf-8") for h in (key_hints or [])]
        json_results: List[Dict[str, Any]] = []
        seen_hashes = set()

        # Match JSON object candidates: { ... }
        json_candidate_regex = re.compile(rb'\{[^{}]{15,2000}\}')

        for _, raw_bytes in self.scan_memory_chunks():
            if hints:
                # Fast path: check if any hint exists in this 4MB chunk
                if not any(h in raw_bytes for h in hints):
                    continue

            for match in json_candidate_regex.finditer(raw_bytes):
                candidate_bytes = match.group(0)
                if hints and not any(h in candidate_bytes for h in hints):
                    continue

                try:
                    parsed = json.loads(candidate_bytes.decode("utf-8", errors="ignore"))
                    if isinstance(parsed, dict) and len(parsed) >= 1:
                        # Deduplicate identical payloads
                        h = hash(json.dumps(parsed, sort_keys=True))
                        if h not in seen_hashes:
                            seen_hashes.add(h)
                            json_results.append(parsed)
                            if len(json_results) >= max_matches:
                                return json_results
                except Exception:
                    continue

        return json_results


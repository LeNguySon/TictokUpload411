"""
Orphan Process Sweeper & Profile Lockfile Cleaner.
Detects abandoned or orphaned browser processes whose parent processes have died,
sweeps zombie chrome.exe/orbita.exe instances, and prunes stale LevelDB/Singleton locks.
"""

from __future__ import annotations
import os
import shutil
from pathlib import Path
from typing import List, Dict, Set, Optional, Tuple

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

SINGLETON_LOCK_NAMES = [
    "SingletonLock",
    "SingletonCookie",
    "SingletonSocket",
    "RunningChromeVersion",
    ".process.lock",
    "lockfile",
    "LOCK",
]

TARGET_PROCESS_NAMES = [
    "chrome.exe",
    "orbita.exe",
    "chromedriver.exe",
    "msedge.exe",
    "brave.exe",
]


class OrphanSweeper:
    """Detects and terminates orphaned Chromium processes and cleans filesystem locks."""

    @staticmethod
    def clean_stale_locks(profile_dir: Path) -> int:
        """
        Removes Singleton locks and LevelDB locks from profile directories
        caused by sudden crashes or ungraceful browser kills.
        """
        p_dir = Path(profile_dir)
        if not p_dir.exists():
            return 0

        cleaned_count = 0

        # 1. Root & Default directory singleton locks
        check_dirs = [p_dir, p_dir / "Default"]
        for d in check_dirs:
            if not d.exists():
                continue
            for lock_name in SINGLETON_LOCK_NAMES:
                lock_file = d / lock_name
                if lock_file.exists() and lock_file.is_file():
                    try:
                        lock_file.unlink()
                        cleaned_count += 1
                    except Exception:
                        pass

        # 2. Local Storage / Session Storage leveldb locks
        for storage_type in ["Local Storage", "Session Storage"]:
            leveldb_dir = p_dir / "Default" / storage_type / "leveldb"
            if leveldb_dir.exists():
                lock = leveldb_dir / "LOCK"
                if lock.exists():
                    try:
                        lock.unlink()
                        cleaned_count += 1
                    except Exception:
                        pass

        # 3. IndexedDB locks
        indexed_db = p_dir / "Default" / "IndexedDB"
        if indexed_db.exists():
            for nested in indexed_db.rglob("LOCK"):
                try:
                    nested.unlink()
                    cleaned_count += 1
                except Exception:
                    pass

        return cleaned_count

    @staticmethod
    def prune_profile_garbage(profile_dir: Path) -> Tuple[int, float]:
        """
        Prunes temporary Crashpad crash dumps, shader caches, and code caches.
        Returns (files_removed, freed_mb).
        """
        p_dir = Path(profile_dir)
        if not p_dir.exists():
            return (0, 0.0)

        garbage_dirs = [
            "Crashpad",
            "GPUCache",
            "ShaderCache",
            "GrShaderCache",
            "Code Cache",
            "optimization_guide_hint_cache_store",
        ]

        removed_count = 0
        total_freed_bytes = 0

        for g_name in garbage_dirs:
            for g_path in p_dir.rglob(g_name):
                if g_path.is_dir():
                    try:
                        for f in g_path.rglob("*"):
                            if f.is_file():
                                total_freed_bytes += f.stat().st_size
                                removed_count += 1
                        shutil.rmtree(g_path, ignore_errors=True)
                    except Exception:
                        pass

        freed_mb = round(total_freed_bytes / (1024 * 1024), 2)
        return (removed_count, freed_mb)

    @classmethod
    def sweep_orphaned_browsers(
        cls,
        known_active_pids: Optional[Set[int]] = None,
        force_terminate: bool = True,
    ) -> List[Dict[str, Any]]:
        """
        Scans all running processes in the OS.
        Terminates any Chromium/Orbita processes that:
        - Are not registered in known_active_pids.
        - Run with --user-data-dir or --remote-debugging-port.
        - Whose parent process has terminated (ppid is 1 or no longer exists).
        """
        if not HAS_PSUTIL:
            return []

        active_pids = known_active_pids or set()
        swept: List[Dict[str, Any]] = []

        current_my_pid = os.getpid()

        for proc in psutil.process_iter(["pid", "name", "ppid", "cmdline"]):
            try:
                pid = proc.info["pid"]
                name = (proc.info["name"] or "").lower()

                if pid == current_my_pid or pid in active_pids:
                    continue

                if name in TARGET_PROCESS_NAMES:
                    cmdline = " ".join(proc.info.get("cmdline") or [])
                    # Verify it's an automation/profile process
                    is_profile_browser = (
                        "--user-data-dir" in cmdline
                        or "--remote-debugging-port" in cmdline
                        or "orbita" in name
                    )

                    if is_profile_browser:
                        # Check if parent process is dead or root
                        ppid = proc.info.get("ppid", 0)
                        parent_alive = False
                        try:
                            parent_proc = psutil.Process(ppid)
                            parent_alive = parent_proc.is_running() and ppid > 4
                        except Exception:
                            parent_alive = False

                        # Determine if process is an orphan:
                        # 1. If known_active_pids specified, any non-listed profile browser is an orphan
                        # 2. If known_active_pids is None, strictly sweep when parent has died (not parent_alive)
                        is_orphan = (not parent_alive) if known_active_pids is None else (pid not in active_pids)

                        if is_orphan:
                            mem_mb = 0.0
                            try:
                                mem_mb = round(proc.memory_info().rss / (1024 * 1024), 2)
                            except Exception:
                                pass

                            record = {
                                "pid": pid,
                                "name": name,
                                "ppid": ppid,
                                "rss_mb": mem_mb,
                                "cmdline_preview": cmdline[:100],
                            }

                            if force_terminate:
                                try:
                                    proc.terminate()
                                    proc.wait(timeout=1.0)
                                except (psutil.TimeoutExpired, psutil.AccessDenied):
                                    try:
                                        proc.kill()
                                    except Exception:
                                        pass
                                record["status"] = "terminated"
                            else:
                                record["status"] = "detected"

                            swept.append(record)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return swept

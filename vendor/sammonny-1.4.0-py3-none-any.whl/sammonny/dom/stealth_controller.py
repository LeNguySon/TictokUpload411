"""
Stealth DOM Controller & Anti-Bot Honeypot Neutralizer.
Discovers and interacts with DOM elements while bypassing:
1. Honeypot elements (invisible inputs, 0x0 buttons, display:none traps).
2. MutationObserver telemetry listeners.
3. Prototype hook traps.
"""

from __future__ import annotations
import json
import time
from typing import Optional, Literal, Dict, Any, List
from sammonny.core.cdp import SyncCdpClient
from sammonny.core.models import Rect, Point
from sammonny.core.exceptions import DOMError
from sammonny.dom.mouse import HumanMouse


class HoneypotDetectedError(DOMError):
    """Raised when an element targeted for interaction is identified as an anti-bot trap."""
    pass


class StealthDOMController:
    """Non-intrusive DOM Controller with Honeypot Trap Detection."""

    def __init__(self, cdp_client: SyncCdpClient, mouse: Optional[HumanMouse] = None):
        self.cdp = cdp_client
        self.mouse = mouse or HumanMouse(cdp_client)

    def inspect_element_safety(self, selector: str) -> Optional[Dict[str, Any]]:
        """
        Evaluates element visibility, computed styles, and geometric boundaries
        to verify if the element is genuine or an anti-bot honeypot.
        """
        js = f"""
        (() => {{
            const el = document.querySelector({json.dumps(selector)});
            if (!el) return {{ exists: false }};

            const style = window.getComputedStyle(el);
            const r = el.getBoundingClientRect();

            // Detect Anti-Bot Honeypots:
            // 1. Zero dimensions or display none
            const isZeroSize = r.width <= 0 || r.height <= 0;
            const isDisplayNone = style.display === 'none';
            const isHidden = style.visibility === 'hidden';
            const isTransparent = parseFloat(style.opacity || '1') <= 0.01;
            const isNoPointer = style.pointerEvents === 'none';
            const isOffscreen = r.x < -100 || r.y < -100 || r.right < 0 || r.bottom < 0;

            const isHoneypot = isZeroSize || isDisplayNone || isHidden || isTransparent || isNoPointer || isOffscreen;

            return {{
                exists: true,
                is_honeypot: isHoneypot,
                rect: {{
                    x: r.x,
                    y: r.y,
                    width: r.width,
                    height: r.height
                }},
                reasons: {{
                    is_zero_size: isZeroSize,
                    is_display_none: isDisplayNone,
                    is_hidden: isHidden,
                    is_transparent: isTransparent,
                    is_no_pointer: isNoPointer,
                    is_offscreen: isOffscreen
                }}
            }};
        }})()
        """
        return self.cdp.evaluate(js)

    def get_safe_rect(self, selector: str, timeout: float = 10.0) -> Rect:
        """
        Waits for element to appear, validates that it is NOT a honeypot,
        and returns its bounding Rect.
        """
        start = time.time()
        while time.time() - start < timeout:
            info = self.inspect_element_safety(selector)
            if info and info.get("exists"):
                if info.get("is_honeypot"):
                    reasons = info.get("reasons", {})
                    raise HoneypotDetectedError(
                        f"Target element '{selector}' is flagged as an Anti-Bot Honeypot! Details: {reasons}"
                    )
                r_dict = info.get("rect", {})
                return Rect(
                    x=float(r_dict.get("x", 0)),
                    y=float(r_dict.get("y", 0)),
                    width=float(r_dict.get("width", 0)),
                    height=float(r_dict.get("height", 0)),
                )
            time.sleep(0.3)

        raise DOMError(f"Element '{selector}' was not found in DOM within {timeout:.1f}s.")

    def click(
        self,
        selector: str,
        style: Literal["minimum_jerk", "windmouse"] = "minimum_jerk",
        timeout: float = 10.0,
    ) -> Point:
        """
        1. Validates element safety (avoids honeypots).
        2. Samples click coordinates with 2D Gaussian dispersion.
        3. Moves mouse along human kinematic spline.
        4. Dispatches native click (event.isTrusted === true).
        """
        rect = self.get_safe_rect(selector, timeout=timeout)
        click_pt = rect.sample_human_point()
        self.mouse.click(click_pt.x, click_pt.y, style=style)
        return click_pt


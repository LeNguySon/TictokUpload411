"""
DOM Controller & High-Level In-DOM Interaction Agent.
Bridges DOM elements (selectors, xpath) with biometric mouse kinematics,
human keyboard typing dispatch, and element viewport positioning.
"""

from __future__ import annotations
import time
import random
import json
from typing import Optional, Literal
from sammonny.core.cdp import SyncCdpClient
from sammonny.core.models import Rect, Point
from sammonny.core.exceptions import DOMError
from sammonny.dom.mouse import HumanMouse


class DOMController:
    """High-Level DOM Automation with Human Biometrics."""

    def __init__(self, cdp_client: SyncCdpClient, mouse: Optional[HumanMouse] = None):
        self.cdp = cdp_client
        self.mouse = mouse or HumanMouse(cdp_client)

    def get_rect(self, selector: str) -> Optional[Rect]:
        """Calculates BoundingClientRect of selector."""
        return self.cdp.get_element_rect(selector)

    def wait_for_selector(self, selector: str, timeout: float = 10.0) -> Rect:
        """Polls until selector is visible in DOM and returns its Rect."""
        start = time.time()
        while time.time() - start < timeout:
            rect = self.get_rect(selector)
            if rect:
                return rect
            time.sleep(0.3)
        raise DOMError(f"Element '{selector}' not found in DOM within {timeout:.1f}s.")

    def click(
        self,
        selector: str,
        style: Literal["minimum_jerk", "windmouse"] = "minimum_jerk",
        timeout: float = 10.0,
    ) -> Point:
        """
        1. Finds element in DOM.
        2. Samples an authentic human click point using 2D Gaussian dispersion.
        3. Moves mouse along a Minimum Jerk or WindMouse trajectory.
        4. Dispatches native mouse click (event.isTrusted === true).
        """
        rect = self.wait_for_selector(selector, timeout=timeout)
        click_pt = rect.sample_human_point()
        self.mouse.click(click_pt.x, click_pt.y, style=style)
        return click_pt

    def type_text(
        self,
        selector: str,
        text: str,
        wpm: float = 85.0,
        click_first: bool = True,
        clear_first: bool = False,
    ) -> None:
        """
        Types text into selector with authentic human keystroke dynamics and rhythm.
        """
        if click_first:
            self.click(selector)
            time.sleep(random.uniform(0.1, 0.25))

        if clear_first:
            # Select all and delete
            self.cdp.send("Input.dispatchKeyEvent", {"type": "keyDown", "windowsVirtualKeyCode": 65, "modifiers": 2}) # Ctrl+A
            self.cdp.send("Input.dispatchKeyEvent", {"type": "keyDown", "windowsVirtualKeyCode": 8}) # Backspace
            time.sleep(0.05)

        # Average milliseconds per character based on Words Per Minute (5 chars/word)
        cpm = wpm * 5.0
        avg_char_delay = 60.0 / cpm

        for char in text:
            # Keystroke down
            self.cdp.send(
                "Input.dispatchKeyEvent",
                {
                    "type": "keyDown",
                    "text": char,
                    "unmodifiedText": char,
                },
            )

            # Natural key press dwell time (40 - 90ms)
            key_press_dwell = random.uniform(0.040, 0.085)
            time.sleep(key_press_dwell)

            # Keystroke up
            self.cdp.send(
                "Input.dispatchKeyEvent",
                {
                    "type": "keyUp",
                    "text": char,
                    "unmodifiedText": char,
                },
            )

            # Delay between letters with natural variation & extra pause for spaces
            delay = random.gauss(avg_char_delay, avg_char_delay * 0.3)
            if char in (" ", ".", ",", "!", "?"):
                delay += random.uniform(0.12, 0.30)
            time.sleep(max(0.02, delay))

    def get_text(self, selector: str) -> Optional[str]:
        """Retrieves innerText of element."""
        js = f"document.querySelector({json.dumps(selector)})?.innerText"
        return self.cdp.evaluate(js)

    def get_attribute(self, selector: str, attribute_name: str) -> Optional[str]:
        """Retrieves attribute value of element."""
        js = f"document.querySelector({json.dumps(selector)})?.getAttribute({json.dumps(attribute_name)})"
        return self.cdp.evaluate(js)

"""
Ghost Cursor & In-DOM Visual Tracer.
Injects a non-intrusive SVG cursor and click ripple into the web page
to provide live visual confirmation of biometric trajectories and click events.
"""

from __future__ import annotations
from typing import Optional
from sammonny.core.cdp import SyncCdpClient

GHOST_CURSOR_SCRIPT = """
(() => {
    if (window.__sammonny_ghost_cursor_installed) return;
    window.__sammonny_ghost_cursor_installed = true;

    // Create SVG cursor element
    const cursor = document.createElement("div");
    cursor.id = "sammonny-ghost-cursor";
    cursor.style.position = "fixed";
    cursor.style.top = "0px";
    cursor.style.left = "0px";
    cursor.style.width = "20px";
    cursor.style.height = "20px";
    cursor.style.pointerEvents = "none";
    cursor.style.zIndex = "2147483647";
    cursor.style.transition = "transform 0.04s ease-out";
    cursor.style.transform = "translate(100px, 100px)";

    cursor.innerHTML = `
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5.5 3.5L18.5 11.5L11.5 13.5L8.5 20.5L5.5 3.5Z" fill="#00E5FF" stroke="#002244" stroke-width="1.5" stroke-linejoin="round"/>
        </svg>
    `;
    document.documentElement.appendChild(cursor);

    // Track mouse moves
    window.addEventListener("mousemove", (e) => {
        cursor.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
    }, { capture: true, passive: true });

    // Click ripple animation
    window.addEventListener("mousedown", (e) => {
        const ripple = document.createElement("div");
        ripple.style.position = "fixed";
        ripple.style.left = `${e.clientX - 12}px`;
        ripple.style.top = `${e.clientY - 12}px`;
        ripple.style.width = "24px";
        ripple.style.height = "24px";
        ripple.style.borderRadius = "50%";
        ripple.style.border = "2px solid #FF0055";
        ripple.style.pointerEvents = "none";
        ripple.style.zIndex = "2147483646";
        ripple.style.animation = "sammonny-ripple 0.4s ease-out forwards";
        document.documentElement.appendChild(ripple);
        setTimeout(() => ripple.remove(), 400);
    }, { capture: true, passive: true });

    // Add ripple animation keyframes
    const style = document.createElement("style");
    style.textContent = `
        @keyframes sammonny-ripple {
            0% { transform: scale(0.6); opacity: 1; }
            100% { transform: scale(2.2); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
})();
"""


class GhostCursor:
    """Manages in-DOM visual cursor tracking for debugging and screencasts."""

    def __init__(self, cdp_client: SyncCdpClient):
        self.cdp = cdp_client
        self.script_id: Optional[str] = None

    def enable(self) -> None:
        """Injects visual cursor script on current page and all future frames."""
        # 1. Inject into currently loaded document
        try:
            self.cdp.evaluate(GHOST_CURSOR_SCRIPT)
        except Exception:
            pass

        # 2. Add to evaluate on new document for all upcoming navigations
        try:
            self.cdp.send(
                "Page.addScriptToEvaluateOnNewDocument",
                {"source": GHOST_CURSOR_SCRIPT},
            )
        except Exception:
            pass

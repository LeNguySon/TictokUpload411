"""
Human Biometric Mouse Kinematics Engine.
Implements:
1. WindMouse (Fluid-particle dynamics with gravity, turbulence & inertia)
2. Minimum Jerk Quintic Spline (Flash & Hogan 1985 motor control formula)
   with 10Hz physiological micro-tremor and Saccadic Overshoot micro-corrections.
"""

from __future__ import annotations
import math
import random
from dataclasses import dataclass
from typing import List, Tuple, Optional
from sammonny.core.models import Point


@dataclass
class WindMouseConfig:
    gravity: float = 9.0
    wind: float = 4.5
    min_wait_sec: float = 0.007
    max_wait_sec: float = 0.015
    max_step_px: float = 13.0
    target_area_px: float = 15.0


class WindMouseGenerator:
    """Simulates physical cursor drag with gravitational pull and wind perturbations."""

    @staticmethod
    def generate_path(
        start: Point, target: Point, config: Optional[WindMouseConfig] = None
    ) -> List[Tuple[Point, float]]:
        cfg = config or WindMouseConfig()
        path: List[Tuple[Point, float]] = []

        cur_x = start.x
        cur_y = start.y
        v_x = 0.0
        v_y = 0.0
        w_x = 0.0
        w_y = 0.0

        sqrt3 = math.sqrt(3.0)
        sqrt5 = math.sqrt(5.0)

        iterations = 0
        max_iterations = 1500

        while iterations < max_iterations:
            iterations += 1
            dist = math.hypot(target.x - cur_x, target.y - cur_y)
            if dist < 2.0:
                break

            wind_mag = min(cfg.wind, dist)
            if dist >= cfg.target_area_px:
                w_x = w_x / sqrt3 + (random.uniform(-1.0, 1.0) * wind_mag) / sqrt5
                w_y = w_y / sqrt3 + (random.uniform(-1.0, 1.0) * wind_mag) / sqrt5
            else:
                w_x /= sqrt3
                w_y /= sqrt3

            v_x += w_x + cfg.gravity * (target.x - cur_x) / dist
            v_y += w_y + cfg.gravity * (target.y - cur_y) / dist

            vel_mag = math.hypot(v_x, v_y)
            if vel_mag > cfg.max_step_px:
                scale = (cfg.max_step_px / 2.0 + random.uniform(0.0, cfg.max_step_px / 2.0)) / vel_mag
                v_x *= scale
                v_y *= scale

            cur_x += v_x
            cur_y += v_y

            step_delay = random.uniform(cfg.min_wait_sec, cfg.max_wait_sec)
            path.append((Point(cur_x, cur_y), step_delay))

        # Final terminal point
        path.append((target, random.uniform(0.015, 0.035)))
        return path


class MinimumJerkGenerator:
    """
    Simulates human motor control using the 5th-order Minimum Jerk polynomial (Flash & Hogan 1985).
    Incorporates:
    - Fitts's Law movement duration.
    - 10Hz physiological micro-tremor.
    - Saccadic Overshoot & micro-corrections for natural ballistic movements.
    """

    @staticmethod
    def generate_path(
        start: Point,
        target: Point,
        duration_ms: Optional[int] = None,
        steps: Optional[int] = None,
    ) -> List[Tuple[Point, float]]:
        dist = math.hypot(target.x - start.x, target.y - start.y)
        if dist < 1.0:
            return [(target, 0.01)]

        # 1. Fitts's Law duration calculation if not explicitly provided
        if duration_ms is None:
            base_dur = int(120.0 * math.log2(1.0 + dist / 75.0) + 110.0)
            duration_ms = max(180, min(800, base_dur)) + random.randint(0, 45)

        num_steps = steps or max(14, int(duration_ms / 12.0))

        # 2. Check for ballistic overshoot when distance is large (> 150px)
        has_overshoot = dist > 150.0 and random.random() < 0.85
        overshoot_dist = random.uniform(3.0, 7.5) if has_overshoot else 0.0

        dir_x = (target.x - start.x) / dist
        dir_y = (target.y - start.y) / dist

        temp_target = Point(
            x=target.x + dir_x * overshoot_dist,
            y=target.y + dir_y * overshoot_dist,
        )

        step_time_sec = (duration_ms / num_steps) / 1000.0
        path: List[Tuple[Point, float]] = []
        curr_time = 0.0

        # Phase 1: Quintic minimum jerk trajectory to temporary target
        for i in range(num_steps + 1):
            tau = i / num_steps  # Normalized time in [0, 1]

            # Flash & Hogan Quintic polynomial: s(tau) = 10*tau^3 - 15*tau^4 + 6*tau^5
            s = 10.0 * (tau**3) - 15.0 * (tau**4) + 6.0 * (tau**5)

            # 10Hz physiological tremor (angular velocity = 2 * pi * 10 rad/s = 62.83 rad/s)
            tremor = math.sin(curr_time * 62.83) * random.uniform(0.2, 0.55)
            perp_x = -dir_y * tremor
            perp_y = dir_x * tremor

            cx = start.x + (temp_target.x - start.x) * s + perp_x
            cy = start.y + (temp_target.y - start.y) * s + perp_y
            path.append((Point(cx, cy), step_time_sec))
            curr_time += step_time_sec

        # Phase 2: Corrective saccade pulling back to exact target point
        if has_overshoot:
            corrective_steps = random.randint(3, 5)
            last_pt = path[-1][0]
            for j in range(1, corrective_steps + 1):
                c_tau = j / corrective_steps
                c_s = 10.0 * (c_tau**3) - 15.0 * (c_tau**4) + 6.0 * (c_tau**5)
                cx = last_pt.x + (target.x - last_pt.x) * c_s
                cy = last_pt.y + (target.y - last_pt.y) * c_s
                path.append((Point(cx, cy), random.uniform(0.009, 0.016)))

        return path

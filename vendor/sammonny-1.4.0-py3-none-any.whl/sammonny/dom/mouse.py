"""
Human Biometric Mouse Controller.
Executes mouse movements and clicks through CDP Input.dispatchMouseEvent.
Guarantees event.isTrusted === true and evades behavioral anti-bot profiling.
"""

from __future__ import annotations
import time
import random
from typing import Optional, Literal
from sammonny.core.cdp import SyncCdpClient
from sammonny.core.models import Point
from sammonny.dom.kinematics import WindMouseGenerator, MinimumJerkGenerator, WindMouseConfig


class HumanMouse:
    """Dispatches humanized mouse kinematics to the browser via CDP."""

    def __init__(self, cdp_client: SyncCdpClient):
        self.cdp = cdp_client

    @property
    def position(self) -> Point:
        return self.cdp.last_mouse_pos

    def move(
        self,
        x: float,
        y: float,
        style: Literal["minimum_jerk", "windmouse"] = "minimum_jerk",
    ) -> None:
        """Moves cursor to (x, y) along a human biometric trajectory."""
        start = self.position
        target = Point(x, y)

        if style == "windmouse":
            path = WindMouseGenerator.generate_path(start, target)
        else:
            path = MinimumJerkGenerator.generate_path(start, target)

        for pt, delay in path:
            self.cdp.dispatch_mouse("mouseMoved", x=pt.x, y=pt.y)
            time.sleep(delay)

    def click(
        self,
        x: Optional[float] = None,
        y: Optional[float] = None,
        button: str = "left",
        style: Literal["minimum_jerk", "windmouse"] = "minimum_jerk",
    ) -> None:
        """
        Executes an authentic human click:
        1. Moves cursor to target.
        2. Dwells for visual confirmation (40 - 120ms).
        3. Presses mouse button down.
        4. Holds click for biological dwell time (65 - 115ms).
        5. Releases mouse button.
        """
        if x is not None and y is not None:
            self.move(x, y, style=style)

        curr = self.position

        # 1. Visual confirmation dwell (pre-click cognition)
        pre_click_dwell = random.uniform(0.040, 0.120)
        time.sleep(pre_click_dwell)

        # 2. Mouse Press
        self.cdp.dispatch_mouse("mousePressed", x=curr.x, y=curr.y, button=button, click_count=1)

        # 3. Hold dwell (tactile micro-switch actuation)
        hold_dwell = random.uniform(0.065, 0.115)
        time.sleep(hold_dwell)

        # 4. Mouse Release
        self.cdp.dispatch_mouse("mouseReleased", x=curr.x, y=curr.y, button=button, click_count=1)

    def double_click(
        self,
        x: Optional[float] = None,
        y: Optional[float] = None,
        button: str = "left",
    ) -> None:
        """Executes a realistic double-click with appropriate inter-click interval."""
        if x is not None and y is not None:
            self.move(x, y)

        self.click(button=button)
        time.sleep(random.uniform(0.08, 0.15))
        self.click(button=button)

    def scroll(self, delta_y: float, steps: int = 5) -> None:
        """Scrolls smoothly with chunked mouse wheel detents and natural deceleration."""
        chunk = delta_y / steps
        pos = self.position
        for _ in range(steps):
            jitter_chunk = chunk * random.uniform(0.85, 1.15)
            self.cdp.dispatch_mouse("mouseWheel", x=pos.x, y=pos.y, delta_x=0, delta_y=jitter_chunk)
            time.sleep(random.uniform(0.03, 0.08))

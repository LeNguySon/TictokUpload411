"""
Main Application Window for SamMonny Antidetect Suite Desktop Control Center.
Engineered with Enterprise standards, Realtime Telemetry, and Quick Filter Toolbar.
"""

from __future__ import annotations
import sys
import os
from pathlib import Path
from typing import Optional

try:
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QTabWidget, QStatusBar, QLabel, QWidget,
        QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QFrame
    )
    from PyQt5.QtCore import Qt, QTimer
    from PyQt5.QtGui import QIcon, QFont
except ImportError:
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QTabWidget, QStatusBar, QLabel, QWidget,
        QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QFrame
    )
    from PySide6.QtCore import Qt, QTimer
    from PySide6.QtGui import QIcon, QFont

from sammonny.engine.core import AntidetectEngine
from sammonny.gui.theme import DARK_THEME_QSS
from sammonny.gui.tabs.tab_profiles import ProfilesTab
from sammonny.gui.tabs.tab_proxy import ProxyTab
from sammonny.gui.tabs.tab_system import SystemTab
from sammonny.gui.tabs.tab_cookies import CookiesTab
from sammonny.gui.tabs.tab_fingerprint import FingerprintTab
from sammonny.gui.tabs.tab_extensions import ExtensionsTab
from sammonny.gui.tabs.tab_signatures import SignaturesTab


class MainWindow(QMainWindow):
    """Next-Gen Antidetect Suite Desktop Control Center."""

    def __init__(self, profiles_dir: Optional[Path] = None, proxies_file: Optional[Path] = None):
        super().__init__()
        self.setWindowTitle("SamMonny Antidetect Browser Suite — Control Center v2.0 Enterprise")
        self.resize(1200, 780)
        self.setMinimumSize(960, 600)

        # Setup Core Engine
        prof_dir = profiles_dir or Path(os.environ.get("SAMMONNY_PROFILES_DIR", "profiles"))
        proxy_path = proxies_file or Path("proxies.json")
        self.engine = AntidetectEngine(profiles_dir=prof_dir, proxy_storage=proxy_path)

        # Main Root Layout
        central_container = QWidget()
        main_layout = QVBoxLayout(central_container)
        main_layout.setContentsMargins(14, 12, 14, 12)
        main_layout.setSpacing(10)

        # --- Top Header Bar ---
        header_bar = self._create_header_bar()
        main_layout.addWidget(header_bar)

        # --- Central Tabs ---
        self.tabs = QTabWidget()
        self.tab_profiles = ProfilesTab(self.engine, self)
        self.tab_proxy = ProxyTab(self.engine.proxy_pool, self)
        self.tab_system = SystemTab(prof_dir, self)
        self.tab_cookies = CookiesTab(prof_dir, self)
        self.tab_fingerprint = FingerprintTab(self)
        self.tab_extensions = ExtensionsTab(prof_dir, self)
        self.tab_signatures = SignaturesTab(self.engine, self)

        self.tabs.addTab(self.tab_profiles, "🌐 Quản Lý Hồ Sơ")
        self.tabs.addTab(self.tab_proxy, "🛡️ Kho Proxy Pool")
        self.tabs.addTab(self.tab_system, "⚡ Dọn Dẹp RAM & System")
        self.tabs.addTab(self.tab_cookies, "🍪 Cookie Station")
        self.tabs.addTab(self.tab_fingerprint, "🧬 Fingerprint Studio")
        self.tabs.addTab(self.tab_extensions, "🧩 Tiện Ích Mở Rộng")
        self.tabs.addTab(self.tab_signatures, "🔐 Chữ Ký & Mạng Nhân")

        main_layout.addWidget(self.tabs, stretch=1)
        self.setCentralWidget(central_container)

        # --- Modern Status Bar ---
        self._setup_status_bar()

        # Apply Global Dark Theme
        self.setStyleSheet(DARK_THEME_QSS)

        # Telemetry Timer (every 5 seconds)
        self.telemetry_timer = QTimer(self)
        self.telemetry_timer.timeout.connect(self._refresh_telemetry)
        self.telemetry_timer.start(5000)

    def _create_header_bar(self) -> QWidget:
        """Create sleek top bar with Branding, Live Search, and Quick Actions."""
        header = QFrame()
        header.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #121624, stop:1 #171b2e);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 8px;
                padding: 6px 12px;
            }
        """)
        layout = QHBoxLayout(header)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(12)

        # Brand Title
        brand_lbl = QLabel("💎 SamMonny Antidetect")
        brand_lbl.setStyleSheet("font-size: 15px; font-weight: 800; color: #00f298; background: transparent;")
        layout.addWidget(brand_lbl)

        # Badge
        badge_lbl = QLabel("ENTERPRISE v2.0")
        badge_lbl.setStyleSheet("""
            font-size: 10px; font-weight: 700; color: #38bdf8;
            background: rgba(56, 189, 248, 0.15); border: 1px solid rgba(56, 189, 248, 0.4);
            border-radius: 4px; padding: 2px 6px;
        """)
        layout.addWidget(badge_lbl)

        layout.addSpacing(16)

        # Fast Filter / Search Input
        self.quick_search = QLineEdit()
        self.quick_search.setPlaceholderText("🔍 Lọc nhanh hồ sơ (Tên, Proxy, Tag)...")
        self.quick_search.setFixedWidth(320)
        self.quick_search.textChanged.connect(self._on_search_filter)
        layout.addWidget(self.quick_search)

        layout.addStretch(1)

        # Quick Actions
        btn_refresh = QPushButton("🔄 Tải Lại")
        btn_refresh.setObjectName("btn-secondary")
        btn_refresh.setFixedWidth(90)
        btn_refresh.clicked.connect(self._refresh_all)
        layout.addWidget(btn_refresh)

        btn_clean = QPushButton("✨ Deep Clean")
        btn_clean.setObjectName("btn-secondary")
        btn_clean.setFixedWidth(110)
        btn_clean.setToolTip("Thu hồi RAM và giải phóng tài nguyên trình duyệt")
        btn_clean.clicked.connect(self._quick_deep_clean)
        layout.addWidget(btn_clean)

        return header

    def _setup_status_bar(self):
        """Setup rich status bar with Realtime metrics."""
        self.status = QStatusBar()
        self.setStatusBar(self.status)

        self.lbl_status = QLabel("● Sẵn sàng")
        self.lbl_status.setStyleSheet("color: #00f298; font-weight: 600; padding-left: 6px;")

        self.lbl_profiles_stat = QLabel("Hồ sơ: 0 tổng | 0 chạy")
        self.lbl_profiles_stat.setStyleSheet("color: #94a3b8; padding: 0 10px;")

        self.lbl_ports = QLabel("🌐 Daemon: 7654 | SDK: 36912")
        self.lbl_ports.setStyleSheet("color: #38bdf8; padding: 0 10px;")

        self.status.addWidget(self.lbl_status)
        self.status.addPermanentWidget(self.lbl_profiles_stat)
        self.status.addPermanentWidget(self.lbl_ports)

    def _on_search_filter(self, query: str):
        """Dispatch search filter to active tab if supported."""
        query = query.strip().lower()
        if hasattr(self.tab_profiles, "apply_filter"):
            self.tab_profiles.apply_filter(query)

    def _refresh_telemetry(self):
        """Update active profile counts on status bar."""
        try:
            total = len(self.engine.profiles_dir.glob("*.json")) if self.engine.profiles_dir.exists() else 0
            running = len(self.engine._active_drivers)
            self.lbl_profiles_stat.setText(f"Hồ sơ: {total} tổng | {running} đang chạy")
        except Exception:
            pass

    def _refresh_all(self):
        """Refresh current tab view."""
        if hasattr(self.tab_profiles, "refresh_table"):
            self.tab_profiles.refresh_table()
        if hasattr(self.tab_proxy, "refresh_table"):
            self.tab_proxy.refresh_table()
        self._refresh_telemetry()
        self.status.showMessage("Đã đồng bộ hóa dữ liệu mới nhất.", 2500)

    def _quick_deep_clean(self):
        """Trigger deep RAM cleanup from system tab."""
        if hasattr(self.tab_system, "run_cleanup"):
            self.tab_system.run_cleanup()
            self.status.showMessage("Đã hoàn tất Deep Clean RAM & Zombie Process.", 3000)


def run_gui():
    """Entry point for Desktop GUI Control Center."""
    app = QApplication.instance() or QApplication(sys.argv)
    window = MainWindow()
    window.show()
    return app.exec_() if hasattr(app, "exec_") else app.exec()


if __name__ == "__main__":
    sys.exit(run_gui())

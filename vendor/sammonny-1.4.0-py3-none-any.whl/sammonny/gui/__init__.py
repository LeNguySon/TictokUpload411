"""
SamMonny Antidetect Suite Desktop GUI Package.
"""
from sammonny.gui.app import MainWindow, run_gui

__all__ = ["MainWindow", "run_gui"]

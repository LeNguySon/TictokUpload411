"""
Fingerprint Studio Tab for SamMonny Antidetect Suite.
"""

from __future__ import annotations
import json
from typing import Optional

try:
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
        QComboBox, QTableWidget, QTableWidgetItem, QHeaderView,
        QFileDialog, QMessageBox
    )
except ImportError:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
        QComboBox, QTableWidget, QTableWidgetItem, QHeaderView,
        QFileDialog, QMessageBox
    )

from sammonny.fingerprint.generator import FingerprintGenerator


class FingerprintTab(QWidget):
    """Bayesian Hardware Fingerprint Generator & Inspector."""

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.current_fp = None
        self._init_ui()
        self.generate_fp()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        toolbar = QHBoxLayout()
        toolbar.addWidget(QLabel("Target OS:"))
        self.combo_os = QComboBox()
        self.combo_os.addItems(["win", "mac", "lin"])
        toolbar.addWidget(self.combo_os)

        self.btn_gen = QPushButton("🎲 Generate New Fingerprint")
        self.btn_gen.setObjectName("btn-success")
        self.btn_gen.clicked.connect(self.generate_fp)
        toolbar.addWidget(self.btn_gen)

        self.btn_export = QPushButton("💾 Export Fingerprint JSON")
        self.btn_export.clicked.connect(self.export_fp)
        toolbar.addWidget(self.btn_export)
        toolbar.addStretch()

        layout.addLayout(toolbar)

        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Fingerprint Attribute", "Generated Hardware & Software Vector"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        layout.addWidget(self.table)

    def generate_fp(self):
        os_target = self.combo_os.currentText()
        fp = FingerprintGenerator.generate(target_os=os_target)
        self.current_fp = fp.to_gologin_dict()

        props = [
            ("Operating System", fp.os.upper()),
            ("User-Agent", fp.user_agent),
            ("Screen Resolution", f"{fp.screen_width}x{fp.screen_height} (DPR: {fp.device_pixel_ratio})"),
            ("Hardware Concurrency (Cores)", str(fp.hardware_concurrency)),
            ("Device Memory (RAM)", f"{fp.device_memory} GB"),
            ("WebGL Unmasked Vendor", fp.webgl_vendor),
            ("WebGL Unmasked Renderer", fp.webgl_renderer),
            ("Canvas Noise Variation", str(fp.canvas_noise)),
            ("AudioContext Noise Level", str(fp.audio_noise)),
            ("Timezone", fp.timezone),
            ("Languages", fp.language),
        ]

        self.table.setRowCount(len(props))
        for row, (k, v) in enumerate(props):
            self.table.setItem(row, 0, QTableWidgetItem(k))
            self.table.setItem(row, 1, QTableWidgetItem(str(v)))

    def export_fp(self):
        if not self.current_fp:
            return
        out_path, _ = QFileDialog.getSaveFileName(self, "Export Fingerprint JSON", "fingerprint.json", "JSON (*.json)")
        if out_path:
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(self.current_fp, f, indent=2)
            QMessageBox.information(self, "Exported", f"Fingerprint saved to {out_path}!")

"""
Offline Cookie Station Tab for SamMonny Antidetect Suite.
"""

from __future__ import annotations
import json
from pathlib import Path
from typing import Optional

try:
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
        QLineEdit, QTableWidget, QTableWidgetItem, QHeaderView,
        QFileDialog, QMessageBox, QComboBox
    )
except ImportError:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
        QLineEdit, QTableWidget, QTableWidgetItem, QHeaderView,
        QFileDialog, QMessageBox, QComboBox
    )

from sammonny.cookies.sqlite_manager import CookieSqliteManager
from sammonny.core.models import CookieItem


class CookiesTab(QWidget):
    """Direct Offline Cookie Extraction & Injection for Chromium Profiles."""

    def __init__(self, profiles_dir: Path, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.profiles_dir = profiles_dir
        self._init_ui()
        self.refresh_profile_list()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        # Profile selection
        sel_layout = QHBoxLayout()
        sel_layout.addWidget(QLabel("Select Profile:"))
        self.combo_profiles = QComboBox()
        self.combo_profiles.currentIndexChanged.connect(self.on_profile_selected)
        sel_layout.addWidget(self.combo_profiles, 1)

        self.btn_load = QPushButton("📂 Load Cookies")
        self.btn_load.clicked.connect(self.load_cookies)
        sel_layout.addWidget(self.btn_load)

        self.btn_export_json = QPushButton("💾 Export JSON")
        self.btn_export_json.clicked.connect(self.export_json)
        sel_layout.addWidget(self.btn_export_json)

        self.btn_export_netscape = QPushButton("📄 Export Netscape")
        self.btn_export_netscape.clicked.connect(self.export_netscape)
        sel_layout.addWidget(self.btn_export_netscape)

        self.btn_import = QPushButton("📥 Import JSON")
        self.btn_import.setObjectName("btn-success")
        self.btn_import.clicked.connect(self.import_json)
        sel_layout.addWidget(self.btn_import)

        layout.addLayout(sel_layout)

        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["Domain", "Name", "Value Preview", "Path", "Expires", "Secure"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

    def refresh_profile_list(self):
        self.combo_profiles.clear()
        if self.profiles_dir.exists():
            for p in self.profiles_dir.iterdir():
                if p.is_dir():
                    self.combo_profiles.addItem(p.name, str(p))

    def on_profile_selected(self):
        pass

    def _get_current_profile_dir(self) -> Optional[Path]:
        path_str = self.combo_profiles.currentData()
        if path_str:
            return Path(path_str)
        return None

    def load_cookies(self):
        p_dir = self._get_current_profile_dir()
        if not p_dir:
            return

        mgr = CookieSqliteManager(p_dir)
        if not mgr.exists():
            QMessageBox.information(self, "No Cookies", "SQLite Cookies file does not exist yet for this profile.")
            self.table.setRowCount(0)
            return

        try:
            cookies = mgr.export_cookies()
            self.table.setRowCount(len(cookies))
            for row, c in enumerate(cookies):
                self.table.setItem(row, 0, QTableWidgetItem(c.domain))
                self.table.setItem(row, 1, QTableWidgetItem(c.name))
                val_prev = (c.value[:30] + "...") if len(c.value) > 30 else c.value
                self.table.setItem(row, 2, QTableWidgetItem(val_prev))
                self.table.setItem(row, 3, QTableWidgetItem(c.path))
                exp_str = f"{c.expirationDate:.0f}" if c.expirationDate else "Session"
                self.table.setItem(row, 4, QTableWidgetItem(exp_str))
                self.table.setItem(row, 5, QTableWidgetItem("YES" if c.secure else "NO"))
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to read cookies: {e}")

    def export_json(self):
        p_dir = self._get_current_profile_dir()
        if not p_dir:
            return
        mgr = CookieSqliteManager(p_dir)
        cookies = mgr.export_cookies()
        if not cookies:
            QMessageBox.warning(self, "Warning", "No cookies to export.")
            return

        out_path, _ = QFileDialog.getSaveFileName(self, "Export Cookies JSON", f"{p_dir.name}_cookies.json", "JSON (*.json)")
        if out_path:
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump([c.to_dict() for c in cookies], f, indent=2)
            QMessageBox.information(self, "Exported", f"Successfully exported {len(cookies)} cookies to {out_path}!")

    def export_netscape(self):
        p_dir = self._get_current_profile_dir()
        if not p_dir:
            return
        mgr = CookieSqliteManager(p_dir)
        data = mgr.export_netscape()

        out_path, _ = QFileDialog.getSaveFileName(self, "Export Netscape Cookies", f"{p_dir.name}_cookies.txt", "Text (*.txt)")
        if out_path:
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(data)
            QMessageBox.information(self, "Exported", f"Successfully exported Netscape cookies to {out_path}!")

    def import_json(self):
        p_dir = self._get_current_profile_dir()
        if not p_dir:
            return

        in_path, _ = QFileDialog.getOpenFileName(self, "Import Cookies JSON", "", "JSON (*.json)")
        if in_path:
            try:
                with open(in_path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                cookies = [CookieItem.from_dict(c) for c in raw]
                mgr = CookieSqliteManager(p_dir)
                count = mgr.import_cookies(cookies)
                QMessageBox.information(self, "Success", f"Successfully injected {count} cookies into SQLite!")
                self.load_cookies()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to import cookies: {e}")

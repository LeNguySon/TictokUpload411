"""
sammonny.gui.tabs.tab_signatures
================================
Interactive Desktop GUI Console for Signatures, Kernel HTTP & WASM Inspection.
Provides visual one-click testing of:
1. ByteDance Cryptographic Signatures (X-Gorgon, X-Bogus, A-Bogus, msToken).
2. Direct In-Kernel HTTP Egress (Sending requests through Chromium BoringSSL).
3. WebAssembly Linear Memory Inspection & Hex Dump.
4. Sub-pixel Font Glyph Metrics Audit.
"""

from __future__ import annotations

import json
from typing import Optional

try:
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
        QTextEdit, QComboBox, QGroupBox, QSpinBox, QMessageBox, QSplitter
    )
    from PyQt5.QtCore import Qt, QThread, pyqtSignal
except ImportError:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
        QTextEdit, QComboBox, QGroupBox, QSpinBox, QMessageBox, QSplitter
    )
    from PySide6.QtCore import Qt, QThread, Signal as pyqtSignal

from sammonny.engine.core import AntidetectEngine


class SignaturesTab(QWidget):
    """Signatures, Kernel HTTP Egress, and WASM Memory Console Tab."""

    def __init__(self, engine: AntidetectEngine, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.engine = engine
        self._init_ui()

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        # Top Control Bar (Profile Selector & Region)
        top_group = QGroupBox("Cấu Hình Phiên & Hồ Sơ Mục Tiêu")
        top_layout = QHBoxLayout(top_group)

        top_layout.addWidget(QLabel("Hồ sơ:"))
        self.cb_profile = QComboBox()
        self.cb_profile.setMinimumWidth(220)
        self._reload_profiles()
        top_layout.addWidget(self.cb_profile)

        btn_reload = QPushButton("🔄")
        btn_reload.setMaximumWidth(40)
        btn_reload.clicked.connect(self._reload_profiles)
        top_layout.addWidget(btn_reload)

        top_layout.addWidget(QLabel("Khu vực IDC:"))
        self.cb_region = QComboBox()
        self.cb_region.addItems(["US (useast2a)", "SG (alisg - APAC)", "VN (alisg)", "GB (eucentral - EU)", "DE (eucentral)"])
        top_layout.addWidget(self.cb_region)

        top_layout.addStretch()
        layout.addWidget(top_group)

        # Central Splitter (Left: Controls, Right: Terminal Console Output)
        splitter = QSplitter(Qt.Horizontal)

        # Left Panel (Actions)
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(10)

        # Group 1: Signature Testing
        sig_group = QGroupBox("1. Ký Chữ Ký Mật Mã (TikTok / ByteDance)")
        sig_layout = QVBoxLayout(sig_group)

        sig_layout.addWidget(QLabel("URL Mục Tiêu:"))
        self.txt_url = QLineEdit("https://www.tiktok.com/api/item/list/?count=30")
        sig_layout.addWidget(self.txt_url)

        btn_box = QHBoxLayout()
        self.btn_sign_offline = QPushButton("⚡ Ký Offline (Zero-Browser)")
        self.btn_sign_offline.setStyleSheet("background: #00aa66; color: white; font-weight: bold;")
        self.btn_sign_offline.clicked.connect(self._on_sign_offline)
        btn_box.addWidget(self.btn_sign_offline)

        self.btn_device_ctx = QPushButton("🆔 Xem Device Context")
        self.btn_device_ctx.clicked.connect(self._on_show_device_context)
        btn_box.addWidget(self.btn_device_ctx)
        sig_layout.addLayout(btn_box)

        left_layout.addWidget(sig_group)

        # Group 2: In-Kernel HTTP Egress
        http_group = QGroupBox("2. Phát Gói Tin Qua Nhân Chromium (In-Kernel HTTP)")
        http_layout = QVBoxLayout(http_group)

        h_ctrl = QHBoxLayout()
        self.cb_method = QComboBox()
        self.cb_method.addItems(["POST", "GET", "PUT", "DELETE"])
        h_ctrl.addWidget(QLabel("Method:"))
        h_ctrl.addWidget(self.cb_method)

        self.btn_send_http = QPushButton("🚀 Gửi Qua Nhân Chromium")
        self.btn_send_http.setStyleSheet("background: #2563eb; color: white; font-weight: bold;")
        self.btn_send_http.clicked.connect(self._on_send_in_kernel_http)
        h_ctrl.addWidget(self.btn_send_http)
        http_layout.addLayout(h_ctrl)

        http_layout.addWidget(QLabel("JSON Payload (cho POST/PUT):"))
        self.txt_payload = QLineEdit('{"action": "ping", "client": "SamMonny-GUI"}')
        http_layout.addWidget(self.txt_payload)

        left_layout.addWidget(http_group)

        # Group 3: WASM & Font Auditing
        audit_group = QGroupBox("3. WebAssembly & Kiểm Định Font Glyph")
        audit_layout = QHBoxLayout(audit_group)

        self.btn_audit_fonts = QPushButton("🧬 Kiểm Định Font Glyph")
        self.btn_audit_fonts.clicked.connect(self._on_audit_fonts)
        audit_layout.addWidget(self.btn_audit_fonts)

        self.btn_wasm_inspect = QPushButton("🔬 Quét WASM Memory")
        self.btn_wasm_inspect.clicked.connect(self._on_inspect_wasm)
        audit_layout.addWidget(self.btn_wasm_inspect)

        left_layout.addWidget(audit_group)
        left_layout.addStretch()
        splitter.addWidget(left_widget)

        # Right Panel (Results Console)
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)

        right_layout.addWidget(QLabel("Kết Quả Đo Đạc & Phản Hồi Từ Nhân Trình Duyệt:"))
        self.txt_console = QTextEdit()
        self.txt_console.setReadOnly(True)
        self.txt_console.setStyleSheet("""
            QTextEdit {
                background-color: #0b0f19;
                color: #38bdf8;
                font-family: 'Consolas', 'Courier New', monospace;
                font-size: 13px;
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 6px;
                padding: 8px;
            }
        """)
        right_layout.addWidget(self.txt_console)
        splitter.addWidget(right_widget)

        splitter.setStretchFactor(0, 4)
        splitter.setStretchFactor(1, 6)
        layout.addWidget(splitter, stretch=1)

    def _reload_profiles(self) -> None:
        self.cb_profile.clear()
        try:
            profs = self.engine.list_profiles()
            for p in profs:
                self.cb_profile.addItem(f"{p.id} ({p.name})", p.id)
        except Exception:
            self.cb_profile.addItem("default (Mặc định)", "default")

    def _get_current_profile_id(self) -> str:
        data = self.cb_profile.currentData()
        return str(data) if data else "default"

    def _get_current_region(self) -> str:
        txt = self.cb_region.currentText()
        return txt.split(" ")[0].upper()

    def _log(self, text: str) -> None:
        self.txt_console.append(text)

    # --- Actions ---

    def _on_sign_offline(self) -> None:
        pid = self._get_current_profile_id()
        region = self._get_current_region()
        url = self.txt_url.text().strip()

        self._log(f"\n[⚡ KÝ OFFLINE (ZERO-BROWSER)] Profile: {pid} | Region: {region}")
        try:
            signer = self.engine.get_signer(pid, region=region)
            env = signer.sign_request(url, method="POST", body={"scene": "test"})
            self._log(f"Status: OK (Độ trễ: <0.05 ms, 0 MB RAM)")
            self._log(f"IDC Affinity: {env['idc']} ({env['region']})")
            self._log(f"X-Gorgon: {env['headers']['X-Gorgon']}")
            self._log(f"X-Bogus:  {env['headers']['X-Bogus']}")
            self._log(f"a_bogus:  {env['headers']['X-ABogus']}")
            self._log(f"msToken:  {env['headers']['Cookie']}")
            self._log(f"\nSigned URL:\n{env['url']}")
        except Exception as e:
            self._log(f"[ERROR] Ký thất bại: {e}")

    def _on_show_device_context(self) -> None:
        pid = self._get_current_profile_id()
        region = self._get_current_region()
        try:
            signer = self.engine.get_signer(pid, region=region)
            ctx = signer.device_context
            self._log(f"\n[🆔 THÔNG SỐ ĐỊNH DANH PHẦN CỨNG - PROFILE {pid}]")
            self._log(f"Device ID:  {ctx.device_id}")
            self._log(f"Install ID: {ctx.install_id}")
            self._log(f"Web ID:     {ctx.webid}")
            self._log(f"OpenUDID:   {ctx.openudid}")
            self._log(f"Verify FP:  {ctx.verify_fp}")
            self._log(f"msToken:    {ctx.ms_token[:40]}...")
            self._log(f"Telemetry:  {json.dumps(ctx.telemetry, indent=2)}")
        except Exception as e:
            self._log(f"[ERROR] Trích xuất thất bại: {e}")

    def _on_send_in_kernel_http(self) -> None:
        pid = self._get_current_profile_id()
        method = self.cb_method.currentText()
        url = self.txt_url.text().strip()
        payload_str = self.txt_payload.text().strip()

        parsed_json = None
        if payload_str:
            try:
                parsed_json = json.loads(payload_str)
            except Exception:
                parsed_json = payload_str

        self._log(f"\n[🚀 GỬI REQUEST QUA NHÂN CHROMIUM] Profile: {pid} | Method: {method}")
        self._log(f"Đang bắt tay TLS 1.3 BoringSSL & tạo khung HTTP/2 qua Chromium...")

        try:
            resp = self.engine.http_request(
                profile_id=pid,
                method=method,
                url=url,
                json=parsed_json,
                headless=True,
            )
            color = "OK (200)" if resp.ok else f"Status: {resp.status_code}"
            self._log(f"Kết quả phản hồi: {color}")
            self._log(f"Độ trễ mạng: {resp.elapsed_ms:.2f} ms")
            self._log(f"Engine: {resp.engine}")
            self._log(f"Nội dung phản hồi:\n{resp.text[:500]}")
        except Exception as e:
            self._log(f"[ERROR] Gửi request thất bại: {e}")

    def _on_audit_fonts(self) -> None:
        pid = self._get_current_profile_id()
        self._log(f"\n[🧬 KIỂM ĐỊNH FONT GLYPH METRICS] Profile: {pid}")
        try:
            with self.engine.session(pid, headless=True) as sess:
                audit = sess.fonts.audit_os_parity("win")
                self._log(f"Kiểm toán OS Parity (win): {'ĐẠT (PASS)' if audit['passed'] else 'CẢNH BÁO'}")
                for note in audit.get("notes", []):
                    self._log(f"• {note}")
                sample = audit.get("sample_arial", {})
                self._log(f"Mẫu Arial (72px): Width={sample.get('width')}px, Ascent={sample.get('ascent')}px")
        except Exception as e:
            self._log(f"[ERROR] Kiểm định thất bại: {e}")

    def _on_inspect_wasm(self) -> None:
        pid = self._get_current_profile_id()
        self._log(f"\n[🔬 QUÉT BỘ NHỚ WEBASSEMBLY] Profile: {pid}")
        try:
            with self.engine.session(pid, headless=True) as sess:
                sess.wasm.install_hooks()
                mems = sess.wasm.list_memories()
                self._log(f"Số vùng nhớ WebAssembly.Memory phát hiện: {len(mems)}")
                for m in mems:
                    self._log(f"• Memory #{m.index}: {m.byte_length} bytes ({m.pages} pages x 64KB)")
                    hex_dump = sess.wasm.dump_hex(m.index, offset=0, length=64)
                    self._log(f"Hex Dump (64 bytes đầu):\n{hex_dump}")
        except Exception as e:
            self._log(f"[ERROR] Quét WASM thất bại: {e}")

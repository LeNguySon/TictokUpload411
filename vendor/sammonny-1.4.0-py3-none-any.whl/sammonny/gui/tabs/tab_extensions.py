"""
Extensions Management Tab for SamMonny Desktop Control Center.
"""

from __future__ import annotations
import threading
from pathlib import Path
from typing import Optional

try:
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
        QTableWidgetItem, QHeaderView, QMessageBox, QInputDialog, QLabel,
        QFileDialog, QComboBox
    )
except ImportError:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
        QTableWidgetItem, QHeaderView, QMessageBox, QInputDialog, QLabel,
        QFileDialog, QComboBox
    )

from sammonny.extensions.manager import ExtensionManager


class ExtensionsTab(QWidget):
    """Manages browser extensions (.crx, .zip, Chrome Web Store) and profile bindings."""

    def __init__(self, profiles_dir: Path, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.profiles_dir = profiles_dir
        self.mgr = ExtensionManager()
        self._init_ui()
        self.refresh_table()
        self.refresh_profiles()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        # 1. Main Toolbar
        toolbar = QHBoxLayout()
        self.btn_install_store = QPushButton("🌐 Install from Chrome Store")
        self.btn_install_store.setObjectName("btn-success")
        self.btn_install_store.clicked.connect(self.on_install_store)

        self.btn_install_file = QPushButton("📂 Install from .CRX / .ZIP")
        self.btn_install_file.clicked.connect(self.on_install_file)

        self.btn_delete = QPushButton("🗑 Delete Extension")
        self.btn_delete.setObjectName("btn-danger")
        self.btn_delete.clicked.connect(self.on_delete)

        toolbar.addWidget(self.btn_install_store)
        toolbar.addWidget(self.btn_install_file)
        toolbar.addWidget(self.btn_delete)
        toolbar.addStretch()

        layout.addLayout(toolbar)

        # 2. Extensions Table
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Name", "Extension ID", "Version", "Manifest", "Unpacked Path"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        layout.addWidget(self.table)

        # 3. Profile Binding Sub-bar
        bind_bar = QHBoxLayout()
        bind_bar.addWidget(QLabel("Bind to Profile:"))
        self.combo_profiles = QComboBox()
        bind_bar.addWidget(self.combo_profiles, 1)

        self.btn_bind = QPushButton("🔗 Bind to Profile")
        self.btn_bind.clicked.connect(self.on_bind)
        bind_bar.addWidget(self.btn_bind)

        self.btn_unbind = QPushButton("✂️ Unbind from Profile")
        self.btn_unbind.clicked.connect(self.on_unbind)
        bind_bar.addWidget(self.btn_unbind)

        layout.addLayout(bind_bar)

    def refresh_profiles(self):
        self.combo_profiles.clear()
        if self.profiles_dir.exists():
            for p in self.profiles_dir.iterdir():
                if p.is_dir():
                    self.combo_profiles.addItem(p.name, p.name)

    def refresh_table(self):
        exts = self.mgr.list_installed()
        self.table.setRowCount(len(exts))
        for row, e in enumerate(exts):
            self.table.setItem(row, 0, QTableWidgetItem(e.name))
            self.table.setItem(row, 1, QTableWidgetItem(e.id))
            self.table.setItem(row, 2, QTableWidgetItem(e.version))
            self.table.setItem(row, 3, QTableWidgetItem(f"MV{e.manifest_version}"))
            self.table.setItem(row, 4, QTableWidgetItem(str(e.path)))

    def _get_selected_ext_id(self) -> Optional[str]:
        selected = self.table.selectedItems()
        if not selected:
            return None
        row = selected[0].row()
        return self.table.item(row, 1).text()

    def on_install_store(self):
        ext_id, ok = QInputDialog.getText(
            self, "Install from Chrome Web Store",
            "Enter 32-character Chrome Web Store Extension ID:\n(e.g., nkbihfbeogaeaoehlefnkodbefgpgknn for MetaMask)"
        )
        if ok and ext_id.strip():
            clean_id = ext_id.strip()
            try:
                ext = self.mgr.install_from_webstore(clean_id)
                QMessageBox.information(
                    self, "Installed",
                    f"Extension '{ext.name}' (v{ext.version}) successfully installed and unpacked!"
                )
                self.refresh_table()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to download or unpack extension: {e}")

    def on_install_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Extension Archive", "", "Extension Archive (*.crx *.zip)"
        )
        if file_path:
            try:
                ext = self.mgr.install_from_file(file_path)
                QMessageBox.information(
                    self, "Installed",
                    f"Extension '{ext.name}' (v{ext.version}) successfully installed and unpacked!"
                )
                self.refresh_table()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to install extension: {e}")

    def on_delete(self):
        ext_id = self._get_selected_ext_id()
        if not ext_id:
            QMessageBox.warning(self, "Warning", "Please select an extension to delete.")
            return

        confirm = QMessageBox.question(
            self, "Confirm Delete", f"Are you sure you want to delete extension '{ext_id}'?",
            QMessageBox.Yes | QMessageBox.No
        )
        if confirm == QMessageBox.Yes:
            self.mgr.delete_extension(ext_id)
            self.refresh_table()

    def on_bind(self):
        ext_id = self._get_selected_ext_id()
        if not ext_id:
            QMessageBox.warning(self, "Warning", "Please select an extension to bind.")
            return

        prof_id = self.combo_profiles.currentData()
        if not prof_id:
            QMessageBox.warning(self, "Warning", "Please select a target profile.")
            return

        self.mgr.bind_to_profile(prof_id, ext_id)
        QMessageBox.information(
            self, "Bound", f"Extension '{ext_id}' bound to profile '{prof_id}'! It will load on next launch."
        )

    def on_unbind(self):
        ext_id = self._get_selected_ext_id()
        prof_id = self.combo_profiles.currentData()
        if ext_id and prof_id:
            self.mgr.unbind_from_profile(prof_id, ext_id)
            QMessageBox.information(self, "Unbound", f"Extension '{ext_id}' unbound from profile '{prof_id}'.")

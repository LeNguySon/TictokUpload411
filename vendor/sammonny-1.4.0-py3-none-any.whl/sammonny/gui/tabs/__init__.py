"""
Tabs package for Desktop GUI.
"""

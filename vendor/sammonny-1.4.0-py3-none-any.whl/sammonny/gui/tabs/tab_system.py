"""
System Health, RAM Optimization & Orphan Sweeper Tab for SamMonny Antidetect Suite.
"""

from __future__ import annotations
import os
from pathlib import Path
from typing import Optional

try:
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
        QGroupBox, QProgressBar, QMessageBox, QTextEdit
    )
    from PyQt5.QtCore import QTimer
except ImportError:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
        QGroupBox, QProgressBar, QMessageBox, QTextEdit
    )
    from PySide6.QtCore import QTimer

from sammonny.system.memory import MemoryManager
from sammonny.system.orphan_sweeper import OrphanSweeper


class SystemTab(QWidget):
    """Monitors system physical RAM and provides 1-click optimization tools."""

    def __init__(self, profiles_dir: Path, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.profiles_dir = profiles_dir
        self._init_ui()

        # Update RAM every 3 seconds
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_memory_status)
        self.timer.start(3000)
        self.update_memory_status()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        # 1. Host Memory Section
        mem_group = QGroupBox("Host Physical Memory Status")
        mem_layout = QVBoxLayout(mem_group)

        self.lbl_mem_info = QLabel("Loading memory stats...")
        self.lbl_mem_info.setStyleSheet("font-size: 14px; font-weight: 500;")
        mem_layout.addWidget(self.lbl_mem_info)

        self.ram_bar = QProgressBar()
        self.ram_bar.setRange(0, 100)
        mem_layout.addWidget(self.ram_bar)

        layout.addWidget(mem_group)

        # 2. Action Controls Section
        act_group = QGroupBox("Maintenance & Optimization Tools")
        act_layout = QHBoxLayout(act_group)

        self.btn_trim = QPushButton("🧹 Trim Working Set RAM")
        self.btn_trim.setObjectName("btn-success")
        self.btn_trim.clicked.connect(self.on_trim_ram)

        self.btn_sweep = QPushButton("🧟 Sweep Zombie Browsers")
        self.btn_sweep.setObjectName("btn-danger")
        self.btn_sweep.clicked.connect(self.on_sweep_orphans)

        self.btn_clean_locks = QPushButton("🔓 Clean Profile Stale Locks")
        self.btn_clean_locks.clicked.connect(self.on_clean_locks)

        act_layout.addWidget(self.btn_trim)
        act_layout.addWidget(self.btn_sweep)
        act_layout.addWidget(self.btn_clean_locks)

        layout.addWidget(act_group)

        # 3. Log Console Section
        log_group = QGroupBox("System Action Log")
        log_layout = QVBoxLayout(log_group)
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        log_layout.addWidget(self.txt_log)
        layout.addWidget(log_group)

    def log(self, message: str):
        self.txt_log.append(f"• {message}")

    def update_memory_status(self):
        st = MemoryManager.get_host_memory()
        self.lbl_mem_info.setText(
            f"RAM Usage: {st.used_mb:,.1f} MB / {st.total_mb:,.1f} MB ({st.percent:.1f}%) | "
            f"Available: {st.available_mb:,.1f} MB | "
            f"Status: {'⚠️ PRESSURE' if st.is_under_pressure else '✅ NORMAL'}"
        )
        self.ram_bar.setValue(int(st.percent))

    def on_trim_ram(self):
        # Trim current process and background threads
        pid = os.getpid()
        res = MemoryManager.trim_process_tree_memory(pid)
        self.log(f"Working set trimmed for PID {pid}. Freed {res.freed_mb} MB ({res.reduction_percent}% reduction).")
        self.update_memory_status()
        QMessageBox.information(
            self, "RAM Trimmed",
            f"Successfully flushed unused physical pages!\nFreed: {res.freed_mb} MB\nBefore: {res.rss_before_mb} MB -> After: {res.rss_after_mb} MB"
        )

    def on_sweep_orphans(self):
        swept = OrphanSweeper.sweep_orphaned_browsers(known_active_pids=None, force_terminate=True)
        if swept:
            self.log(f"Terminated {len(swept)} abandoned/orphaned browser processes.")
            for proc in swept:
                self.log(f"   - PID {proc['pid']} ({proc['name']}) [PPID {proc['ppid']}] freed {proc['rss_mb']} MB")
            QMessageBox.information(self, "Sweep Complete", f"Successfully swept and killed {len(swept)} zombie processes.")
        else:
            self.log("Scan complete: No orphaned browser processes detected.")
            QMessageBox.information(self, "Clean", "System is clean! No orphaned browser processes found.")
        self.update_memory_status()

    def on_clean_locks(self):
        if not self.profiles_dir.exists():
            QMessageBox.warning(self, "Warning", f"Profiles directory does not exist: {self.profiles_dir}")
            return

        total_cleaned = 0
        for p_sub in self.profiles_dir.iterdir():
            if p_sub.is_dir():
                total_cleaned += OrphanSweeper.clean_stale_locks(p_sub)

        self.log(f"Cleaned {total_cleaned} stale Singleton/LevelDB lock files across profiles directory.")
        QMessageBox.information(self, "Locks Cleaned", f"Successfully removed {total_cleaned} stale lock files.")

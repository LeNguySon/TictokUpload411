"""
Proxy Pool Management Tab for SamMonny Antidetect Suite.
"""

from __future__ import annotations
import threading
from typing import Optional

try:
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
        QTableWidgetItem, QHeaderView, QMessageBox, QInputDialog, QLabel
    )
    from PyQt5.QtCore import Qt, pyqtSignal, QObject
except ImportError:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
        QTableWidgetItem, QHeaderView, QMessageBox, QInputDialog, QLabel
    )
    from PySide6.QtCore import Qt, Signal as pyqtSignal, QObject

from sammonny.proxy.pool import ProxyPool
from sammonny.proxy.checker import check_proxy_health, trigger_ip_rotation


class ProxyTabSignals(QObject):
    tests_finished = pyqtSignal(dict)
    proxy_tested = pyqtSignal(str, object)


class ProxyTab(QWidget):
    """Manages Proxy Pool, Latency Diagnostics, and IP Rotation."""

    def __init__(self, proxy_pool: ProxyPool, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.pool = proxy_pool
        self.signals = ProxyTabSignals()
        self.signals.tests_finished.connect(self._on_tests_finished)
        self.signals.proxy_tested.connect(self._on_single_tested)
        self._init_ui()
        self.refresh_table()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        toolbar = QHBoxLayout()
        self.btn_add = QPushButton("➕ Add Proxy")
        self.btn_add.setObjectName("btn-success")
        self.btn_add.clicked.connect(self.on_add_proxy)

        self.btn_test_all = QPushButton("⚡ Test All Proxies")
        self.btn_test_all.clicked.connect(self.on_test_all)

        self.btn_rotate = QPushButton("🔄 Rotate IP")
        self.btn_rotate.clicked.connect(self.on_rotate_ip)

        self.btn_remove = QPushButton("🗑 Remove")
        self.btn_remove.setObjectName("btn-danger")
        self.btn_remove.clicked.connect(self.on_remove_proxy)

        toolbar.addWidget(self.btn_add)
        toolbar.addWidget(self.btn_test_all)
        toolbar.addWidget(self.btn_rotate)
        toolbar.addWidget(self.btn_remove)
        toolbar.addStretch()

        layout.addLayout(toolbar)

        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels([
            "ID", "Protocol", "Host:Port", "Status", "Latency", "Country", "Egress IP"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        layout.addWidget(self.table)

    def refresh_table(self):
        proxies = self.pool.get_all(alive_only=False)
        self.table.setRowCount(len(proxies))
        for row, p in enumerate(proxies):
            self.table.setItem(row, 0, QTableWidgetItem(p.id))
            self.table.setItem(row, 1, QTableWidgetItem(p.mode.upper()))
            self.table.setItem(row, 2, QTableWidgetItem(f"{p.host}:{p.port}"))
            status_text = "🟢 ALIVE" if p.is_alive else "🔴 DEAD"
            self.table.setItem(row, 3, QTableWidgetItem(status_text))
            self.table.setItem(row, 4, QTableWidgetItem("---"))
            self.table.setItem(row, 5, QTableWidgetItem(p.country or "---"))
            self.table.setItem(row, 6, QTableWidgetItem("---"))

    def _get_selected_proxy_id(self) -> Optional[str]:
        selected = self.table.selectedItems()
        if not selected:
            return None
        row = selected[0].row()
        return self.table.item(row, 0).text()

    def on_add_proxy(self):
        text, ok = QInputDialog.getMultiLineText(
            self, "Add Proxies",
            "Enter one or more proxies (format: socks5://user:pass@host:port or host:port:user:pass):"
        )
        if ok and text.strip():
            count = self.pool.add_bulk(text.strip())
            QMessageBox.information(self, "Success", f"Added {count} proxies to pool.")
            self.refresh_table()

    def on_test_all(self):
        self.btn_test_all.setEnabled(False)
        self.btn_test_all.setText("Testing...")

        def _bg_test():
            results = self.pool.test_all()
            self.signals.tests_finished.emit(results)

        threading.Thread(target=_bg_test, daemon=True).start()

    def _on_tests_finished(self, results: dict):
        self.btn_test_all.setEnabled(True)
        self.btn_test_all.setText("⚡ Test All Proxies")
        self.refresh_table()
        # Populate results
        for row in range(self.table.rowCount()):
            pid = self.table.item(row, 0).text()
            if pid in results:
                res = results[pid]
                status_text = "🟢 ALIVE" if res.is_alive else "🔴 DEAD"
                self.table.setItem(row, 3, QTableWidgetItem(status_text))
                self.table.setItem(row, 4, QTableWidgetItem(f"{res.latency_ms:.0f} ms" if res.is_alive else "Timeout"))
                self.table.setItem(row, 5, QTableWidgetItem(res.country or "---"))
                self.table.setItem(row, 6, QTableWidgetItem(res.egress_ip or "---"))

    def _on_single_tested(self, pid: str, res: object):
        pass

    def on_rotate_ip(self):
        pid = self._get_selected_proxy_id()
        if not pid:
            QMessageBox.warning(self, "Warning", "Select a proxy to rotate.")
            return

        proxy = self.pool.get(pid)
        if not proxy or not proxy.change_ip_url:
            QMessageBox.information(self, "Info", "This proxy has no configured Change IP URL.")
            return

        res = trigger_ip_rotation(proxy)
        if res.get("success"):
            QMessageBox.information(self, "Success", f"IP Rotated successfully!\nResponse: {res.get('response')}")
        else:
            QMessageBox.critical(self, "Failed", f"Rotation failed: {res.get('error')}")

    def on_remove_proxy(self):
        pid = self._get_selected_proxy_id()
        if not pid:
            return
        if self.pool.remove(pid):
            self.refresh_table()

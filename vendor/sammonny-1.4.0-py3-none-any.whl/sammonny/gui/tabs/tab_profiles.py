"""
Profiles Management Tab for SamMonny Antidetect Suite.
Engineered with High-Contrast Status Badges, Instant Search Filter, and Micro-interactions.
"""

from __future__ import annotations
import threading
from typing import Optional, List

try:
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
        QTableWidgetItem, QHeaderView, QMessageBox, QInputDialog, QLabel
    )
    from PyQt5.QtCore import Qt, pyqtSignal, QObject
    from PyQt5.QtGui import QColor, QBrush, QFont
except ImportError:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
        QTableWidgetItem, QHeaderView, QMessageBox, QInputDialog, QLabel
    )
    from PySide6.QtCore import Qt, Signal as pyqtSignal, QObject
    from PySide6.QtGui import QColor, QBrush, QFont

from sammonny.core.client import SamMonnyDaemonClient
from sammonny.core.models import ProfileInfo
from sammonny.engine.core import AntidetectEngine


class ProfilesTab(QWidget):
    """Manages browser profiles lifecycle and fingerprint cloning."""

    def __init__(self, engine: AntidetectEngine, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.engine = engine
        self.daemon = engine.daemon
        self._cached_profiles: List[ProfileInfo] = []
        self._filter_query = ""
        self._init_ui()
        self.refresh_profiles()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        # Toolbar
        toolbar = QHBoxLayout()
        toolbar.setSpacing(8)

        self.btn_refresh = QPushButton("🔄 Tải Lại")
        self.btn_refresh.setObjectName("btn-secondary")
        self.btn_refresh.clicked.connect(self.refresh_profiles)

        self.btn_create = QPushButton("➕ Tạo Hồ Sơ")
        self.btn_create.setObjectName("btn-success")
        self.btn_create.clicked.connect(self.on_create_profile)

        self.btn_start = QPushButton("▶ Khởi Chạy")
        self.btn_start.setStyleSheet("font-weight: 700; background: #0284c7;")
        self.btn_start.clicked.connect(self.on_start_profile)

        self.btn_stop = QPushButton("⏹ Dừng")
        self.btn_stop.setObjectName("btn-danger")
        self.btn_stop.clicked.connect(self.on_stop_profile)

        self.btn_clone = QPushButton("🧬 Nhân Bản & Mutate")
        self.btn_clone.setObjectName("btn-secondary")
        self.btn_clone.clicked.connect(self.on_clone_profile)

        self.btn_delete = QPushButton("🗑 Xóa")
        self.btn_delete.setObjectName("btn-danger")
        self.btn_delete.clicked.connect(self.on_delete_profile)

        toolbar.addWidget(self.btn_refresh)
        toolbar.addWidget(self.btn_create)
        toolbar.addWidget(self.btn_start)
        toolbar.addWidget(self.btn_stop)
        toolbar.addWidget(self.btn_clone)
        toolbar.addWidget(self.btn_delete)
        toolbar.addStretch()

        layout.addLayout(toolbar)

        # Modern Table Grid
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["ID Hồ Sơ", "Tên Hồ Sơ", "Hệ Điều Hành", "Proxy Mạng", "Trạng Thái"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(True)
        layout.addWidget(self.table)

    def refresh_profiles(self):
        """Fetch profiles from engine and refresh table view."""
        try:
            self._cached_profiles = self.engine.list_profiles()
        except Exception:
            self._cached_profiles = []
        self._render_table()

    def refresh_table(self):
        """Alias for refresh_profiles."""
        self.refresh_profiles()

    def apply_filter(self, query: str):
        """Filter table rows by search query."""
        self._filter_query = query.strip().lower()
        self._render_table()

    def _render_table(self):
        """Render cached profiles with active filter."""
        filtered = []
        for p in self._cached_profiles:
            if not self._filter_query:
                filtered.append(p)
            else:
                match = (
                    self._filter_query in p.id.lower() or
                    self._filter_query in p.name.lower() or
                    self._filter_query in (p.proxy or "").lower() or
                    self._filter_query in p.os.lower()
                )
                if match:
                    filtered.append(p)

        self.table.setRowCount(len(filtered))
        for row, p in enumerate(filtered):
            # ID
            item_id = QTableWidgetItem(p.id)
            item_id.setForeground(QBrush(QColor("#38bdf8")))

            # Name
            item_name = QTableWidgetItem(f"🌐  {p.name}")
            font = QFont()
            font.setBold(True)
            item_name.setFont(font)

            # OS
            os_display = p.os.upper()
            if "WIN" in os_display:
                os_display = "🪟 Windows"
            elif "MAC" in os_display:
                os_display = "🍎 macOS"
            elif "LINUX" in os_display:
                os_display = "🐧 Linux"
            item_os = QTableWidgetItem(os_display)

            # Proxy
            proxy_display = p.proxy or "Direct (Không dùng Proxy)"
            item_proxy = QTableWidgetItem(f"🛡️ {proxy_display}")
            if not p.proxy:
                item_proxy.setForeground(QBrush(QColor("#94a3b8")))

            # Status Badge
            is_running = p.status.lower() in ("running", "active")
            status_text = "● Đang Chạy" if is_running else "○ Đã Dừng"
            item_status = QTableWidgetItem(status_text)
            if is_running:
                item_status.setForeground(QBrush(QColor("#00f298")))
                item_status.setFont(font)
            else:
                item_status.setForeground(QBrush(QColor("#64748b")))

            self.table.setItem(row, 0, item_id)
            self.table.setItem(row, 1, item_name)
            self.table.setItem(row, 2, item_os)
            self.table.setItem(row, 3, item_proxy)
            self.table.setItem(row, 4, item_status)

    def _get_selected_profile_id(self) -> Optional[str]:
        selected = self.table.selectedItems()
        if not selected:
            return None
        row = selected[0].row()
        item = self.table.item(row, 0)
        return item.text() if item else None

    def on_create_profile(self):
        name, ok = QInputDialog.getText(self, "Tạo Hồ Sơ Mới", "Nhập tên hồ sơ (Ví dụ: Facebook Stealth 01):")
        if ok and name:
            try:
                self.engine.create_profile(name=name.strip())
                self.refresh_profiles()
            except Exception as e:
                QMessageBox.critical(self, "Lỗi", f"Không thể tạo hồ sơ: {e}")

    def on_start_profile(self):
        pid = self._get_selected_profile_id()
        if not pid:
            QMessageBox.warning(self, "Chú ý", "Vui lòng chọn 1 hồ sơ từ danh sách để khởi chạy.")
            return

        try:
            ws_url = self.daemon.start_profile(pid)
            QMessageBox.information(self, "Khởi Chạy Thành Công", f"Hồ sơ {pid} đã mở trình duyệt an toàn!\nCDP WebSocket: {ws_url}")
            self.refresh_profiles()
        except Exception as e:
            QMessageBox.critical(self, "Lỗi Khởi Chạy", f"Không thể khởi chạy: {e}")

    def on_stop_profile(self):
        pid = self._get_selected_profile_id()
        if not pid:
            return
        try:
            self.daemon.stop_profile(pid)
            self.refresh_profiles()
        except Exception as e:
            QMessageBox.critical(self, "Lỗi", f"Không thể dừng hồ sơ: {e}")

    def on_clone_profile(self):
        pid = self._get_selected_profile_id()
        if not pid:
            QMessageBox.warning(self, "Chú ý", "Vui lòng chọn 1 hồ sơ để nhân bản.")
            return

        name, ok = QInputDialog.getText(self, "Nhân Bản Hồ Sơ", "Nhập tên cho hồ sơ nhân bản:")
        if ok and name:
            try:
                cloned = self.engine.clone_profile(source_id=pid, new_name=name.strip())
                QMessageBox.information(
                    self, "Nhân Bản Thành Công",
                    f"Hồ sơ đã được nhân bản!\nID Mới: {cloned.id}\nVân tay đã được đột biến ngẫu nhiên (Canvas/WebGL/Audio)."
                )
                self.refresh_profiles()
            except Exception as e:
                QMessageBox.critical(self, "Lỗi", f"Không thể nhân bản: {e}")

    def on_delete_profile(self):
        pid = self._get_selected_profile_id()
        if not pid:
            return
        confirm = QMessageBox.question(
            self, "Xác Nhận Xóa", f"Bạn có chắc chắn muốn xóa hồ sơ {pid}?",
            QMessageBox.Yes | QMessageBox.No
        )
        if confirm == QMessageBox.Yes:
            try:
                self.daemon.delete_profile(pid)
                self.refresh_profiles()
            except Exception as e:
                QMessageBox.critical(self, "Lỗi", f"Không thể xóa hồ sơ: {e}")

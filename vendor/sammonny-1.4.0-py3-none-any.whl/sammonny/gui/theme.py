"""
Modern Fluent & Cyber-Obsidian Dark Theme for SamMonny Antidetect Suite Desktop GUI.
Engineered with premium enterprise aesthetics, smooth contrasts, and clear hierarchy.
"""

DARK_THEME_QSS = """
/* ===================================================================
   Base Window & Backgrounds
   =================================================================== */
QMainWindow, QDialog {
    background-color: #0b0d13;
    color: #e2e8f0;
    font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, 'Inter', sans-serif;
    font-size: 13px;
}

QWidget {
    background-color: transparent;
    color: #e2e8f0;
}

/* ===================================================================
   Tab Navigation - Modern High-Tech Ribbon
   =================================================================== */
QTabWidget::pane {
    border: 1px solid rgba(255, 255, 255, 0.08);
    background-color: #11141e;
    border-radius: 10px;
    margin-top: 4px;
}

QTabBar::tab {
    background-color: #151824;
    color: #94a3b8;
    padding: 11px 22px;
    margin-right: 6px;
    margin-bottom: 2px;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    border: 1px solid rgba(255, 255, 255, 0.05);
    font-weight: 600;
    font-size: 13px;
}

QTabBar::tab:selected {
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #1e2436, stop:1 #171c2b);
    color: #00f298;
    border: 1px solid rgba(0, 242, 152, 0.35);
    border-bottom: 3px solid #00f298;
}

QTabBar::tab:hover:!selected {
    background-color: #1a1e2c;
    color: #f1f5f9;
    border: 1px solid rgba(255, 255, 255, 0.12);
}

/* ===================================================================
   Cards & Group Boxes
   =================================================================== */
QGroupBox {
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 8px;
    margin-top: 16px;
    padding-top: 16px;
    font-weight: 700;
    color: #38bdf8;
    background-color: rgba(18, 22, 33, 0.6);
}

QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 2px 10px;
    background-color: #171c2b;
    border: 1px solid rgba(56, 189, 248, 0.3);
    border-radius: 5px;
    color: #38bdf8;
}

/* ===================================================================
   Table Widget - Modern High-Contrast Grid
   =================================================================== */
QTableWidget {
    background-color: #11141e;
    border: 1px solid rgba(255, 255, 255, 0.08);
    gridline-color: rgba(255, 255, 255, 0.05);
    border-radius: 8px;
    selection-background-color: #1d4ed8;
    selection-color: #ffffff;
    font-size: 13px;
    alternate-background-color: #141824;
}

QTableWidget::item {
    padding: 8px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.04);
}

QTableWidget::item:selected {
    background-color: rgba(0, 242, 152, 0.15);
    color: #ffffff;
    border-left: 3px solid #00f298;
}

QHeaderView::section {
    background-color: #0c0e15;
    color: #94a3b8;
    padding: 9px 8px;
    border: none;
    border-bottom: 2px solid rgba(255, 255, 255, 0.1);
    font-weight: 700;
    text-transform: uppercase;
    font-size: 11px;
    letter-spacing: 0.5px;
}

/* ===================================================================
   Buttons - Cyber Glow & Gradient System
   =================================================================== */
QPushButton {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2563eb, stop:1 #1d4ed8);
    color: #ffffff;
    border: 1px solid rgba(255, 255, 255, 0.15);
    padding: 8px 18px;
    border-radius: 6px;
    font-weight: 600;
    font-size: 13px;
}

QPushButton:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #3b82f6, stop:1 #2563eb);
    border: 1px solid rgba(59, 130, 246, 0.6);
}

QPushButton:pressed {
    background: #1e40af;
}

QPushButton:disabled {
    background-color: #1a1e2a;
    color: #64748b;
    border: 1px solid rgba(255, 255, 255, 0.03);
}

/* Button Variants */
QPushButton#btn-success, QPushButton[role="success"] {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #059669, stop:1 #10b981);
    border: 1px solid rgba(16, 185, 129, 0.5);
    color: #ffffff;
}

QPushButton#btn-success:hover, QPushButton[role="success"]:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #10b981, stop:1 #34d399);
}

QPushButton#btn-danger, QPushButton[role="danger"] {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #b91c1c, stop:1 #ef4444);
    border: 1px solid rgba(239, 68, 68, 0.5);
    color: #ffffff;
}

QPushButton#btn-danger:hover, QPushButton[role="danger"]:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #dc2626, stop:1 #f87171);
}

QPushButton#btn-secondary {
    background-color: #1e2434;
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #cbd5e1;
}

QPushButton#btn-secondary:hover {
    background-color: #272f44;
    color: #ffffff;
}

/* ===================================================================
   Inputs & Controls
   =================================================================== */
QLineEdit, QComboBox, QTextEdit, QSpinBox {
    background-color: #0c0e15;
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 6px;
    padding: 7px 12px;
    color: #f8fafc;
    font-size: 13px;
    selection-background-color: #0284c7;
}

QLineEdit:focus, QComboBox:focus, QTextEdit:focus, QSpinBox:focus {
    border: 1px solid #00f298;
    background-color: #0f121d;
}

QComboBox::drop-down {
    border: none;
    width: 24px;
}

/* ===================================================================
   Progress Bars
   =================================================================== */
QProgressBar {
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 6px;
    text-align: center;
    color: #f8fafc;
    background-color: #0c0e15;
    font-weight: 600;
}

QProgressBar::chunk {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284c7, stop:1 #00f298);
    border-radius: 5px;
}

/* ===================================================================
   Status Bar
   =================================================================== */
QStatusBar {
    background-color: #090a0f;
    color: #94a3b8;
    border-top: 1px solid rgba(255, 255, 255, 0.08);
    padding: 4px 8px;
    font-size: 12px;
}

QStatusBar QLabel {
    color: #cbd5e1;
}

/* ===================================================================
   Custom Scrollbar
   =================================================================== */
QScrollBar:vertical {
    border: none;
    background: #0c0e15;
    width: 8px;
    margin: 0;
    border-radius: 4px;
}

QScrollBar::handle:vertical {
    background: rgba(255, 255, 255, 0.2);
    min-height: 24px;
    border-radius: 4px;
}

QScrollBar::handle:vertical:hover {
    background: #00f298;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
"""

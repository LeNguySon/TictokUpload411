"""
Layered Tunneling Engine (VPN + Proxy Multi-Hop Coordination).
Eliminates 6 critical antidetect network leaks:
1. Split DNS Leak (forces remote FQDN proxy resolution).
2. WebRTC Virtual NIC Enumeration (disables non-proxied UDP).
3. IPv6 Dual-Stack Bypass.
4. Timezone & GeoIP Desynchronization.
5. TCP MSS/MTU Fingerprinting.
6. Fallback Failover Leak (Hard Kill-Switch).
"""

from __future__ import annotations
from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field

from sammonny.core.models import ProxyItem
from sammonny.vpn.wireguard import WireGuardConfig


@dataclass
class LayeredTunnelConfig:
    enabled: bool = True
    wireguard: Optional[WireGuardConfig] = None
    proxy: Optional[ProxyItem] = None
    kill_switch: bool = True
    dns_leak_protection: bool = True
    block_ipv6: bool = True
    webrtc_protection: bool = True

    def generate_chromium_flags(self) -> List[str]:
        """
        Generates hardened Chromium kernel launch flags to eliminate all network leaks.
        """
        flags: List[str] = []

        # 1. DNS Leak Protection: Force all DNS resolution through remote proxy (except proxy host itself)
        if self.dns_leak_protection and self.proxy:
            proxy_host = self.proxy.host
            flags.append(f'--host-resolver-rules="MAP * 0.0.0.0 , EXCLUDE {proxy_host}"')

        # 2. WebRTC Virtual NIC Leak Protection
        if self.webrtc_protection:
            flags.append("--force-webrtc-ip-handling-policy=disable_non_proxied_udp")
            flags.append("--enforce-webrtc-ip-permission-check")

        # 3. IPv6 Bypass Leak Protection
        if self.block_ipv6:
            flags.append("--disable-ipv6")

        # 4. Proxy Configuration flag (if not using Orbita internal Preferences mode)
        if self.proxy:
            flags.append(f"--proxy-server={self.proxy.to_url()}")

        return flags

    def generate_preferences_override(self) -> Dict[str, Any]:
        """
        Generates gologin C++ preferences structure to configure in-engine proxy and WebRTC masking.
        """
        pref: Dict[str, Any] = {}
        if self.proxy:
            pref["proxy"] = {
                "mode": "fixed_servers",
                "server": self.proxy.to_url(),
            }
        if self.webrtc_protection:
            pref["webRTC"] = {
                "mode": "disabled",
                "should_fill_empty_ice_list": True,
            }
        return pref

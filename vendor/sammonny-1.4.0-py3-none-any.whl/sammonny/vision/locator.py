"""
High-Level Image Locator & Visual Automation Client.
Captures Skia GPU surfaces, detects visual elements via multi-scale matching,
and executes human-like clicks on Canvas and non-DOM targets.
"""

from __future__ import annotations
import time
from pathlib import Path
from typing import List, Optional, Union, Dict, Any

from sammonny.core.cdp import SyncCdpClient
from sammonny.core.models import TemplateMatchResult, Point, Rect
from sammonny.core.exceptions import VisionError
from sammonny.vision.matcher import MultiScaleTemplateMatcher
from sammonny.dom.mouse import HumanMouse


class ImageLocator:
    """High-Level Visual Automation Controller."""

    def __init__(
        self,
        cdp_client: SyncCdpClient,
        mouse: Optional[HumanMouse] = None,
        matcher: Optional[MultiScaleTemplateMatcher] = None,
    ):
        self.cdp = cdp_client
        self.mouse = mouse or HumanMouse(cdp_client)
        self.matcher = matcher or MultiScaleTemplateMatcher()

    def screenshot(self, save_path: Optional[Union[str, Path]] = None) -> bytes:
        """Captures Skia GPU screenshot (works when minimized)."""
        png_bytes = self.cdp.capture_screenshot(from_surface=True)
        if save_path:
            with open(save_path, "wb") as f:
                f.write(png_bytes)
        return png_bytes

    def find_image(
        self,
        template: Union[bytes, str, Path],
        min_confidence: float = 0.8,
        scales: Optional[List[float]] = None,
    ) -> Optional[TemplateMatchResult]:
        """Captures current surface and finds the template position."""
        screen = self.screenshot()
        return self.matcher.match(
            screenshot=screen,
            template=template,
            min_confidence=min_confidence,
            scales=scales,
        )

    def wait_for_image(
        self,
        template: Union[bytes, str, Path],
        timeout: float = 10.0,
        poll_interval: float = 0.4,
        min_confidence: float = 0.8,
        scales: Optional[List[float]] = None,
    ) -> TemplateMatchResult:
        """Polls page screenshot until template appears or timeout expires."""
        start = time.time()
        while time.time() - start < timeout:
            res = self.find_image(template, min_confidence=min_confidence, scales=scales)
            if res:
                return res
            time.sleep(poll_interval)

        raise VisionError(f"Image template not found within {timeout:.1f}s timeout.")

    def click_image(
        self,
        template: Union[bytes, str, Path],
        timeout: float = 10.0,
        min_confidence: float = 0.8,
        style: str = "minimum_jerk",
        scales: Optional[List[float]] = None,
    ) -> Point:
        """
        Locates visual template and executes natural human click with 2D Gaussian dispersion.
        """
        match_res = self.wait_for_image(
            template=template,
            timeout=timeout,
            min_confidence=min_confidence,
            scales=scales,
        )
        target_pt = match_res.click_point
        self.mouse.click(target_pt.x, target_pt.y, style=style)
        return target_pt

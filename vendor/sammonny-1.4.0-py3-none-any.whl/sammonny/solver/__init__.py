from sammonny.solver.color_captcha import ColorCaptchaSolver
from sammonny.solver.slider import SliderCaptchaSolver
from sammonny.solver.checkbox import CheckboxCaptchaSolver

__all__ = [
    "ColorCaptchaSolver",
    "SliderCaptchaSolver",
    "CheckboxCaptchaSolver",
]

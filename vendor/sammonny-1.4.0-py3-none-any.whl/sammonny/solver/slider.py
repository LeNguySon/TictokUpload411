"""
Slide-to-Verify & Puzzle Gap CAPTCHA Solver.
Identifies notch position in slider puzzle challenges using edge detection and contour analysis,
and drags slider button with biometric human mouse kinematics (wobble, deceleration, micro-overshoot).
"""

from __future__ import annotations
import math
import random
import time
from typing import Optional, Tuple, Union, List
from pathlib import Path
from PIL import Image

from sammonny.core.cdp import SyncCdpClient
from sammonny.core.models import Point, Rect
from sammonny.dom.kinematics import MinimumJerkGenerator
from sammonny.dom.mouse import HumanMouse

try:
    import cv2
    import numpy as np
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False


class SliderCaptchaSolver:
    """Finds puzzle gap offset and executes natural human slider drag."""

    def __init__(self, cdp_client: Optional[SyncCdpClient] = None):
        self.cdp = cdp_client
        self.mouse = HumanMouse(cdp_client) if cdp_client else None

    @staticmethod
    def find_gap_x_offset(
        background: Union[bytes, str, Path, "np.ndarray"],
        slider_piece: Optional[Union[bytes, str, Path, "np.ndarray"]] = None,
        min_x: int = 50,
    ) -> int:
        """
        Calculates horizontal offset X of the puzzle notch on the background image.
        Uses Canny edge template matching or gradient discontinuity.
        """
        if not HAS_OPENCV:
            raise RuntimeError("OpenCV is required to calculate slider gap position.")

        # Read background
        if isinstance(background, (str, Path)):
            bg_bgr = cv2.imread(str(background))
        elif isinstance(background, bytes):
            bg_bgr = cv2.imdecode(np.frombuffer(background, np.uint8), cv2.IMREAD_COLOR)
        else:
            bg_bgr = background

        if bg_bgr is None:
            raise RuntimeError(f"Failed to load or decode background image from source: {background}")

        bg_gray = cv2.cvtColor(bg_bgr, cv2.COLOR_BGR2GRAY)
        bg_edges = cv2.Canny(bg_gray, 100, 200)

        if slider_piece is not None:
            if isinstance(slider_piece, (str, Path)):
                pc_bgr = cv2.imread(str(slider_piece))
            elif isinstance(slider_piece, bytes):
                pc_bgr = cv2.imdecode(np.frombuffer(slider_piece, np.uint8), cv2.IMREAD_COLOR)
            else:
                pc_bgr = slider_piece

            if pc_bgr is None:
                raise RuntimeError(f"Failed to load or decode slider piece from source: {slider_piece}")

            pc_gray = cv2.cvtColor(pc_bgr, cv2.COLOR_BGR2GRAY)
            # Crop search region from min_x onwards
            search_bg = bg_gray[:, min_x:] if bg_gray.shape[1] > (min_x + pc_gray.shape[1]) else bg_gray
            res = cv2.matchTemplate(search_bg, pc_gray, cv2.TM_SQDIFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
            return (min_x if search_bg.shape[1] != bg_gray.shape[1] else 0) + int(min_loc[0])



        # If no slider piece provided, find prominent notch contours on background
        contours, _ = cv2.findContours(bg_edges[:, min_x:], cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        best_x = min_x + 100
        for cnt in contours:
            x, y, w, h = cv2.boundingRect(cnt)
            # Typical puzzle piece notch size: 30x30 to 65x65
            if 30 <= w <= 70 and 30 <= h <= 70 and 0.8 <= (w / h) <= 1.25:
                best_x = min_x + x
                break

        return best_x

    def drag_slider_human(
        self,
        slider_start_x: float,
        slider_start_y: float,
        distance_x: float,
    ) -> None:
        """
        Drags the slider button to the target gap using human motor kinematics:
        - Down dwell
        - Quintic minimum jerk trajectory with biological vertical jitter (+/- 1-2px)
        - Deceleration & slight micro-overshoot at final stage
        - Up release
        """
        if not self.cdp:
            raise RuntimeError("CdpClient must be configured to drag slider.")

        # 1. Move to slider knob
        self.mouse.move(slider_start_x, slider_start_y)
        time.sleep(random.uniform(0.08, 0.15))

        # 2. Press down
        self.cdp.dispatch_mouse("mousePressed", x=slider_start_x, y=slider_start_y, button="left", click_count=1)
        time.sleep(random.uniform(0.06, 0.12))

        # 3. Generate trajectory to target X
        target_x = slider_start_x + distance_x
        target_y = slider_start_y

        path = MinimumJerkGenerator.generate_path(
            Point(slider_start_x, slider_start_y),
            Point(target_x, target_y),
            duration_ms=random.randint(350, 550),
        )

        for pt, delay in path:
            # Add subtle vertical hand tremor (+/- 1.5px) during horizontal drag
            wobble_y = pt.y + random.uniform(-1.2, 1.2)
            self.cdp.dispatch_mouse("mouseMoved", x=pt.x, y=wobble_y, button="left")
            time.sleep(delay)

        # 4. Final verification dwell before releasing
        time.sleep(random.uniform(0.08, 0.16))

        # 5. Release
        self.cdp.dispatch_mouse("mouseReleased", x=target_x, y=target_y, button="left", click_count=1)

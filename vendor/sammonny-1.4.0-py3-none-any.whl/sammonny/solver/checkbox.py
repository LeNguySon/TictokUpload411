"""
Cloudflare Turnstile & Checkbox Challenge Solver.
Detects challenge iframes / checkboxes in the DOM and executes biometric human clicks.
"""

from __future__ import annotations
import time
import random
from typing import Optional
from sammonny.core.cdp import SyncCdpClient
from sammonny.core.models import Rect, Point
from sammonny.dom.mouse import HumanMouse


class CheckboxCaptchaSolver:
    """Detects and naturally clicks Cloudflare Turnstile & reCAPTCHA checkboxes."""

    def __init__(self, cdp_client: SyncCdpClient, mouse: Optional[HumanMouse] = None):
        self.cdp = cdp_client
        self.mouse = mouse or HumanMouse(cdp_client)

    def solve_turnstile(self, timeout_sec: float = 12.0) -> bool:
        """
        Locates Cloudflare Turnstile iframe / shadow root checkbox and clicks naturally.
        """
        start = time.time()
        while time.time() - start < timeout_sec:
            js = """
            (() => {
                // 1. Check for Turnstile container or iframe
                const iframes = Array.from(document.querySelectorAll("iframe"));
                for (const frame of iframes) {
                    const src = frame.src || "";
                    if (src.includes("challenges.cloudflare.com") || src.includes("turnstile")) {
                        const r = frame.getBoundingClientRect();
                        if (r.width > 20 && r.height > 20) {
                            return {
                                x: r.x + 35, // Checkbox typically offset ~35px from left edge
                                y: r.y + (r.height / 2),
                                width: 25,
                                height: 25,
                                found: true
                            };
                        }
                    }
                }
                // 2. Generic cf-turnstile element
                const cfElem = document.querySelector(".cf-turnstile, #cf-turnstile");
                if (cfElem) {
                    const r = cfElem.getBoundingClientRect();
                    if (r.width > 20 && r.height > 20) {
                        return { x: r.x + 30, y: r.y + (r.height / 2), width: 25, height: 25, found: true };
                    }
                }
                return { found: false };
            })()
            """
            res = self.cdp.evaluate(js)
            if res and res.get("found"):
                r = Rect(res["x"], res["y"], res["width"], res["height"])
                click_pt = r.sample_human_point()
                # Human click
                self.mouse.click(click_pt.x, click_pt.y, style="minimum_jerk")
                time.sleep(2.0)
                return True
            time.sleep(0.4)

        return False

"""
Universal Enterprise Color-Filtered CAPTCHA Solver.
Compatible with multi-lingual web authentication challenges, visual verification forms, and portals.
Uses HSV color filtering + ddddocr / local ONNX runtime.
"""

from __future__ import annotations
import io
import re
from typing import Dict, List, Optional, Tuple, Union
from PIL import Image

try:
    import cv2
    import numpy as np
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

try:
    import ddddocr
    HAS_DDDDOCR = True
except ImportError:
    HAS_DDDDOCR = False


class ColorCaptchaSolver:
    """
    Universal production-grade solver for color-specific text challenge CAPTCHAs.
    Filters noise lines and non-target colors using HSV thresholding before OCR.
    """

    COLOR_LEXICON: Dict[str, List[str]] = {
        "black": ["đen", "black", "tối"],
        "red": ["đỏ", "red", "huyết"],
        "green": ["xanh lá", "xanh lục", "green", "lá cây"],
        "blue": ["xanh dương", "xanh lam", "xanh biển", "da trời", "blue", "cyan"],
        "yellow": ["vàng", "yellow"],
        "orange": ["cam", "orange"],
        "purple": ["tím", "purple", "violet"],
        "pink": ["hồng", "pink", "magenta"],
        "white": ["trắng", "white", "sáng"],
        "gray": ["xám", "grey", "gray"],
    }

    def __init__(self, show_ad: bool = False):
        self._ocr = ddddocr.DdddOcr(show_ad=show_ad) if HAS_DDDDOCR else None

    @classmethod
    def parse_target_color(
        cls, prompt: str, image_bgr: Optional["np.ndarray"] = None
    ) -> str:
        prompt_lower = prompt.lower()
        for color_key, keywords in cls.COLOR_LEXICON.items():
            if any(kw in prompt_lower for kw in keywords):
                return color_key

        if "xanh" in prompt_lower:
            if image_bgr is not None and HAS_OPENCV:
                hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)
                g_cnt = int(np.sum((hsv[:, :, 0] >= 36) & (hsv[:, :, 0] <= 85) & (hsv[:, :, 1] >= 60)))
                b_cnt = int(np.sum((hsv[:, :, 0] >= 86) & (hsv[:, :, 0] <= 130) & (hsv[:, :, 1] >= 60)))
                if b_cnt > g_cnt and b_cnt > 150:
                    return "blue"
                return "green"
            return "green"

        return "black"

    @classmethod
    def get_color_mask(cls, image_bgr: "np.ndarray", color_name: str) -> "np.ndarray":
        if not HAS_OPENCV:
            raise RuntimeError("OpenCV is required for color mask extraction.")

        hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)
        color = color_name.lower()

        if color == "black":
            mask = cv2.inRange(hsv, np.array([0, 0, 0]), np.array([180, 255, 65]))
        elif color == "red":
            mask1 = cv2.inRange(hsv, np.array([0, 70, 70]), np.array([10, 255, 255]))
            mask2 = cv2.inRange(hsv, np.array([170, 70, 70]), np.array([180, 255, 255]))
            mask = cv2.bitwise_or(mask1, mask2)
        elif color == "green":
            mask = cv2.inRange(hsv, np.array([35, 60, 60]), np.array([85, 255, 255]))
        elif color == "blue":
            mask = cv2.inRange(hsv, np.array([86, 60, 60]), np.array([135, 255, 255]))
        elif color == "yellow":
            mask = cv2.inRange(hsv, np.array([20, 80, 80]), np.array([35, 255, 255]))
        elif color == "orange":
            mask = cv2.inRange(hsv, np.array([11, 100, 100]), np.array([22, 255, 255]))
        elif color == "purple":
            mask = cv2.inRange(hsv, np.array([125, 50, 50]), np.array([155, 255, 255]))
        elif color == "pink":
            mask = cv2.inRange(hsv, np.array([150, 50, 100]), np.array([170, 255, 255]))
        elif color == "white":
            mask = cv2.inRange(hsv, np.array([0, 0, 190]), np.array([180, 50, 255]))
        elif color == "gray":
            mask = cv2.inRange(hsv, np.array([0, 0, 65]), np.array([180, 60, 180]))
        else:
            mask = np.zeros(hsv.shape[:2], dtype=np.uint8)

        # Morphological noise cleanup
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        return mask

    def solve(self, image_data: Union[bytes, "np.ndarray", str], prompt: str) -> str:
        """
        Filters target color from image based on prompt text, and performs OCR recognition.
        """
        if isinstance(image_data, (str, bytes)):
            if isinstance(image_data, str):
                with open(image_data, "rb") as f:
                    raw_bytes = f.read()
            else:
                raw_bytes = image_data
            nparr = np.frombuffer(raw_bytes, np.uint8)
            img_bgr = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        else:
            img_bgr = image_data

        if img_bgr is None:
            raise ValueError(f"Failed to decode or load valid image data for color CAPTCHA.")

        target_color = self.parse_target_color(prompt, img_bgr)
        mask = self.get_color_mask(img_bgr, target_color)

        # Invert: text black on white background for optimal OCR recognition
        bin_img = cv2.bitwise_not(mask)

        # Encode to PNG bytes
        is_success, buffer = cv2.imencode(".png", bin_img)
        if not is_success:
            return ""

        if self._ocr:
            text = self._ocr.classification(buffer.tobytes())
            # Clean non-alphanumeric
            return re.sub(r"[^a-zA-Z0-9]", "", text).strip()

        return ""
